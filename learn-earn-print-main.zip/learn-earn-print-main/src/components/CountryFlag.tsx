interface CountryFlagProps {
  country: 'ro' | 'en' | 'es' | 'it' | 'fr' | 'de' | 'at' | 'ch';
  className?: string;
}

const flagEmojis: Record<string, string> = {
  ro: '🇷🇴',
  en: '🇬🇧',
  es: '🇪🇸',
  it: '🇮🇹',
  fr: '🇫🇷',
  de: '🇩🇪',
  at: '🇦🇹',
  ch: '🇨🇭',
};

const flagColors: Record<string, { colors: string[], direction?: string }> = {
  ro: { colors: ['#002B7F', '#FCD116', '#CE1126'], direction: 'to right' },
  en: { colors: ['#012169', '#FFFFFF', '#C8102E'] },
  es: { colors: ['#AA151B', '#F1BF00', '#AA151B'], direction: 'to bottom' },
  it: { colors: ['#009246', '#FFFFFF', '#CE2B37'], direction: 'to right' },
  fr: { colors: ['#002395', '#FFFFFF', '#ED2939'], direction: 'to right' },
  de: { colors: ['#000000', '#DD0000', '#FFCE00'], direction: 'to bottom' },
  at: { colors: ['#ED2939', '#FFFFFF', '#ED2939'], direction: 'to bottom' },
  ch: { colors: ['#FF0000', '#FFFFFF'], direction: 'to right' },
};

export function CountryFlag({ country, className = '' }: CountryFlagProps) {
  const flag = flagColors[country];
  
  // Fallback to emoji for browsers that support it
  const supportsEmojiFlags = () => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return false;
      
      ctx.fillText('🇺🇸', 0, 0);
      return ctx.measureText('🇺🇸').width > 10;
    } catch {
      return false;
    }
  };

  if (!flag) {
    return <span className={className}>{flagEmojis[country] || country.toUpperCase()}</span>;
  }

  const gradient = flag.direction === 'to bottom' 
    ? `linear-gradient(to bottom, ${flag.colors.join(', ')})`
    : `linear-gradient(to right, ${flag.colors.join(', ')})`;

  return (
    <span 
      className={`inline-block rounded ${className}`}
      style={{
        width: '1.5em',
        height: '1em',
        background: gradient,
        border: '1px solid rgba(0,0,0,0.1)',
        verticalAlign: 'middle',
        boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
      }}
      title={country.toUpperCase()}
      role="img"
      aria-label={`${country.toUpperCase()} flag`}
    />
  );
}
