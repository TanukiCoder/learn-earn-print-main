import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import api from "@/lib/api-client";
import { FileText, DollarSign, FileQuestion, CheckCircle2, Sparkles, Award, BookOpen, ArrowRight, Zap, Trophy } from "lucide-react";
import { receiptTemplates } from "@/lib/receiptTemplates";
import jsPDF from "jspdf";
import { useI18n } from "@/lib/i18n";

interface Quiz {
  id: string;
  title: string;
}

interface ReceiptDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  videoId: string;
  videoTitle: string;
  quizzes: Quiz[];
  preselectedQuizId?: string | null;
}

export function ReceiptDialog({ open, onOpenChange, videoId, videoTitle, quizzes, preselectedQuizId }: ReceiptDialogProps) {
  const [quizTitle, setQuizTitle] = useState<string>('Avem câteva întrebări');
  
  useEffect(() => {
    // Load quiz title from settings
    const loadQuizTitle = async () => {
      try {
        const response = await api.receipts.getSettings();
        if (response.data?.quiz_title) {
          setQuizTitle(response.data.quiz_title);
        }
      } catch (error) {
        console.error('Error loading quiz title:', error);
      }
    };
    
    loadQuizTitle();
  }, []);
  const [step, setStep] = useState<'quiz' | 'questions' | 'receipt'>('quiz');
  const [selectedQuiz, setSelectedQuiz] = useState<string>('');
  const [quizQuestions, setQuizQuestions] = useState<any[]>([]);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [generateReceipt, setGenerateReceipt] = useState<'yes' | 'no'>('no');
  const [amount, setAmount] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('romania');
  const [isGenerating, setIsGenerating] = useState(false);
  const { t } = useI18n();
  useEffect(() => {
    if (open) {
      console.log('ReceiptDialog opened with quizzes:', quizzes);
      console.log('Preselected quiz ID:', preselectedQuizId);
      console.log('Quizzes length:', quizzes?.length);
      console.log('Quizzes array:', Array.isArray(quizzes) ? quizzes : 'Not an array');
      console.log('Quizzes content:', JSON.stringify(quizzes));
      
      // Check if quizzes array exists and has items - use a more robust check
      const hasQuizzes = Array.isArray(quizzes) && quizzes.length > 0 && quizzes.some(q => q && q.id);
      
      console.log('Has quizzes:', hasQuizzes);
      
      // If there's a preselected quiz and it exists in the list, load questions
      if (preselectedQuizId && hasQuizzes && quizzes.some(q => q && q.id === preselectedQuizId)) {
        console.log('Setting step to questions for preselected quiz');
        setSelectedQuiz(preselectedQuizId);
        loadQuizQuestions(preselectedQuizId);
        setStep('questions');
      } else if (hasQuizzes) {
        // If there are quizzes available, show quiz selection step
        console.log('Setting step to quiz selection - HAS QUIZZES');
        setStep('quiz');
        setSelectedQuiz('');
        setQuizQuestions([]);
      } else {
        // No quizzes available, go directly to receipt generation
        console.log('No quizzes, going directly to receipt');
        setStep('receipt');
        setSelectedQuiz('');
        setQuizQuestions([]);
      }
      
      setAnswers({});
      setGenerateReceipt('no');
      setAmount('');
      setSelectedTemplate('romania');
    }
  }, [open, quizzes, preselectedQuizId]);

  const loadQuizQuestions = async (quizId: string) => {
    try {
      const response = await api.quizzes.getById(quizId);
      const questions = response.data.questions || [];
      
      console.log('Loaded quiz questions:', questions);
      setQuizQuestions(questions);
    } catch (error) {
      console.error('Error loading quiz questions:', error);
      setQuizQuestions([]);
    }
  };

const handleQuizSubmit = async () => {
  if (!selectedQuiz) {
    toast.error(t('receiptDialog.error.selectQuiz'));
    return;
  }

    await loadQuizQuestions(selectedQuiz);
    setStep('questions');
  };

const handleQuestionsSubmit = () => {
  // Check if all questions are answered
  if (Object.keys(answers).length < quizQuestions.length) {
    toast.error(t('receiptDialog.error.answerAll'));
    return;
  }
  setStep('receipt');
};

  const generateReceiptNumber = async () => {
    try {
      const response = await api.receipts.getNextNumber();
      return response.data.receiptNumber;
    } catch (error) {
      console.error('Error getting next receipt number:', error);
      // Fallback to random number if API fails
      const year = new Date().getFullYear();
      const random = Math.floor(Math.random() * 999999);
      return `BON-${year}-${String(random).padStart(6, '0')}`;
    }
  };

const handleGenerateReceipt = async () => {
  if (!amount || parseFloat(amount) <= 0) {
    toast.error(t('receiptDialog.error.invalidAmount'));
    return;
  }

    setIsGenerating(true);

    try {
      // Get current user
      const userResponse = await api.auth.getCurrentUser();
      const user = userResponse.data;
      if (!user) throw new Error(t('receiptDialog.error.notAuthenticated'));

      // Create quiz submission if quiz is selected
      let quizSubmissionId = null;
      if (selectedQuiz) {
        try {
          const submissionResponse = await api.quizzes.submit(selectedQuiz, {
            answers: answers,
            video_id: videoId
          });
          quizSubmissionId = submissionResponse.data.id;
        } catch (submissionError) {
          console.error('Quiz submission error:', submissionError);
          toast.error(t('receiptDialog.error.saveAnswers'));
          throw submissionError;
        }
      }

      // Load receipt settings
      const settingsResponse = await api.receipts.getSettings();
      const settings = settingsResponse.data || {};

      const receiptNumber = await generateReceiptNumber();
      const template = receiptTemplates[selectedTemplate];
      
      // Create PDF with proper settings for receipt
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [72, 200],
        compress: true
      });

      // Set font to monospace for better alignment (like real receipts)
      pdf.setFont('courier', 'normal');
      
      // Get date format based on template
      const dateFormat = selectedTemplate === 'franta' ? 'fr-FR' : 
                        selectedTemplate === 'italia' ? 'it-IT' : 
                        selectedTemplate === 'spania' ? 'es-ES' : 'ro-RO';
      
      const receiptData = {
        receiptNumber,
        date: new Date().toLocaleDateString(dateFormat, { 
          day: '2-digit', 
          month: '2-digit', 
          year: 'numeric' 
        }),
        time: new Date().toLocaleTimeString(dateFormat, { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: false
        }),
        userName: user?.full_name || 'Participant',
        videoTitle: videoTitle,
        amount: parseFloat(amount).toFixed(2),
        settings: settings
      };

      let y = 8;
      const maxWidth = 67; // 72mm - 5mm margins (increased for better text fitting)
      
      // Header - centered, larger font
      pdf.setFontSize(11);
      pdf.setFont('courier', 'bold');
      const headerLines = template.headerFormat({...settings, receiptNumber});
      headerLines.forEach((line: string) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---') || line.includes('─') || line.includes('━')) {
          // Draw line separator - use simple dashes
          pdf.setFontSize(8);
          pdf.setFont('courier', 'normal');
          // Replace Unicode dashes with simple dashes
          const cleanLine = line.replace(/[─━]/g, '-').replace(/%/g, '-');
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 30)), 36, y, { align: 'center' });
          y += 4;
          pdf.setFontSize(11);
          pdf.setFont('courier', 'bold');
        } else {
          // Clean any percent signs or Unicode characters
          const cleanLine = line.replace(/%/g, '').trim();
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 28)), 36, y, { align: 'center' });
          y += 4;
        }
      });
      
      y += 2;
      
      // Details - left aligned, smaller font
      pdf.setFontSize(8);
      pdf.setFont('courier', 'normal');
      const details = template.detailsFormat(receiptData);
      const totalLines = details.length;
      details.forEach((line: string, index: number) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---')) {
          // Draw separator line
          const lineLength = Math.min(line.length, 30);
          pdf.text(line.substring(0, lineLength), 5, y, { maxWidth: maxWidth });
          y += 4;
        } else {
          // Regular text, wrap if needed
          // Use smaller font for last few lines if they're footer messages
          const isFooterLine = index >= totalLines - 5 && !line.includes('Bon Nr:') && !line.includes('Data:') && !line.includes('Client:') && !line.includes('Nº:') && !line.includes('Nr:') && !line.includes('Fecha:') && !line.includes('Date:') && !line.includes('Datum:');
          const isLastLine = index === totalLines - 1;
          // Check for footer messages in different languages
          const isParticipareLine = line.includes('Mulțumim!') || 
                                   line.includes('Multumim pentru participare') || 
                                   line.includes('Gracias por su participación') ||
                                   line.includes('Grazie per la partecipazione') ||
                                   line.includes('Merci pour votre participation') ||
                                   line.includes('Vielen Dank für Ihre Teilnahme');
          
          if (isFooterLine && !isLastLine && !isParticipareLine) {
            pdf.setFontSize(6.5); // Smaller for footer lines
          }
          if (isLastLine || isParticipareLine) {
            pdf.setFontSize(4); // Very small for last line and footer messages to ensure it fits
          }
          
          // For footer messages, use maximum width and ensure strict left alignment
          if (isParticipareLine) {
            // Write directly with maximum width, left aligned
            pdf.text(line.trim(), 5, y, { maxWidth: 75, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else if (isLastLine) {
            // For other last lines
            const textMaxWidth = maxWidth + 15;
            pdf.text(line.trim(), 5, y, { maxWidth: textMaxWidth, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else {
            // Regular lines
            const textMaxWidth = maxWidth;
            const lines = pdf.splitTextToSize(line, textMaxWidth);
            lines.forEach((textLine: string) => {
              pdf.text(textLine, 5, y, { 
                maxWidth: textMaxWidth,
                align: 'left'
              });
              y += 3.5;
            });
            if (isFooterLine) {
              pdf.setFontSize(8); // Reset font size
            }
          }
        }
      });
      
      y += 3;

      // Footer messages are now handled within the template detailsFormat function

      // Save to database
      try {
        await api.receipts.create({
          video_id: videoId,
          quiz_submission_id: quizSubmissionId,
          amount: parseFloat(amount),
          receipt_number: receiptNumber,
          user_name: user?.full_name || 'Participant',
          template_country: selectedTemplate,
        });
      } catch (insertError: any) {
        console.error('Receipt insert error:', insertError);
        throw new Error(`${t('receipts.errorSaving')}: ${insertError.message}`);
      }

      // Download PDF
      pdf.save(`${receiptNumber}.pdf`);

      toast.success(t('receiptDialog.success.generated'));
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error generating receipt:', error);
      toast.error(error.message || t('receiptDialog.error.generate'));
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5 rounded-lg blur-2xl -z-10" />
          <DialogTitle className="flex items-center gap-3 text-2xl">
            {step === 'quiz' ? (
              <>
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg">
                  <FileQuestion className="h-6 w-6 text-white" />
                </div>
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent font-bold">
                  {quizTitle}
                </span>
              </>
            ) : step === 'questions' ? (
              <>
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg">
                  <BookOpen className="h-6 w-6 text-white" />
                </div>
                <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent font-bold">
                  Răspunde la Întrebări
                </span>
              </>
            ) : (
              <>
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 shadow-lg">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <span className="bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent font-bold">
                  Generează Bon Fiscal
                </span>
              </>
            )}
          </DialogTitle>
          <DialogDescription className="text-base mt-3">
            {step === 'quiz' 
              ? '🎯 Alege un test pentru a verifica cunoștințele tale după vizionarea videoclipului'
              : step === 'questions'
              ? `📝 Răspunde la toate întrebările (${Object.keys(answers).length}/${quizQuestions.length} completate)`
              : '💰 Completează detaliile pentru bonul educațional'
            }
          </DialogDescription>
        </DialogHeader>

        {step === 'quiz' ? (
          <div className="space-y-6">
            {Array.isArray(quizzes) && quizzes.length > 0 ? (
              <>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-blue-500/10 rounded-2xl blur-xl -z-10" />
                  <div className="space-y-4 p-1">
                    <div className="flex items-center gap-2 mb-4">
                      <Sparkles className="h-5 w-5 text-primary" />
                      <Label className="text-lg font-bold">{t('receiptDialog.availableQuizzes')}</Label>
                    </div>
                    <RadioGroup value={selectedQuiz} onValueChange={setSelectedQuiz} className="space-y-3">
                      {quizzes.map((quiz, index) => {
                        const isSelected = selectedQuiz === quiz.id;
                        return (
                          <div
                            key={quiz.id}
                            className={`relative group cursor-pointer transition-all duration-300 ${
                              isSelected 
                                ? 'scale-[1.02]' 
                                : 'hover:scale-[1.01]'
                            }`}
                          >
                            <div className={`absolute inset-0 rounded-xl blur-lg transition-opacity ${
                              isSelected 
                                ? 'bg-gradient-to-r from-blue-500/30 to-purple-500/30 opacity-100' 
                                : 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-50'
                            }`} />
                            <div className={`relative flex items-center gap-4 p-5 rounded-xl border-2 transition-all ${
                              isSelected
                                ? 'border-primary bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10 shadow-lg shadow-primary/20'
                                : 'border-border bg-card hover:border-primary/50 hover:bg-primary/5 shadow-sm hover:shadow-md'
                            }`}>
                              <RadioGroupItem 
                                value={quiz.id} 
                                id={quiz.id} 
                                className="border-2 h-5 w-5 flex-shrink-0"
                              />
                              <div className="flex items-center gap-4 flex-1">
                                <div className={`flex-shrink-0 w-12 h-12 rounded-lg flex items-center justify-center font-bold text-lg transition-all shadow-md ${
                                  isSelected
                                    ? 'bg-gradient-to-br from-blue-500 to-purple-600 text-white'
                                    : 'bg-gradient-to-br from-blue-500/20 to-purple-600/20 text-primary'
                                }`}>
                                  {index + 1}
                                </div>
                                <Label htmlFor={quiz.id} className="flex-1 cursor-pointer">
                                  <div className="flex items-center gap-3">
                                    <FileQuestion className={`h-5 w-5 flex-shrink-0 transition-colors ${
                                      isSelected ? 'text-primary' : 'text-muted-foreground'
                                    }`} />
                                    <span className={`font-semibold text-base transition-colors ${
                                      isSelected ? 'text-primary' : 'text-foreground'
                                    }`}>
                                      {quiz.title}
                                    </span>
                                  </div>
                                </Label>
                                {isSelected && (
                                  <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0 animate-in fade-in zoom-in" />
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </RadioGroup>
                  </div>
                </div>

                <Button 
                  onClick={handleQuizSubmit}
                  className="w-full gradient-primary h-12 text-base font-semibold shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!selectedQuiz}
                >
                  {selectedQuiz ? (
                    <>
                      <Zap className="h-5 w-5 mr-2" />
                      <span>Începe Testul</span>
                      <ArrowRight className="h-5 w-5 ml-2" />
                    </>
                  ) : (
                    <span>Selectează un test pentru a continua</span>
                  )}
                </Button>
              </>
            ) : (
              <div className="text-center py-8">
                <div className="relative inline-block mb-4">
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-full blur-2xl" />
                  <div className="relative p-6 rounded-full bg-gradient-to-br from-orange-500/10 to-red-500/10">
                    <FileQuestion className="h-12 w-12 text-muted-foreground mx-auto" />
                  </div>
                </div>
                <p className="text-lg font-semibold mb-2">Nu există chestionare disponibile</p>
                <p className="text-sm text-muted-foreground mb-6">Poți genera un bon fiscal direct</p>
                <Button 
                  onClick={() => setStep('receipt')}
                  className="gradient-primary shadow-lg"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Generează Bon Direct
                </Button>
              </div>
            )}
          </div>
        ) : step === 'questions' ? (
          <div className="space-y-6">
            {/* Progress Bar */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 via-emerald-500/10 to-green-500/10 rounded-xl blur-xl -z-10" />
              <div className="space-y-2 p-4 bg-card/50 rounded-xl border border-green-500/20">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-green-500" />
                    <span className="font-semibold text-muted-foreground">Progres Test</span>
                  </div>
                  <span className="font-bold text-primary text-lg">
                    {Object.keys(answers).length} / {quizQuestions.length}
                  </span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden shadow-inner">
                  <div 
                    className="h-full bg-gradient-to-r from-green-500 via-emerald-500 to-green-600 transition-all duration-500 rounded-full shadow-sm"
                    style={{ width: `${(Object.keys(answers).length / quizQuestions.length) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="max-h-[55vh] overflow-y-auto pr-2 space-y-6">
              {quizQuestions.map((question, index) => {
                const isAnswered = answers[question.id] !== undefined;
                return (
                  <div 
                    key={question.id} 
                    className={`relative space-y-4 p-6 border-2 rounded-xl transition-all ${
                      isAnswered
                        ? 'bg-gradient-to-br from-green-500/5 to-emerald-500/5 border-green-500/30 shadow-lg'
                        : 'bg-card border-border shadow-sm hover:shadow-md'
                    }`}
                  >
                    {isAnswered && (
                      <div className="absolute top-3 right-3">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                      </div>
                    )}
                    <div className="flex items-start gap-4">
                      <div className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center font-bold text-base shadow-md transition-all ${
                        isAnswered
                          ? 'bg-gradient-to-br from-green-500 to-emerald-600 text-white'
                          : 'bg-gradient-to-br from-primary/20 to-primary/10 text-primary'
                      }`}>
                        {index + 1}
                      </div>
                      <Label className="text-lg font-semibold leading-tight flex-1">
                        {question.question_text}
                      </Label>
                    </div>
                    <RadioGroup 
                      value={answers[question.id]?.toString()} 
                      onValueChange={(value) => setAnswers({...answers, [question.id]: parseInt(value)})}
                      className="space-y-3 mt-4"
                    >
                      {question.options?.options?.map((option: string, optIndex: number) => {
                        const isSelected = answers[question.id] === optIndex;
                        return (
                          <div 
                            key={optIndex} 
                            className={`relative group flex items-center space-x-3 p-4 rounded-xl border-2 transition-all cursor-pointer ${
                              isSelected
                                ? 'border-green-500 bg-gradient-to-r from-green-500/10 to-emerald-500/10 shadow-md'
                                : 'border-border hover:border-primary/50 hover:bg-primary/5'
                            }`}
                          >
                            <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm border-2 transition-all ${
                              isSelected
                                ? 'bg-gradient-to-br from-green-500 to-emerald-600 text-white border-green-500'
                                : 'bg-muted border-muted-foreground/30 text-muted-foreground group-hover:border-primary'
                            }`}>
                              {String.fromCharCode(65 + optIndex)}
                            </div>
                            <RadioGroupItem 
                              value={optIndex.toString()} 
                              id={`${question.id}-${optIndex}`} 
                              className="border-2 flex-shrink-0"
                            />
                            <Label 
                              htmlFor={`${question.id}-${optIndex}`} 
                              className={`flex-1 cursor-pointer font-medium transition-colors ${
                                isSelected ? 'text-green-700 dark:text-green-400' : 'text-foreground'
                              }`}
                            >
                              {option}
                            </Label>
                            {isSelected && (
                              <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 animate-in fade-in zoom-in" />
                            )}
                          </div>
                        );
                      })}
                    </RadioGroup>
                  </div>
                );
              })}
            </div>

            <div className="sticky bottom-0 pt-4 bg-background/95 backdrop-blur-sm border-t -mx-6 px-6">
              <Button 
                onClick={handleQuestionsSubmit}
                className="w-full gradient-primary h-12 text-base font-semibold shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={Object.keys(answers).length < quizQuestions.length}
              >
                {Object.keys(answers).length < quizQuestions.length ? (
                  <>
                    <span>Completează toate întrebările ({quizQuestions.length - Object.keys(answers).length} rămase)</span>
                  </>
                ) : (
                  <>
                    <Trophy className="h-5 w-5 mr-2" />
                    <span>Finalizează Testul</span>
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-3">
              <Label>{t('receiptDialog.generateReceiptQuestion')}</Label>
              <RadioGroup value={generateReceipt} onValueChange={(v: any) => setGenerateReceipt(v)}>
                <div className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-accent/50 transition-colors">
                  <RadioGroupItem value="yes" id="yes" />
                  <Label htmlFor="yes" className="flex-1 cursor-pointer">{t('receiptDialog.yesGenerate')}</Label>
                </div>
                <div className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-accent/50 transition-colors">
                  <RadioGroupItem value="no" id="no" />
                  <Label htmlFor="no" className="flex-1 cursor-pointer">{t('receiptDialog.noThanks')}</Label>
                </div>
              </RadioGroup>
            </div>

            {generateReceipt === 'yes' && (
              <>
                <Separator />
                
<div className="space-y-2">
  <Label htmlFor="template">{t('receiptDialog.countryTemplate')}</Label>
  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
    <SelectTrigger id="template">
      <SelectValue />
    </SelectTrigger>
    <SelectContent>
      {Object.values(receiptTemplates).map((template) => (
        <SelectItem key={template.country} value={template.country}>
          <span className="flex items-center gap-2">
            <span>{template.flag}</span>
            <span>{template.name}</span>
            <Badge variant="outline" className="ml-auto">{template.currency}</Badge>
          </span>
        </SelectItem>
      ))}
    </SelectContent>
  </Select>
</div>

                <div className="space-y-2">
                  <Label htmlFor="amount">
                    {t('receiptDialog.amountLabel')} ({receiptTemplates[selectedTemplate].currency})
                  </Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>

                <Button 
                  onClick={handleGenerateReceipt}
                  className="w-full gradient-primary"
                  disabled={isGenerating || !amount}
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      {t('receiptDialog.generating')}
                    </>
                  ) : (
                    t('receiptDialog.generate')
                  )}
                </Button>
              </>
            )}

            {generateReceipt === 'no' && (
              <Button 
                onClick={() => onOpenChange(false)}
                className="w-full"
                variant="outline"
              >
                {t('receiptDialog.close')}
              </Button>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
