import { useEffect, useState } from "react";
import { Bell, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
}

export function AdminNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    loadNotifications();
    
    // Poll for new notifications every 30 seconds
    const interval = setInterval(loadNotifications, 30000);

    return () => {
      clearInterval(interval);
    };
  }, []);

  const loadNotifications = async () => {
    // For now, just return empty array since we don't have notifications API yet
    // TODO: Implement notifications API endpoint
    setNotifications([]);
    setUnreadCount(0);
  };

  const markAsRead = async (id: string) => {
    // TODO: Implement mark as read API
    loadNotifications();
  };

  const dismissNotification = async (id: string) => {
    // TODO: Implement dismiss API
    loadNotifications();
  };

  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2 max-w-md">
      {notifications.filter(n => !n.is_read).slice(0, 3).map((notification) => (
        <Card key={notification.id} className="shadow-lg border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Bell className="h-4 w-4 text-orange-500" />
                  <span className="font-semibold text-sm">
                    {notification.title}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  {notification.message}
                </p>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {notification.type}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {new Date(notification.created_at).toLocaleString('ro-RO')}
                  </span>
                </div>
              </div>
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => markAsRead(notification.id)}
                  className="h-6 w-6 p-0"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
      {unreadCount > 3 && (
        <Card className="shadow-lg">
          <CardContent className="p-3 text-center">
            <p className="text-sm text-muted-foreground">
              +{unreadCount - 3} alte notificări
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

