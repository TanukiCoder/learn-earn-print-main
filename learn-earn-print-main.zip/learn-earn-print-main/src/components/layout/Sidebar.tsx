import { Home, Video, FileQuestion, Receipt, Settings, LogOut, LayoutDashboard, Users, FileVideo, Monitor, Menu, X, Sliders, Bell } from "lucide-react";
import { NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-new";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { NotificationBell } from "@/components/NotificationBell";

export function Sidebar() {
  const { isAdmin, signOut } = useAuth();
  const { t } = useI18n();
  const [open, setOpen] = useState(false);


  const userLinks = [
    { icon: Home, label: t('nav.dashboard'), path: "/dashboard" },
    { icon: Video, label: t('nav.videos'), path: "/videos" },
    { icon: FileQuestion, label: t('nav.quizzes'), path: "/quizzes" },
    { icon: Receipt, label: t('nav.receipts'), path: "/receipts" },
    { icon: Settings, label: t('nav.settings'), path: "/settings" },
  ];

  const adminLinks = [
    { icon: LayoutDashboard, label: t('admin.nav.dashboard') || "Dashboard", path: "/admin" },
    { icon: Users, label: t('admin.nav.users') || "Utilizatori", path: "/admin/users" },
    { icon: Bell, label: t('admin.nav.notifications') || "Notificări", path: "/admin/notifications" },
    { icon: Monitor, label: t('admin.nav.sessions') || "Sesiuni", path: "/admin/sessions" },
    { icon: FileVideo, label: t('admin.nav.videos') || "Videoclipuri", path: "/admin/videos" },
    { icon: FileQuestion, label: t('admin.nav.quizzes') || "Chestionare", path: "/admin/quizzes" },
    { icon: Receipt, label: t('admin.nav.receipts') || "Bonuri", path: "/admin/receipts" },
    { icon: Settings, label: t('admin.nav.receiptSettings') || "Setări Bonuri", path: "/admin/receipt-settings" },
    { icon: Sliders, label: t('admin.nav.appSettings') || "Setări Aplicație", path: "/admin/app-settings" },
  ];

  const links = isAdmin ? adminLinks : userLinks;

  const SidebarContent = () => (
    <>
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h1 className="text-xl md:text-2xl font-bold text-foreground">
            UNICEFO
          </h1>
          {isAdmin && (
            <div className="hidden md:block">
              <NotificationBell />
            </div>
          )}
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {links.map((link) => (
          <NavLink
            key={link.path}
            to={link.path}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all",
                isActive
                  ? "bg-primary text-primary-foreground shadow-glow"
                  : "hover:bg-secondary text-muted-foreground hover:text-foreground"
              )
            }
          >
            <link.icon className="h-5 w-5" />
            <span className="font-medium">{link.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-border">
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground"
          onClick={signOut}
        >
          <LogOut className="h-5 w-5" />
          <span>{t('nav.logout')}</span>
        </Button>
      </div>
    </>
  );

  return (
    <>
      {isAdmin ? (
        /* Admin mobile menu - hamburger in top left */
        <>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden fixed top-4 left-4 z-50 bg-background/95 backdrop-blur-lg border border-border shadow-lg"
              >
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64">
              <div className="h-full gradient-card flex flex-col">
                <SidebarContent />
              </div>
            </SheetContent>
          </Sheet>
          
          {/* Notification bell for mobile admin */}
          <div className="md:hidden fixed top-4 right-4 z-50">
            <NotificationBell />
          </div>
        </>
      ) : (
        /* User mobile navigation - bottom centered */
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-lg border-t border-border shadow-lg">
          <div className="flex justify-center items-center h-16 px-2 gap-2 max-w-md mx-auto">
            {links.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  cn(
                    "flex flex-col items-center justify-center gap-1 px-3 py-2 rounded-lg transition-all flex-1 max-w-[80px]",
                    isActive
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground"
                  )
                }
              >
                <link.icon className="h-5 w-5" />
                <span className="text-[10px] font-medium truncate w-full text-center">{link.label}</span>
              </NavLink>
            ))}
          </div>
        </nav>
      )}

      {/* Desktop sidebar */}
      <aside className="hidden md:flex w-64 lg:w-64 h-screen gradient-card border-r border-border flex-col">
        <SidebarContent />
      </aside>
    </>
  );
}
