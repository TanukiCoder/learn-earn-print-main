import { Sidebar } from "./Sidebar";
import { useI18n } from "@/lib/i18n";
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { Watermark } from "@/components/Watermark";
import { AdminNotifications } from "@/components/AdminNotifications";
import { useAuth } from "@/lib/auth-new";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const getPageIdFromPath = (pathname: string): string => {
  if (pathname === '/dashboard') return 'dashboard';
  if (pathname === '/videos') return 'videos';
  if (pathname.startsWith('/video/')) return 'video-watch';
  if (pathname === '/quizzes') return 'quizzes';
  if (pathname === '/receipts') return 'receipts';
  if (pathname === '/settings') return 'settings';
  return '';
};

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { language } = useI18n();
  const { isAdmin } = useAuth();
  const location = useLocation();
  const [logoUrl, setLogoUrl] = useState<string>("");
  const [showLogo, setShowLogo] = useState(false);

  useEffect(() => {
    const savedLogos = localStorage.getItem('logosByLanguage');
    const currentPageId = getPageIdFromPath(location.pathname);
    
    if (savedLogos) {
      const logos = JSON.parse(savedLogos);
      const logoData = logos[language];
      
      if (logoData?.url && logoData?.pages?.includes(currentPageId)) {
        setLogoUrl(logoData.url);
        setShowLogo(true);
      } else {
        // Fallback to default logo from public folder
        setLogoUrl('/newlolgo.jpg');
        setShowLogo(true);
      }
    } else {
      // Default logo from public folder
      setLogoUrl('/newlolgo.jpg');
      setShowLogo(true);
    }
  }, [language, location.pathname]);

  return (
    <div className="flex min-h-screen w-full relative">
      <Watermark />
      <Sidebar />
      <main className={`flex-1 w-full md:w-auto p-4 md:p-6 lg:p-8 overflow-auto relative z-10 ${
        isAdmin ? 'pt-16 md:pt-6' : 'pb-20 md:pb-4'
      }`}>
        {showLogo && logoUrl && (
          <div className="flex justify-center mb-4 md:mb-6">
            <img 
              src={logoUrl} 
              alt="Logo" 
              className="h-16 md:h-20 lg:h-24 w-auto object-contain rounded-xl shadow-lg"
            />
          </div>
        )}
        <div className="max-w-full overflow-x-hidden">
          {children}
        </div>
      </main>
      {isAdmin && <AdminNotifications />}
    </div>
  );
}
