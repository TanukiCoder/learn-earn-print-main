import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";

interface WatermarkProps {
  text?: string;
  opacity?: number;
}

export function Watermark({ text, opacity = 0.03 }: WatermarkProps) {
  const { language } = useI18n();
  const [watermarkText, setWatermarkText] = useState(text || "UNICEFO");

  useEffect(() => {
    // Load watermark text from localStorage or use default
    const saved = localStorage.getItem('watermarkText');
    if (saved) {
      setWatermarkText(saved);
    } else if (text) {
      setWatermarkText(text);
    }
  }, [text, language]);

  return (
    <div
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      style={{ opacity }}
    >
      <div
        className="absolute inset-0 flex items-center justify-center"
        style={{
          transform: 'rotate(-45deg)',
          transformOrigin: 'center',
        }}
      >
        <div className="grid grid-cols-3 gap-32 w-full h-full">
          {Array.from({ length: 15 }).map((_, i) => (
            <div
              key={i}
              className="text-6xl font-bold text-foreground select-none whitespace-nowrap"
              style={{
                opacity: opacity * 0.5,
                fontSize: 'clamp(2rem, 8vw, 6rem)',
              }}
            >
              {watermarkText}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
