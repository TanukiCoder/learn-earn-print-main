import { useRef, useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Play, Pause, Volume2, VolumeX, Maximize } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

interface VideoPlayerProps {
  videoUrl: string;
  onProgress: (percentage: number) => void;
  onComplete: () => void;
  initialProgress?: number;
}

// Helper function to detect and convert YouTube URL to embed format
const getYouTubeEmbedUrl = (url: string): string | null => {
  const youtubeRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  const match = url.match(youtubeRegex);
  if (match && match[1]) {
    return `https://www.youtube.com/embed/${match[1]}?modestbranding=1&rel=0&showinfo=0&autohide=1&controls=1&enablejsapi=1`;
  }
  return null;
};

export function VideoPlayer({ videoUrl, onProgress, onComplete, initialProgress = 0 }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [hasCompleted, setHasCompleted] = useState(false);
  const [isYouTube, setIsYouTube] = useState(false);
  const [youtubeEmbedUrl, setYoutubeEmbedUrl] = useState<string | null>(null);

  // Check if URL is YouTube on mount
  useEffect(() => {
    const embedUrl = getYouTubeEmbedUrl(videoUrl);
    if (embedUrl) {
      setIsYouTube(true);
      setYoutubeEmbedUrl(embedUrl);
    } else {
      setIsYouTube(false);
      setYoutubeEmbedUrl(null);
    }
  }, [videoUrl]);

  // Track progress for YouTube (simplified - marks as complete when viewed)
  useEffect(() => {
    if (isYouTube && !hasCompleted) {
      // For YouTube, we'll mark as complete after a delay (simulate watching)
      const timer = setTimeout(() => {
        onProgress(100);
        setHasCompleted(true);
        onComplete();
      }, 30000); // 30 seconds

      return () => clearTimeout(timer);
    }
  }, [isYouTube, hasCompleted, onProgress, onComplete]);

  useEffect(() => {
    if (isYouTube) return; // Skip for YouTube
    
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      const current = video.currentTime;
      const total = video.duration;
      
      setCurrentTime(current);
      
      if (total > 0) {
        const percentage = (current / total) * 100;
        onProgress(Math.min(percentage, 100));
        
        // Video completed
        if (percentage >= 99 && !hasCompleted) {
          setHasCompleted(true);
          onComplete();
        }
      }
    };

    const handleLoadedMetadata = () => {
      setDuration(video.duration);
      
      // Set initial progress
      if (initialProgress > 0 && initialProgress < 100) {
        video.currentTime = (initialProgress / 100) * video.duration;
      }
    };

    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [onProgress, onComplete, initialProgress, hasCompleted, isYouTube]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleSeek = (value: number[]) => {
    const video = videoRef.current;
    if (!video) return;

    const newTime = (value[0] / 100) * duration;
    video.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0] / 100;
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setVolume(newVolume);
      setIsMuted(newVolume === 0);
    }
  };

  const toggleFullscreen = () => {
    if (videoRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        videoRef.current.requestFullscreen();
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="overflow-hidden shadow-card">
      <div className="relative bg-black aspect-video">
        {isYouTube && youtubeEmbedUrl ? (
          <iframe
            ref={iframeRef}
            src={youtubeEmbedUrl}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        ) : (
          <>
            <video
              ref={videoRef}
              src={videoUrl}
              className="w-full h-full"
              onContextMenu={(e) => e.preventDefault()}
              controlsList="nodownload"
            />
            
            {/* Custom Controls - Only for non-YouTube videos */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <div className="space-y-2">
                {/* Progress Bar */}
                <Slider
                  value={[duration > 0 ? (currentTime / duration) * 100 : 0]}
                  onValueChange={handleSeek}
                  max={100}
                  step={0.1}
                  className="cursor-pointer"
                />
                
                {/* Controls */}
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={togglePlay}
                      className="text-white hover:bg-white/20"
                    >
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={toggleMute}
                        className="text-white hover:bg-white/20"
                      >
                        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                      </Button>
                      
                      <Slider
                        value={[volume * 100]}
                        onValueChange={handleVolumeChange}
                        max={100}
                        step={1}
                        className="w-20"
                      />
                    </div>
                    
                    <span className="text-sm text-white font-mono">
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </span>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleFullscreen}
                    className="text-white hover:bg-white/20"
                  >
                    <Maximize className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </Card>
  );
}
