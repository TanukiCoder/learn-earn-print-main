import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, Receipt as ReceiptIcon, Plus } from "lucide-react";
import api from "@/lib/api-client";
import { toast } from "sonner";
import jsPDF from "jspdf";
import { receiptTemplates } from "@/lib/receiptTemplates";
import { useI18n } from "@/lib/i18n";

export default function Receipts() {
  const { t, language } = useI18n();
  const [receipts, setReceipts] = useState<any[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  
  // New receipt form state
  const [selectedVideo, setSelectedVideo] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('romania');
  const [amount, setAmount] = useState('');

  useEffect(() => {
    loadReceipts();
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const response = await api.videos.getAll();
      setVideos(response.data || []);
    } catch (error) {
      console.error('Error loading videos:', error);
    }
  };

  const loadReceipts = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      if (!user.id) return;

      const response = await api.receipts.getAll();
      const receiptsData = response.data || [];
      
      // Transform to match expected format
      const formattedReceipts = receiptsData.map((receipt: any) => ({
        ...receipt,
        videos: receipt.video_title ? { title: receipt.video_title } : null
      }));
      
      setReceipts(formattedReceipts);
    } catch (error) {
      console.error('Error loading receipts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const generateReceiptNumber = async () => {
    try {
      const response = await api.receipts.getNextNumber();
      return response.data.receiptNumber;
    } catch (error) {
      console.error('Error getting next receipt number:', error);
      // Fallback to random number if API fails
      const year = new Date().getFullYear();
      const random = Math.floor(Math.random() * 999999);
      return `BON-${year}-${String(random).padStart(6, '0')}`;
    }
  };

  const handleCreateReceipt = async () => {
    if (!selectedVideo || !amount || parseFloat(amount) <= 0) {
      toast.error("Completează toate câmpurile!");
      return;
    }

    setIsGenerating(true);

    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      if (!user.id) throw new Error("Nu ești autentificat");

      const videoData = videos.find(v => v.id === selectedVideo);
      
      // Load receipt settings
      const settingsResponse = await api.receipts.getSettings();
      const settings: any = settingsResponse.data || {};

      const receiptNumber = await generateReceiptNumber();
      const template = receiptTemplates[selectedTemplate];
      
      // Create PDF with proper settings for receipt
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [72, 200],
        compress: true
      });

      // Set font to monospace for better alignment
      pdf.setFont('courier', 'normal');
      
      const receiptData = {
        receiptNumber,
        date: new Date().toLocaleDateString('ro-RO', { 
          day: '2-digit', 
          month: '2-digit', 
          year: 'numeric' 
        }),
        time: new Date().toLocaleTimeString('ro-RO', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: false
        }),
        userName: user.full_name || 'Participant',
        videoTitle: videoData?.title || 'Video',
        amount: parseFloat(amount).toFixed(2),
        settings: { ...settings, user_language: language }
      };

      let y = 8;
      const maxWidth = 67; // Increased for better text fitting
      
      // Header - centered, larger font
      pdf.setFontSize(11);
      pdf.setFont('courier', 'bold');
      const headerLines = template.headerFormat({...settings, receiptNumber});
      headerLines.forEach((line: string) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---') || line.includes('─') || line.includes('━')) {
          // Draw line separator - use simple dashes
          pdf.setFontSize(8);
          pdf.setFont('courier', 'normal');
          // Replace Unicode dashes with simple dashes
          const cleanLine = line.replace(/[─━]/g, '-').replace(/%/g, '-');
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 30)), 36, y, { align: 'center' });
          y += 4;
          pdf.setFontSize(11);
          pdf.setFont('courier', 'bold');
        } else {
          // Clean any percent signs or Unicode characters
          const cleanLine = line.replace(/%/g, '').trim();
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 28)), 36, y, { align: 'center' });
          y += 4;
        }
      });
      
      y += 2;
      
      // Details - left aligned, smaller font
      pdf.setFontSize(8);
      pdf.setFont('courier', 'normal');
      const details = template.detailsFormat(receiptData);
      const totalLines = details.length;
      details.forEach((line: string, index: number) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---')) {
          const lineLength = Math.min(line.length, 30);
          pdf.text(line.substring(0, lineLength), 5, y, { maxWidth: maxWidth });
          y += 4;
        } else {
          // Use smaller font for last few lines if they're footer messages
          const isFooterLine = index >= totalLines - 5 && !line.includes('Bon Nr:') && !line.includes('Data:') && !line.includes('Client:') && !line.includes('Nº:') && !line.includes('Nr:') && !line.includes('Fecha:') && !line.includes('Date:') && !line.includes('Datum:');
          const isLastLine = index === totalLines - 1;
          // Check for footer messages in different languages
          const isParticipareLine = line.includes('Mulțumim!') || 
                                   line.includes('Multumim pentru participare') || 
                                   line.includes('Gracias por su participación') ||
                                   line.includes('Grazie per la partecipazione') ||
                                   line.includes('Merci pour votre participation') ||
                                   line.includes('Vielen Dank für Ihre Teilnahme');
          
          if (isFooterLine && !isLastLine && !isParticipareLine) {
            pdf.setFontSize(6.5); // Smaller for footer lines
          }
          if (isLastLine || isParticipareLine) {
            pdf.setFontSize(4); // Very small for last line and footer messages to ensure it fits
          }
          
          // For footer messages, use maximum width and ensure strict left alignment
          if (isParticipareLine) {
            // Write directly with maximum width, left aligned
            pdf.text(line.trim(), 5, y, { maxWidth: 75, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else if (isLastLine) {
            // For other last lines
            const textMaxWidth = maxWidth + 15;
            pdf.text(line.trim(), 5, y, { maxWidth: textMaxWidth, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else {
            // Regular lines
            const textMaxWidth = maxWidth;
            const lines = pdf.splitTextToSize(line, textMaxWidth);
            lines.forEach((textLine: string) => {
              pdf.text(textLine, 5, y, { 
                maxWidth: textMaxWidth,
                align: 'left'
              });
              y += 3.5;
            });
            if (isFooterLine) {
              pdf.setFontSize(8); // Reset font size
            }
          }
        }
      });
      
      y += 3;

      // Footer
      if (selectedTemplate === 'franta' && settings?.france_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        // Split by \n and also handle escaped newlines
        const footerLines = settings.france_footer_message.split(/\\n|\n/).filter(line => line.trim());
        footerLines.forEach((line: string) => {
          pdf.text(line.trim(), 5, y, { maxWidth: 75, align: 'left' });
          y += 4;
        });
      } else if (selectedTemplate === 'italia' && settings?.italy_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        pdf.text(settings.italy_footer_message.trim(), 5, y, { maxWidth: 75, align: 'left' });
        y += 4;
      } else if (selectedTemplate === 'spania' && settings?.spain_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        pdf.text(settings.spain_footer_message.trim(), 5, y, { maxWidth: 75, align: 'left' });
        y += 4;
      }
      // Note: footer_text is not added here as each template has its own language-specific footer

      // Save to database
      await api.receipts.create({
        video_id: selectedVideo,
        amount: parseFloat(amount),
        template_country: selectedTemplate,
      });

      // Download PDF
      pdf.save(`${receiptNumber}.pdf`);

      toast.success("Bon generat cu succes! 🎉");
      
      // Reset form
      setShowCreateDialog(false);
      setSelectedVideo('');
      setAmount('');
      setSelectedTemplate('romania');
      
      // Reload receipts to update the total amount
      await loadReceipts();
    } catch (error: any) {
      console.error('Error generating receipt:', error);
      toast.error(error.message || "Eroare la generarea bonului");
    } finally {
      setIsGenerating(false);
    }
  };

  const regeneratePDF = async (receipt: any) => {
    try {
      // Load receipt settings
      const settingsResponse = await api.receipts.getSettings();
      const settings: any = settingsResponse.data || {};

      const template = receiptTemplates[receipt.template_country || 'romania'] || receiptTemplates.romania;
      
      // Create PDF with proper settings for receipt
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [72, 200],
        compress: true
      });

      // Set font to monospace for better alignment
      pdf.setFont('courier', 'normal');
      
      // Get date format based on template
      const dateFormat = receipt.template_country === 'franta' ? 'fr-FR' : 
                        receipt.template_country === 'italia' ? 'it-IT' : 
                        receipt.template_country === 'spania' ? 'es-ES' : 
                        receipt.template_country === 'austria' ? 'de-AT' :
                        receipt.template_country === 'germania' ? 'de-DE' : 'ro-RO';
      
      const receiptData = {
        receiptNumber: receipt.receipt_number,
        date: new Date(receipt.generated_at).toLocaleDateString(dateFormat, { 
          day: '2-digit', 
          month: '2-digit', 
          year: 'numeric' 
        }),
        time: new Date(receipt.generated_at).toLocaleTimeString(dateFormat, { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: false
        }),
        userName: receipt.user_name,
        videoTitle: receipt.videos?.title || '',
        amount: parseFloat(receipt.amount).toFixed(2),
        settings: { ...settings, user_language: language }
      };

      let y = 8;
      const maxWidth = 67; // 72mm - 5mm margins
      
      // Header - centered, larger font
      pdf.setFontSize(11);
      pdf.setFont('courier', 'bold');
      const headerLines = template.headerFormat({...settings, receiptNumber: receipt.receipt_number});
      headerLines.forEach((line: string) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---') || line.includes('─') || line.includes('━')) {
          // Draw line separator - use simple dashes
          pdf.setFontSize(8);
          pdf.setFont('courier', 'normal');
          // Replace Unicode dashes with simple dashes
          const cleanLine = line.replace(/[─━]/g, '-').replace(/%/g, '-');
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 30)), 36, y, { align: 'center' });
          y += 4;
          pdf.setFontSize(11);
          pdf.setFont('courier', 'bold');
        } else {
          // Clean any percent signs or Unicode characters
          const cleanLine = line.replace(/%/g, '').trim();
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 28)), 36, y, { align: 'center' });
          y += 4;
        }
      });
      
      y += 2;
      
      // Details - left aligned, smaller font
      pdf.setFontSize(8);
      pdf.setFont('courier', 'normal');
      const details = template.detailsFormat(receiptData);
      const totalLines = details.length;
      details.forEach((line: string, index: number) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---')) {
          const lineLength = Math.min(line.length, 30);
          pdf.text(line.substring(0, lineLength), 5, y, { maxWidth: maxWidth });
          y += 4;
        } else {
          // Use smaller font for last few lines if they're footer messages
          const isFooterLine = index >= totalLines - 5 && !line.includes('Bon Nr:') && !line.includes('Data:') && !line.includes('Client:') && !line.includes('Nº:') && !line.includes('Nr:') && !line.includes('Fecha:') && !line.includes('Date:') && !line.includes('Datum:');
          const isLastLine = index === totalLines - 1;
          // Check for footer messages in different languages
          const isParticipareLine = line.includes('Mulțumim!') || 
                                   line.includes('Multumim pentru participare') || 
                                   line.includes('Gracias por su participación') ||
                                   line.includes('Grazie per la partecipazione') ||
                                   line.includes('Merci pour votre participation') ||
                                   line.includes('Vielen Dank für Ihre Teilnahme');
          
          if (isFooterLine && !isLastLine && !isParticipareLine) {
            pdf.setFontSize(6.5); // Smaller for footer lines
          }
          if (isLastLine || isParticipareLine) {
            pdf.setFontSize(4); // Very small for last line and footer messages to ensure it fits
          }
          
          // For footer messages, use maximum width and ensure strict left alignment
          if (isParticipareLine) {
            // Write directly with maximum width, left aligned
            pdf.text(line.trim(), 5, y, { maxWidth: 75, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else if (isLastLine) {
            // For other last lines
            const textMaxWidth = maxWidth + 15;
            pdf.text(line.trim(), 5, y, { maxWidth: textMaxWidth, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else {
            // Regular lines
            const textMaxWidth = maxWidth;
            const lines = pdf.splitTextToSize(line, textMaxWidth);
            lines.forEach((textLine: string) => {
              pdf.text(textLine, 5, y, { 
                maxWidth: textMaxWidth,
                align: 'left'
              });
              y += 3.5;
            });
            if (isFooterLine) {
              pdf.setFontSize(8); // Reset font size
            }
          }
        }
      });
      
      y += 3;

      // Footer
      if (receipt.template_country === 'franta' && settings?.france_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        // Split by \n and also handle escaped newlines
        const footerLines = settings.france_footer_message.split(/\\n|\n/).filter(line => line.trim());
        footerLines.forEach((line: string) => {
          pdf.text(line.trim(), 5, y, { maxWidth: 75, align: 'left' });
          y += 4;
        });
      } else if (receipt.template_country === 'italia' && settings?.italy_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        pdf.text(settings.italy_footer_message.trim(), 5, y, { maxWidth: 75, align: 'left' });
        y += 4;
      } else if (receipt.template_country === 'spania' && settings?.spain_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        pdf.text(settings.spain_footer_message.trim(), 5, y, { maxWidth: 75, align: 'left' });
        y += 4;
      }
      // Note: footer_text is not added here as each template has its own language-specific footer
      
      pdf.save(`bon-${receipt.receipt_number}.pdf`);
      toast.success('Bon descărcat cu succes');
    } catch (error: any) {
      console.error('Error regenerating PDF:', error);
      toast.error('Eroare la generarea bonului');
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ReceiptIcon className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-4xl font-bold">{t('receipts.title')}</h1>
              <p className="text-muted-foreground">
                {t('receipts.description')}
              </p>
            </div>
          </div>
          
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="gradient-primary">
                <Plus className="h-4 w-4 mr-2" />
                {t('receipts.generate')}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <ReceiptIcon className="h-5 w-5 text-primary" />
                  Generează Bon Fiscal
                </DialogTitle>
                <DialogDescription>
                  Completează detaliile pentru a genera un bon fiscal nou
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="video">Videoclip</Label>
                  <Select value={selectedVideo} onValueChange={setSelectedVideo}>
                    <SelectTrigger id="video">
                      <SelectValue placeholder="Selectează un videoclip" />
                    </SelectTrigger>
                    <SelectContent>
                      {videos.map((video) => (
                        <SelectItem key={video.id} value={video.id}>
                          {video.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="template">Țară Template</Label>
                  <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                    <SelectTrigger id="template">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.values(receiptTemplates).map((template) => (
                        <SelectItem key={template.country} value={template.country}>
                          {template.flag} {template.name} ({template.currency})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="amount">
                    {t('receipts.amount')} ({receiptTemplates[selectedTemplate].currency})
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>

                <Button 
                  onClick={handleCreateReceipt}
                  className="w-full gradient-primary"
                  disabled={isGenerating || !selectedVideo || !amount}
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Se generează...
                    </>
                  ) : (
                    'Generează Bon'
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ReceiptIcon className="h-5 w-5" />
              {t('receipts.allReceipts')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : receipts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {t('receipts.noReceiptsYet')}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('receipts.receiptNumber')}</TableHead>
                    <TableHead>{t('receipts.video')}</TableHead>
                    <TableHead>{t('receipts.template')}</TableHead>
                    <TableHead>{t('receipts.amount')}</TableHead>
                    <TableHead>{t('receipts.date')}</TableHead>
                    <TableHead className="text-right">{t('receipts.actions')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {receipts.map((receipt) => (
                    <TableRow key={receipt.id}>
                      <TableCell className="font-mono">{receipt.receipt_number}</TableCell>
                      <TableCell>{receipt.videos?.title}</TableCell>
                      <TableCell>
                        {receiptTemplates[receipt.template_country]?.flag} {receiptTemplates[receipt.template_country]?.name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="font-mono text-black dark:text-white">
                          {parseFloat(receipt.amount).toFixed(2)} {receiptTemplates[receipt.template_country]?.currency}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(receipt.generated_at).toLocaleDateString('ro-RO')}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => regeneratePDF(receipt)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {receipts.length > 0 && (
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>{t('receipts.totalAmount')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-black dark:text-white">
                {receipts.reduce((sum, r) => {
                  const amount = typeof r.amount === 'string' ? parseFloat(r.amount) : r.amount;
                  return sum + (isNaN(amount) ? 0 : amount);
                }, 0).toFixed(2)} RON
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
