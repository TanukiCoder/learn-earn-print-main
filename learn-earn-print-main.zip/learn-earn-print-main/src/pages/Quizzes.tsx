import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import api from "@/lib/api-client";
import { FileQuestion, Video, CheckCircle2, Plus, X, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth-new";

interface QuizWithVideo {
  id: string;
  title: string;
  video_id: string;
  created_by?: string;
  video: {
    title: string;
  };
  submissions?: Array<{
    id: string;
    submitted_at: string;
  }>;
}

interface QuestionForm {
  question_text: string;
  options: string[];
  correct_answer: number;
}

export default function Quizzes() {
  const { t, language } = useI18n();
  const { isAdmin } = useAuth();
  const [quizzes, setQuizzes] = useState<QuizWithVideo[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [canCreateQuizzes, setCanCreateQuizzes] = useState(false);
  const navigate = useNavigate();

  // Create quiz form
  const [quizTitle, setQuizTitle] = useState('');
  const [selectedVideo, setSelectedVideo] = useState('');
  const [questions, setQuestions] = useState<QuestionForm[]>([{
    question_text: '',
    options: ['', '', '', ''],
    correct_answer: 0
  }]);

  useEffect(() => {
    loadQuizzes();
    loadVideos();
    loadCurrentUser();
    checkQuizCreationPermission();
  }, []);

  const checkQuizCreationPermission = async () => {
    try {
      // Admins can always create quizzes
      if (isAdmin) {
        setCanCreateQuizzes(true);
        return;
      }

      // Check setting for regular users
      const response = await api.appSettings.getByKey('users_can_create_quizzes');
      setCanCreateQuizzes(response.data.setting_value === 'true');
    } catch (error) {
      console.error('Error checking quiz creation permission:', error);
      setCanCreateQuizzes(false);
    }
  };

  const loadCurrentUser = async () => {
    try {
      const response = await api.auth.getCurrentUser();
      setCurrentUserId(response.data?.id || null);
    } catch (error) {
      console.error('Error loading current user:', error);
      setCurrentUserId(null);
    }
  };

  const loadVideos = async () => {
    try {
      const response = await api.videos.getAll();
      setVideos(response.data || []);
    } catch (error) {
      console.error('Error loading videos:', error);
      setVideos([]);
    }
  };

  const loadQuizzes = async () => {
    try {
      const userResponse = await api.auth.getCurrentUser();
      const user = userResponse.data;
      if (!user) return;

      // Get all videos first to map video titles
      const videosResponse = await api.videos.getAll();
      const videosMap = (videosResponse.data || []).reduce((acc: any, video: any) => {
        acc[video.id] = video;
        return acc;
      }, {});

      // Get all quizzes - we'll need to fetch them differently since we don't have a direct endpoint
      // For now, we'll get quizzes by fetching all videos and their quizzes
      const allQuizzes: any[] = [];
      for (const video of videosResponse.data || []) {
        try {
          const quizzesResponse = await api.quizzes.getByVideoId(video.id);
          const videoQuizzes = (quizzesResponse.data || []).map((quiz: any) => ({
            ...quiz,
            video: video,
            submissions: quiz.submissions || []
          }));
          allQuizzes.push(...videoQuizzes);
        } catch (error) {
          // Video might not have quizzes, continue
        }
      }

      setQuizzes(allQuizzes);
    } catch (error) {
      console.error('Error loading quizzes:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addQuestion = () => {
    setQuestions([...questions, {
      question_text: '',
      options: ['', '', '', ''],
      correct_answer: 0
    }]);
  };

  const removeQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const updateQuestion = (index: number, field: keyof QuestionForm, value: any) => {
    const newQuestions = [...questions];
    newQuestions[index] = { ...newQuestions[index], [field]: value };
    setQuestions(newQuestions);
  };

  const updateOption = (qIndex: number, oIndex: number, value: string) => {
    const newQuestions = [...questions];
    newQuestions[qIndex].options[oIndex] = value;
    setQuestions(newQuestions);
  };

  const handleCreateQuiz = async () => {
    if (!quizTitle || !selectedVideo) {
      toast.error(t('quizzes.fillTitleAndVideo') || 'Completează titlul și selectează un videoclip!');
      return;
    }

    if (questions.length === 0) {
      toast.error(t('quizzes.addAtLeastOne'));
      return;
    }

    // Validate all questions
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.question_text.trim()) {
        toast.error(t('quizzes.questionEmpty') || `Întrebarea ${i + 1} este goală!`);
        return;
      }
      if (q.options.some(opt => !opt.trim())) {
        toast.error(t('quizzes.allOptionsRequired') || `Toate opțiunile pentru întrebarea ${i + 1} trebuie completate!`);
        return;
      }
    }

    setIsCreating(true);

    try {
      const userResponse = await api.auth.getCurrentUser();
      const user = userResponse.data;
      if (!user) throw new Error(t('quizzes.notAuthenticated') || 'Nu ești autentificat');

      // Create quiz with questions
      const questionsData = questions.map((q, index) => ({
        question_text: q.question_text,
        question_type: 'radio',
        options: {
          options: q.options,
          correct: q.correct_answer
        },
        order_index: index
      }));

      await api.quizzes.create({
        title: quizTitle,
        video_id: selectedVideo,
        questions: questionsData
      });

      toast.success(t('quizzes.successCreated') || 'Chestionar creat cu succes! 🎉');
      setShowCreateDialog(false);
      setQuizTitle('');
      setSelectedVideo('');
      setQuestions([{
        question_text: '',
        options: ['', '', '', ''],
        correct_answer: 0
      }]);
      loadQuizzes();
    } catch (error: any) {
      console.error('Error creating quiz:', error);
      toast.error(error.message || t('quizzes.errorCreating'));
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteQuiz = async (quizId: string) => {
    if (!confirm(t('quizzes.confirmDelete'))) return;

    try {
      await api.quizzes.delete(quizId);

      toast.success(t('quizzes.successDeleted') || 'Chestionar șters cu succes!');
      loadQuizzes();
    } catch (error: any) {
      console.error('Error deleting quiz:', error);
      toast.error(error.message || t('quizzes.errorDeleting'));
    }
  };

  const handleDeleteSubmission = async (submissionId: string) => {
    if (!confirm(t('quizzes.confirmDeleteSubmission'))) return;

    try {
      // Note: We need to add a delete submission endpoint to the API
      // For now, we'll use a workaround
      await api.quizzes.submit(submissionId, { delete: true });

      toast.success(t('quizzes.successDeletedSubmission') || 'Submisiune ștearsă cu succes!');
      loadQuizzes();
    } catch (error: any) {
      console.error('Error deleting submission:', error);
      toast.error(error.message || t('quizzes.errorDeletingSubmission'));
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center gap-3">
          <FileQuestion className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-4xl font-bold">{t('quizzes.title')}</h1>
            <p className="text-muted-foreground">
              {t('quizzes.description')}
            </p>
          </div>
        </div>

        {canCreateQuizzes && (
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button className="gradient-primary">
                <Plus className="h-4 w-4 mr-2" />
                {t('quizzes.create')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <FileQuestion className="h-5 w-5 text-primary" />
                  {t('quizzes.createTitle')}
                </DialogTitle>
                <DialogDescription>
                  {t('quizzes.createDescription')}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="quiz-title">{t('quizzes.quizTitle')}</Label>
                    <Input
                      id="quiz-title"
                      placeholder={t('quizzes.quizTitlePlaceholder')}
                      value={quizTitle}
                      onChange={(e) => setQuizTitle(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="video">{t('quizzes.selectVideo')}</Label>
                    <Select value={selectedVideo} onValueChange={setSelectedVideo}>
                      <SelectTrigger id="video">
                        <SelectValue placeholder={t('quizzes.selectVideoPlaceholder')} />
                      </SelectTrigger>
                      <SelectContent>
                        {videos.map((video) => (
                          <SelectItem key={video.id} value={video.id}>
                            {video.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-semibold">{t('quizzes.questionsLabel')}</Label>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addQuestion}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      {t('quizzes.addQuestion')}
                    </Button>
                  </div>

                  {questions.map((question, qIndex) => (
                    <Card key={qIndex} className="p-5 border-2 shadow-sm hover:shadow-md transition-shadow">
                      <div className="space-y-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <span className="text-sm font-bold text-primary">{qIndex + 1}</span>
                            </div>
                            <Label className="text-base font-semibold">{t('quizzes.question')} {qIndex + 1}</Label>
                          </div>
                          {questions.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeQuestion(qIndex)}
                              className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>

                        <Input
                          placeholder={t('quizzes.enterQuestion')}
                          value={question.question_text}
                          onChange={(e) => updateQuestion(qIndex, 'question_text', e.target.value)}
                          className="text-base"
                        />

                        <div className="space-y-3 pt-2">
                          <Label className="text-sm font-semibold">{t('quizzes.answerOptions')}</Label>
                          {question.options.map((option, oIndex) => (
                            <div key={oIndex} className="flex items-center gap-3 p-3 rounded-lg border hover:border-primary hover:bg-primary/5 transition-all">
                              <div className="flex-shrink-0 w-6 h-6 rounded-full border-2 border-muted-foreground/30 flex items-center justify-center">
                                <span className="text-xs font-semibold text-muted-foreground">{String.fromCharCode(65 + oIndex)}</span>
                              </div>
                              <Input
                                placeholder={`${t('quizzes.option')} ${oIndex + 1}`}
                                value={option}
                                onChange={(e) => updateOption(qIndex, oIndex, e.target.value)}
                                className="flex-1"
                              />
                              <input
                                type="radio"
                                name={`correct-${qIndex}`}
                                checked={question.correct_answer === oIndex}
                                onChange={() => updateQuestion(qIndex, 'correct_answer', oIndex)}
                                className="w-5 h-5 cursor-pointer accent-primary"
                                title={t('quizzes.correct')}
                              />
                            </div>
                          ))}
                          <p className="text-xs text-muted-foreground pl-11">
                            💡 {t('quizzes.selectRadioHint')}
                          </p>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>

                <Button
                  onClick={handleCreateQuiz}
                  className="w-full gradient-primary"
                  disabled={isCreating}
                >
                  {isCreating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      {t('quizzes.creating')}
                    </>
                  ) : (
                    t('quizzes.create')
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {quizzes.length === 0 ? (
          <Card className="shadow-card">
            <CardContent className="py-12 text-center">
              <FileQuestion className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg text-muted-foreground">
                {t('quizzes.noQuizzesAvailable')}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                {t('quizzes.createFirst')}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map((quiz) => {
              const specialTitles = ['test de evaluare', 'chestionar final'];
              const isSpecial = specialTitles.includes(quiz.title?.trim().toLowerCase());
              const canDelete = isAdmin || quiz.created_by === currentUserId || isSpecial;
              
              return (
                <Card key={quiz.id} className="shadow-card hover:shadow-glow transition-all border-2 hover:border-primary/50 flex flex-col h-full">
                  <CardHeader className="pb-3 flex-shrink-0">
                    <CardTitle className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <FileQuestion className="h-5 w-5 text-primary" />
                        </div>
                        <span className="line-clamp-2 text-lg font-semibold leading-tight">{quiz.title}</span>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {quiz.submissions && quiz.submissions.length > 0 && (
                          <Badge variant="secondary" className="flex-shrink-0 font-semibold px-2.5">
                            {quiz.submissions.length}x
                          </Badge>
                        )}
                        {canDelete && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteQuiz(quiz.id)}
                            className="flex-shrink-0 hover:bg-destructive/10"
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        )}
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col space-y-4">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 p-2 rounded-lg">
                        <Video className="h-4 w-4 flex-shrink-0" />
                        <span className="line-clamp-1 font-medium">
                          {quiz.video.title === 'Curs Demonstrativ: Introducere în Platform' 
                            ? t('quizzes.videoTitle.demo') 
                            : quiz.video.title}
                        </span>
                      </div>

                      {quiz.submissions && quiz.submissions.length > 0 && (
                        <div className="space-y-2">
                          <Label className="text-xs text-muted-foreground">{t('quizzes.completionHistory')}:</Label>
                          <div className="space-y-1 max-h-32 overflow-y-auto">
                            {quiz.submissions.map((sub) => (
                              <div key={sub.id} className="flex items-center justify-between text-xs bg-muted/50 rounded px-2 py-1">
                                <span>{new Date(sub.submitted_at).toLocaleString(language === 'ro' ? 'ro-RO' : language === 'en' ? 'en-US' : language === 'fr' ? 'fr-FR' : language === 'it' ? 'it-IT' : 'es-ES')}</span>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteSubmission(sub.id)}
                                  className="h-6 w-6 p-0"
                                >
                                  <X className="h-3 w-3 text-destructive" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <Button 
                      className="w-full gradient-primary mt-auto"
                      onClick={() => navigate(`/video/${quiz.video_id}`, { state: { preselectedQuizId: quiz.id } })}
                    >
                      {quiz.submissions && quiz.submissions.length > 0 ? t('quizzes.completeAgain') : t('quizzes.watchVideo')}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
