import { useAuth } from "@/lib/auth-new";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Mail, Phone } from "lucide-react";

export default function AccountDeactivated() {
  const { signOut } = useAuth();

  const handleSignOut = () => {
    signOut();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <AlertTriangle className="h-6 w-6 text-red-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-red-700">
            Cont Dezactivat
          </CardTitle>
          <CardDescription className="text-gray-600">
            Contul dumneavoastră a fost dezactivat temporar
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-4">
            <p className="text-gray-700">
              Din păcate, contul dumneavoastră a fost dezactivat de către administratorul platformei.
            </p>
            
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <h3 className="font-semibold text-amber-800 mb-2">
                Pentru reactivarea contului:
              </h3>
              <div className="space-y-2 text-sm text-amber-700">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>Contactați administratorul prin email</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>Apelați suportul tehnic</span>
                </div>
              </div>
            </div>

            <p className="text-sm text-gray-600">
              Vă rugăm să explicați situația și să solicitați reactivarea contului. 
              Administratorul va examina cererea dumneavoastră și va lua o decizie în cel mai scurt timp.
            </p>
          </div>

          <div className="pt-4 border-t">
            <Button 
              onClick={handleSignOut}
              variant="outline" 
              className="w-full"
            >
              Deconectare
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
