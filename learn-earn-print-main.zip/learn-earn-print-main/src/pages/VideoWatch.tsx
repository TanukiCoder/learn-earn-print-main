import { useEffect, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { VideoPlayer } from "@/components/VideoPlayer";
import { Button } from "@/components/ui/button";
import api from "@/lib/api-client";
import { ArrowLeft } from "lucide-react";
import { ReceiptDialog } from "@/components/ReceiptDialog";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth-new";

export default function VideoWatch() {
  const { t } = useI18n();
  const { user } = useAuth();
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [video, setVideo] = useState<any>(null);
  const [quizzes, setQuizzes] = useState<any[]>([]);
  const [progress, setProgress] = useState(0);
  const [showReceiptDialog, setShowReceiptDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [preselectedQuizId, setPreselectedQuizId] = useState<string | null>(
    location.state?.preselectedQuizId || null
  );

  useEffect(() => {
    if (id && user?.id) {
      loadVideo();
    }
  }, [id, user?.id]);

  const loadVideo = async () => {
    try {
      if (!user?.id) return;

      const [videoResponse, quizzesResponse] = await Promise.all([
        api.videos.getById(id!),
        api.quizzes.getByVideoId(id!),
      ]);

      // Try to get progress, but don't fail if it doesn't exist
      let progressPercentage = 0;
      try {
        const progressResponse = await api.videoProgress.get(user.id, id!);
        progressPercentage = progressResponse.data?.progress_percentage || 0;
      } catch (error) {
        // Progress doesn't exist yet, that's okay
      }

      console.log('Loaded quizzes for video:', quizzesResponse.data);
      setVideo(videoResponse.data);
      setQuizzes(quizzesResponse.data || []);
      setProgress(progressPercentage);
    } catch (error) {
      console.error('Error loading video:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleProgress = async (percentage: number) => {
    try {
      if (!user?.id || !id) return;

      await api.videoProgress.upsert({
        user_id: user.id,
        video_id: id,
        progress_percentage: Math.floor(percentage),
        completed: percentage >= 99,
        last_watched_at: new Date().toISOString(),
      });

      setProgress(percentage);
    } catch (error) {
      console.error('Error updating progress:', error);
    }
  };

  const handleComplete = async () => {
    // Reload quizzes BEFORE opening dialog to ensure we have the latest data
    if (id) {
      try {
        const userResponse = await api.auth.getCurrentUser();
        const user = userResponse.data;
        if (user) {
          const quizzesResponse = await api.quizzes.getByVideoId(id);
          
          console.log('Quizzes loaded on video complete:', quizzesResponse.data);
          const loadedQuizzes = quizzesResponse.data || [];
          setQuizzes(loadedQuizzes);
          
          // Wait for React state to update, then open dialog
          // Use requestAnimationFrame to ensure state is updated in next render cycle
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              console.log('Opening dialog with quizzes:', loadedQuizzes);
              setShowReceiptDialog(true);
            });
          });
          return;
        }
      } catch (error) {
        console.error('Error loading quizzes:', error);
      }
    }
    
    // If no user or id, open dialog immediately
    setShowReceiptDialog(true);
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  if (!video) {
    return (
      <DashboardLayout>
        <div className="text-center py-12">
          <p className="text-lg text-muted-foreground">{t('videos.notFound')}</p>
          <Button onClick={() => navigate('/videos')} className="mt-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            {t('videos.backToVideos')}
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
        <Button variant="ghost" onClick={() => navigate('/videos')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          {t('common.back')}
        </Button>

        <div>
          <h1 className="text-4xl font-bold mb-2">{video.title}</h1>
          {video.description && (
            <p className="text-muted-foreground">{video.description}</p>
          )}
        </div>

        <VideoPlayer
          videoUrl={video.video_url}
          onProgress={handleProgress}
          onComplete={handleComplete}
          initialProgress={progress}
        />

        {/* New unified Receipt Dialog with Quiz Selection */}
        <ReceiptDialog
          open={showReceiptDialog}
          onOpenChange={setShowReceiptDialog}
          videoId={id!}
          videoTitle={video.title}
          quizzes={quizzes}
          preselectedQuizId={preselectedQuizId}
        />
      </div>
    </DashboardLayout>
  );
}
