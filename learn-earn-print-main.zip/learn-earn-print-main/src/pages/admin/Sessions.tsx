import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import api from "@/lib/api-client";
import { Monitor, Smartphone, Tablet, Power, Clock, AlertTriangle, Trash2 } from "lucide-react";
import { getDeviceDetails } from "@/lib/deviceDetection";
import { useI18n } from "@/lib/i18n";

interface UserSession {
  id: string;
  user_id: string;
  device_type: string;
  device_info: string;
  ip_address: string | null;
  login_at: string;
  last_active: string;
  is_active: boolean;
  logout_reason: string | null;
  profiles: {
    full_name: string;
    email: string;
  };
}

export default function Sessions() {
  const { t } = useI18n();
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSessions();
    
    // Poll for updates every 30 seconds
    const interval = setInterval(() => {
      loadSessions();
    }, 30000);

    return () => {
      clearInterval(interval);
    };
  }, []);

  const loadSessions = async () => {
    try {
      const response = await api.sessions.getAll();
      setSessions(response.data || []);
      setIsLoading(false);
    } catch (error) {
      console.error('Exception loading sessions:', error);
      toast.error(t('admin.errorLoadingSessions'));
      setIsLoading(false);
    }
  };

  const kickSession = async (sessionId: string) => {
    try {
      await api.sessions.kick(sessionId, 'Kicked by admin');
      toast.success('Session kicked successfully');
      loadSessions(); // Reload sessions
    } catch (error) {
      console.error('Error kicking session:', error);
      toast.error(t('admin.errorLogout'));
    }
  };

  const cleanupOldSessions = async () => {
    if (!confirm('Удалить все неактивные сессии старше 7 дней?')) return;
    
    try {
      const response = await api.sessions.cleanup(7);
      toast.success(`Удалено ${response.data.deleted} старых сессий`);
      loadSessions();
    } catch (error) {
      console.error('Error cleaning up sessions:', error);
      toast.error('Ошибка при очистке сессий');
    }
  };

  const formatIpAddress = (ip: string | null) => {
    if (!ip) return 'N/A';
    // Remove IPv6 prefix for localhost
    if (ip === '::1' || ip === '::ffff:127.0.0.1') return '127.0.0.1 (localhost)';
    if (ip.startsWith('::ffff:')) return ip.replace('::ffff:', '');
    return ip;
  };

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case 'mobile':
        return <Smartphone className="h-4 w-4" />;
      case 'tablet':
        return <Tablet className="h-4 w-4" />;
      default:
        return <Monitor className="h-4 w-4" />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ro-RO', {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getBrowserInfo = (userAgent: string) => {
    if (!userAgent) return 'Unknown';
    
    if (userAgent.includes('Chrome')) return 'Chrome';
    if (userAgent.includes('Firefox')) return 'Firefox';
    if (userAgent.includes('Safari')) return 'Safari';
    if (userAgent.includes('Edge')) return 'Edge';
    if (userAgent.includes('Opera')) return 'Opera';
    
    return 'Other';
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-4xl font-bold mb-2">{t('admin.sessions.title')}</h1>
          <p className="text-muted-foreground">
            {t('admin.sessions.description')}
          </p>
        </div>

        <Card className="shadow-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{t('admin.sessions.allSessions')}</CardTitle>
                <CardDescription>
                  {t('admin.sessions.sessionHistory')}
                </CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={cleanupOldSessions}
                className="text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Очистить старые
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : sessions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {t('admin.sessions.noSessions')}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('admin.sessions.user')}</TableHead>
                      <TableHead>{t('admin.sessions.device')}</TableHead>
                      <TableHead>{t('admin.sessions.browser')}</TableHead>
                      <TableHead>{t('admin.sessions.ipAddress')}</TableHead>
                      <TableHead>{t('admin.sessions.login')}</TableHead>
                      <TableHead>{t('admin.sessions.lastActive')}</TableHead>
                      <TableHead>{t('admin.sessions.status')}</TableHead>
                      <TableHead className="text-right">{t('admin.users.actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sessions.map((session) => (
                      <TableRow key={session.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{session.profiles?.full_name || t('admin.sessions.unknown')}</div>
                            <div className="text-xs text-muted-foreground">{session.profiles?.email}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getDeviceIcon(session.device_type)}
                            <span className="capitalize">{session.device_type}</span>
                            {(() => {
                              try {
                                const deviceInfo = JSON.parse(session.device_info || '{}');
                                const isUnusual = deviceInfo.isUnusual || 
                                  !deviceInfo.userAgent?.includes('chrome') && 
                                  !deviceInfo.userAgent?.includes('firefox') && 
                                  !deviceInfo.userAgent?.includes('safari') && 
                                  !deviceInfo.userAgent?.includes('edge');
                                return isUnusual ? (
                                  <div title={t('admin.sessions.unusualDevice')}>
                                    <AlertTriangle className="h-4 w-4 text-yellow-500" />
                                  </div>
                                ) : null;
                              } catch {
                                return null;
                              }
                            })()}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            <Badge variant="outline">
                              {getBrowserInfo(session.device_info)}
                            </Badge>
                            {(() => {
                              try {
                                const deviceInfo = JSON.parse(session.device_info || '{}');
                                if (deviceInfo.userAgent && deviceInfo.userAgent.includes('bot')) {
                                  return <Badge variant="destructive" className="text-xs">{t('admin.sessions.botCrawler')}</Badge>;
                                }
                              } catch {}
                              return null;
                            })()}
                          </div>
                        </TableCell>
                        <TableCell>
                          <code className="text-xs bg-muted px-2 py-1 rounded">
                            {formatIpAddress(session.ip_address)}
                          </code>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            {formatDate(session.login_at)}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatDate(session.last_active)}
                        </TableCell>
                        <TableCell>
                          {session.is_active ? (
                            <Badge variant="default" className="bg-green-500">
                              Activ
                            </Badge>
                          ) : (
                            <Badge variant="secondary">
                              Deconectat
                              {session.logout_reason && (
                                <span className="ml-1 text-xs">({session.logout_reason})</span>
                              )}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {session.is_active && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => kickSession(session.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Power className="h-4 w-4" />
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Statistici</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                <div className="text-2xl font-bold text-green-600">
                  {sessions.filter(s => s.is_active).length}
                </div>
                <div className="text-sm text-muted-foreground">Sesiuni Active</div>
              </div>
              
              <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <div className="text-2xl font-bold text-blue-600">
                  {sessions.filter(s => s.device_type === 'mobile').length}
                </div>
                <div className="text-sm text-muted-foreground">Mobile</div>
              </div>
              
              <div className="p-4 rounded-lg bg-purple-500/10 border border-purple-500/20">
                <div className="text-2xl font-bold text-purple-600">
                  {sessions.filter(s => s.device_type === 'tablet').length}
                </div>
                <div className="text-sm text-muted-foreground">Tablet</div>
              </div>
              
              <div className="p-4 rounded-lg bg-orange-500/10 border border-orange-500/20">
                <div className="text-2xl font-bold text-orange-600">
                  {sessions.filter(s => s.device_type === 'desktop').length}
                </div>
                <div className="text-sm text-muted-foreground">Desktop</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
