import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import api from "@/lib/api-client";
import { Plus, Upload, Trash2, Eye, EyeOff, Pencil } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useI18n } from "@/lib/i18n";

interface Video {
  id: string;
  title: string;
  description: string | null;
  video_url: string;
  thumbnail_url: string | null;
  duration: number | null;
  is_active: boolean;
  order_index: number;
  country: string | null;
  created_at: string;
}

export default function Videos() {
  const { t } = useI18n();
  const [videos, setVideos] = useState<Video[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    country: "România",
    order_index: 0,
  });
  
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [youtubeUrl, setYoutubeUrl] = useState("");

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const response = await api.videos.getAllAdmin();
      setVideos(response.data || []);
    } catch (error) {
      console.error('Error loading videos:', error);
      toast.error('Eroare la încărcarea videoclipurilor');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'video' | 'thumbnail') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (type === 'video') {
      if (!file.type.startsWith('video/')) {
        toast.error('Vă rugăm să selectați un fișier video valid');
        return;
      }
      setVideoFile(file);
    } else {
      if (!file.type.startsWith('image/')) {
        toast.error('Vă rugăm să selectați o imagine validă');
        return;
      }
      setThumbnailFile(file);
    }
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUploading(true);

    try {
      // Create new video
      if (!editingVideo && !youtubeUrl.trim() && !videoFile) {
        toast.error('Vă rugăm să adăugați un link YouTube sau să selectați un fișier video');
        setIsUploading(false);
        return;
      }

      const formDataToSend = new FormData();
      formDataToSend.append('title', formData.title);
      formDataToSend.append('description', formData.description);
      formDataToSend.append('country', formData.country);
      formDataToSend.append('order_index', formData.order_index.toString());
      
      if (youtubeUrl.trim()) {
        formDataToSend.append('youtube_url', youtubeUrl.trim());
      }
      
      if (videoFile) {
        formDataToSend.append('video', videoFile);
      }
      
      if (thumbnailFile) {
        formDataToSend.append('thumbnail', thumbnailFile);
      }

      if (editingVideo) {
        formDataToSend.append('is_active', editingVideo.is_active.toString());
        await api.videos.update(editingVideo.id, formDataToSend);
        toast.success('Videoclip actualizat cu succes!');
      } else {
        await api.videos.create(formDataToSend);
        toast.success('Videoclip adăugat cu succes!');
      }

      setIsOpen(false);
      resetForm();
      loadVideos();
    } catch (error: any) {
      console.error('Error saving video:', error);
      toast.error(error.response?.data?.error || 'Eroare la salvarea videoclipului');
    } finally {
      setIsUploading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      country: "România",
      order_index: 0,
    });
    setVideoFile(null);
    setThumbnailFile(null);
    setYoutubeUrl("");
    setEditingVideo(null);
  };

  const handleEdit = (video: Video) => {
    setEditingVideo(video);
    setFormData({
      title: video.title,
      description: video.description || "",
      country: video.country || "România",
      order_index: video.order_index,
    });
    setIsOpen(true);
  };

  const toggleActive = async (videoId: string, currentStatus: boolean) => {
    try {
      const formDataToSend = new FormData();
      const video = videos.find(v => v.id === videoId);
      if (!video) return;
      
      formDataToSend.append('title', video.title);
      formDataToSend.append('description', video.description || '');
      formDataToSend.append('country', video.country || '');
      formDataToSend.append('order_index', video.order_index.toString());
      formDataToSend.append('is_active', (!currentStatus).toString());
      
      await api.videos.update(videoId, formDataToSend);
      toast.success(!currentStatus ? t('admin.videos.activated') : t('admin.videos.deactivated'));
      loadVideos();
    } catch (error) {
      toast.error('Eroare la actualizare');
    }
  };

  const deleteVideo = async (videoId: string) => {
    if (!confirm(t('admin.confirmDelete'))) return;

    try {
      await api.videos.delete(videoId);
      toast.success('Videoclip șters cu succes!');
      loadVideos();
    } catch (error) {
      toast.error('Eroare la ștergere');
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold mb-2">{t('admin.videos.title')}</h1>
            <p className="text-muted-foreground">
              {t('admin.videos.description')}
            </p>
          </div>

          <Dialog open={isOpen} onOpenChange={(open) => {
            setIsOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                {t('admin.videos.addVideo')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingVideo ? t('admin.videos.editVideo') : t('admin.videos.addNewVideo')}
                </DialogTitle>
                <DialogDescription>
                  {editingVideo 
                    ? t('admin.videos.editDescription') 
                    : t('admin.videos.addDescription')}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">{t('admin.videos.titleLabel')} *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">{t('admin.videos.descriptionLabel')}</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country">{t('admin.videos.countryLabel')}</Label>
                  <Input
                    id="country"
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="order_index">{t('admin.videos.orderIndexLabel')}</Label>
                  <Input
                    id="order_index"
                    type="number"
                    value={formData.order_index}
                    onChange={(e) => setFormData({ ...formData, order_index: parseInt(e.target.value) })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="youtubeUrl">{t('admin.videos.youtubeUrlLabel')}</Label>
                  <Input
                    id="youtubeUrl"
                    type="url"
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    {t('admin.videos.youtubeOrUpload')}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="video">
                    {t('admin.videos.videoFileLabel')} {!editingVideo && !youtubeUrl.trim() && '*'}
                  </Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="video"
                      type="file"
                      accept="video/*"
                      onChange={(e) => handleFileChange(e, 'video')}
                      disabled={!!youtubeUrl.trim()}
                    />
                    <Upload className="h-4 w-4 text-muted-foreground" />
                  </div>
                  {videoFile && (
                    <p className="text-sm text-muted-foreground">
                      {t('admin.videos.selected')}: {videoFile.name}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="thumbnail">{t('admin.videos.thumbnailFileLabel')}</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="thumbnail"
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileChange(e, 'thumbnail')}
                    />
                    <Upload className="h-4 w-4 text-muted-foreground" />
                  </div>
                  {thumbnailFile && (
                    <p className="text-sm text-muted-foreground">
                      {t('admin.videos.selected')}: {thumbnailFile.name}
                    </p>
                  )}
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsOpen(false);
                      resetForm();
                    }}
                  >
                    Anulează
                  </Button>
                  <Button type="submit" disabled={isUploading}>
                    {isUploading ? 'Se încarcă...' : editingVideo ? 'Actualizează' : 'Adaugă'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>{t('admin.videos.videoList')}</CardTitle>
            <CardDescription>
              {videos.length} {t('admin.videos.totalVideos')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : videos.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {t('admin.videos.noVideos')}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Titlu</TableHead>
                    <TableHead>Țară</TableHead>
                    <TableHead>Ordine</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Acțiuni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {videos.map((video) => (
                    <TableRow key={video.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{video.title}</div>
                          {video.description && (
                            <div className="text-xs text-muted-foreground line-clamp-1">
                              {video.description}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{video.country || 'N/A'}</Badge>
                      </TableCell>
                      <TableCell>{video.order_index}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={video.is_active}
                            onCheckedChange={() => toggleActive(video.id, video.is_active)}
                          />
                          <span className="text-sm">
                            {video.is_active ? t('admin.users.active') : t('admin.users.inactive')}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(video)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteVideo(video.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
