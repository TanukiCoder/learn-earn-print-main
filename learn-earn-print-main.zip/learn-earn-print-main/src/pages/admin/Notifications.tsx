import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bell, AlertTriangle, CheckCircle, Info, Trash2 } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import api from "@/lib/api-client";
import { toast } from "sonner";

interface Notification {
  id: string;
  type: 'ip_change' | 'new_user' | 'suspicious_activity' | 'info';
  title: string;
  message: string;
  user_id?: string;
  user_name?: string;
  user_email?: string;
  old_ip?: string;
  new_ip?: string;
  is_read: boolean;
  created_at: string;
}

export default function Notifications() {
  const { t } = useI18n();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      const response = await api.notifications.getAll();
      setNotifications(response.data || []);
    } catch (error) {
      console.error('Error loading notifications:', error);
      toast.error(t('admin.notifications.errorLoading'));
    } finally {
      setIsLoading(false);
    }
  };

  const markAsRead = async (id: string) => {
    try {
      await api.notifications.markAsRead(id);
      setNotifications(notifications.map(n => 
        n.id === id ? { ...n, is_read: true } : n
      ));
      toast.success(t('admin.notifications.markedAsRead'));
    } catch (error) {
      toast.error(t('admin.notifications.errorMarkingRead'));
    }
  };

  const markAllAsRead = async () => {
    try {
      await api.notifications.markAllAsRead();
      setNotifications(notifications.map(n => ({ ...n, is_read: true })));
      toast.success(t('admin.notifications.allMarkedAsRead'));
    } catch (error) {
      toast.error(t('admin.notifications.errorMarkingRead'));
    }
  };

  const deleteNotification = async (id: string) => {
    if (!confirm(t('admin.notifications.confirmDelete'))) return;

    try {
      await api.notifications.delete(id);
      setNotifications(notifications.filter(n => n.id !== id));
      toast.success(t('admin.notifications.deleted'));
    } catch (error) {
      toast.error(t('admin.notifications.errorDeleting'));
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'ip_change':
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case 'suspicious_activity':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'new_user':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getNotificationBadge = (type: string) => {
    switch (type) {
      case 'ip_change':
        return <Badge variant="outline" className="bg-orange-500/10 text-orange-700 border-orange-500/20">{t('admin.notifications.ipChange')}</Badge>;
      case 'suspicious_activity':
        return <Badge variant="destructive">{t('admin.notifications.suspicious')}</Badge>;
      case 'new_user':
        return <Badge variant="outline" className="bg-green-500/10 text-green-700 border-green-500/20">{t('admin.notifications.newUser')}</Badge>;
      default:
        return <Badge variant="secondary">{t('admin.notifications.info')}</Badge>;
    }
  };

  const filteredNotifications = filter === 'unread' 
    ? notifications.filter(n => !n.is_read)
    : notifications;

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
              <Bell className="h-8 w-8 text-primary" />
              {t('admin.notifications.title')}
            </h1>
            <p className="text-muted-foreground">
              {t('admin.notifications.description')}
            </p>
          </div>

          {unreadCount > 0 && (
            <Button onClick={markAllAsRead} variant="outline">
              <CheckCircle className="h-4 w-4 mr-2" />
              {t('admin.notifications.markAllRead')}
            </Button>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            onClick={() => setFilter('all')}
          >
            {t('admin.notifications.all')} ({notifications.length})
          </Button>
          <Button
            variant={filter === 'unread' ? 'default' : 'outline'}
            onClick={() => setFilter('unread')}
          >
            {t('admin.notifications.unread')} ({unreadCount})
          </Button>
        </div>

        {/* Notifications List */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>{t('admin.notifications.recentNotifications')}</CardTitle>
            <CardDescription>
              {filteredNotifications.length} {t('admin.notifications.notifications')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredNotifications.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Bell className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>{t('admin.notifications.noNotifications')}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredNotifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 rounded-lg border transition-all ${
                      notification.is_read 
                        ? 'bg-background border-border' 
                        : 'bg-primary/5 border-primary/20'
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="mt-1">
                        {getNotificationIcon(notification.type)}
                      </div>
                      
                      <div className="flex-1 space-y-2">
                        <div className="flex items-start justify-between gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{notification.title}</h3>
                              {getNotificationBadge(notification.type)}
                              {!notification.is_read && (
                                <Badge variant="default" className="text-xs">
                                  {t('admin.notifications.new')}
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {notification.message}
                            </p>
                          </div>
                          
                          <div className="flex gap-2">
                            {!notification.is_read && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => markAsRead(notification.id)}
                              >
                                <CheckCircle className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteNotification(notification.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        {/* Additional Info for IP Change */}
                        {notification.type === 'ip_change' && notification.old_ip && notification.new_ip && (
                          <div className="mt-2 p-3 rounded bg-muted/50 text-sm">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <span className="text-muted-foreground">{t('admin.notifications.previousIP')}:</span>
                                <span className="ml-2 font-mono">{notification.old_ip}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">{t('admin.notifications.newIP')}:</span>
                                <span className="ml-2 font-mono">{notification.new_ip}</span>
                              </div>
                            </div>
                            {notification.user_name && (
                              <div className="mt-2">
                                <span className="text-muted-foreground">{t('admin.notifications.user')}:</span>
                                <span className="ml-2">{notification.user_name} ({notification.user_email})</span>
                              </div>
                            )}
                          </div>
                        )}

                        <p className="text-xs text-muted-foreground">
                          {new Date(notification.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
