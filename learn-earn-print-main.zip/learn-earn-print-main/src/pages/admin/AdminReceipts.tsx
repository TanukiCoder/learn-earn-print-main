import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, Receipt } from "lucide-react";
import api from "@/lib/api-client";
import { toast } from "sonner";
import { getReceiptTemplate } from "@/lib/receiptTemplates";
import jsPDF from "jspdf";
import { useI18n } from "@/lib/i18n";

interface ReceiptData {
  id: string;
  receipt_number: string;
  user_name: string;
  amount: number;
  generated_at: string;
  template_country: string;
  videos: {
    title: string;
  } | null;
  profiles: {
    full_name: string;
    email: string;
  } | null;
}

export default function AdminReceipts() {
  const { t } = useI18n();
  const [receipts, setReceipts] = useState<ReceiptData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadReceipts();
  }, []);

  const loadReceipts = async () => {
    try {
      const response = await api.receipts.getAllAdmin();
      const receiptsData = response.data || [];
      
      // Transform data to match expected format
      const formattedReceipts = receiptsData.map((receipt: any) => ({
        ...receipt,
        videos: receipt.video_title ? { title: receipt.video_title } : null,
        profiles: {
          full_name: receipt.full_name,
          email: receipt.email
        }
      }));
      
      setReceipts(formattedReceipts);
    } catch (error) {
      console.error('Error loading receipts:', error);
      toast.error(t('admin.receipts.errorLoading'));
    } finally {
      setIsLoading(false);
    }
  };

  const regeneratePDF = async (receipt: ReceiptData) => {
    try {
      const settingsResponse = await api.receipts.getSettings();
      const settings = settingsResponse.data;

      const template = getReceiptTemplate(receipt.template_country || 'romania');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [72, 200],
        compress: true
      });

      // Set font to monospace for better alignment
      pdf.setFont('courier', 'normal');

      const now = new Date();
      // Determine language based on template country or default to ro
      const countryLangMap: Record<string, string> = {
        'romania': 'ro',
        'franta': 'fr',
        'italia': 'it',
        'spania': 'es',
        'austria': 'de',
        'germania': 'de'
      };
      const userLang = countryLangMap[receipt.template_country || 'romania'] || 'ro';
      
      const receiptData = {
        receiptNumber: receipt.receipt_number,
        date: new Date(receipt.generated_at).toLocaleDateString('ro-RO', { 
          day: '2-digit', 
          month: '2-digit', 
          year: 'numeric' 
        }),
        time: new Date(receipt.generated_at).toLocaleTimeString('ro-RO', { 
          hour: '2-digit', 
          minute: '2-digit',
          hour12: false
        }),
        userName: receipt.user_name,
        videoTitle: receipt.videos?.title || '',
        amount: receipt.amount.toFixed(2),
        settings: { ...settings, user_language: userLang }
      };

      let y = 8;
      const maxWidth = 67; // Increased for better text fitting
      
      // Header - centered, larger font
      pdf.setFontSize(11);
      pdf.setFont('courier', 'bold');
      const headerLines = template.headerFormat(settings);
      headerLines.forEach((line: string) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---') || line.includes('─') || line.includes('━')) {
          // Draw line separator - use simple dashes
          pdf.setFontSize(8);
          pdf.setFont('courier', 'normal');
          // Replace Unicode dashes with simple dashes
          const cleanLine = line.replace(/[─━]/g, '-').replace(/%/g, '-');
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 30)), 36, y, { align: 'center' });
          y += 4;
          pdf.setFontSize(11);
          pdf.setFont('courier', 'bold');
        } else {
          // Clean any percent signs or Unicode characters
          const cleanLine = line.replace(/%/g, '').trim();
          pdf.text(cleanLine.substring(0, Math.min(cleanLine.length, 28)), 36, y, { align: 'center' });
          y += 4;
        }
      });
      
      y += 2;
      
      // Details - left aligned, smaller font
      pdf.setFontSize(8);
      pdf.setFont('courier', 'normal');
      const details = template.detailsFormat(receiptData);
      const totalLines = details.length;
      details.forEach((line: string, index: number) => {
        if (line.trim() === '') {
          y += 3;
        } else if (line.includes('---')) {
          const lineLength = Math.min(line.length, 30);
          pdf.text(line.substring(0, lineLength), 5, y, { maxWidth: maxWidth });
          y += 4;
        } else {
          // Use smaller font for last few lines if they're footer messages
          const isFooterLine = index >= totalLines - 5 && !line.includes('Bon Nr:') && !line.includes('Data:') && !line.includes('Client:') && !line.includes('Nº:') && !line.includes('Nr:') && !line.includes('Fecha:') && !line.includes('Date:') && !line.includes('Datum:');
          const isLastLine = index === totalLines - 1;
          // Check for footer messages in different languages
          const isParticipareLine = line.includes('Mulțumim!') || 
                                   line.includes('Multumim pentru participare') || 
                                   line.includes('Gracias por su participación') ||
                                   line.includes('Grazie per la partecipazione') ||
                                   line.includes('Merci pour votre participation') ||
                                   line.includes('Vielen Dank für Ihre Teilnahme');
          
          if (isFooterLine && !isLastLine && !isParticipareLine) {
            pdf.setFontSize(6.5); // Smaller for footer lines
          }
          if (isLastLine || isParticipareLine) {
            pdf.setFontSize(4); // Very small for last line and footer messages to ensure it fits
          }
          
          // For footer messages, use maximum width and ensure strict left alignment
          if (isParticipareLine) {
            // Write directly with maximum width, left aligned
            pdf.text(line.trim(), 5, y, { maxWidth: 75, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else if (isLastLine) {
            // For other last lines
            const textMaxWidth = maxWidth + 15;
            pdf.text(line.trim(), 5, y, { maxWidth: textMaxWidth, align: 'left' });
            y += 3.5;
            pdf.setFontSize(8); // Reset font size
          } else {
            // Regular lines
            const textMaxWidth = maxWidth;
            const lines = pdf.splitTextToSize(line, textMaxWidth);
            lines.forEach((textLine: string) => {
              pdf.text(textLine, 5, y, { 
                maxWidth: textMaxWidth,
                align: 'left'
              });
              y += 3.5;
            });
            if (isFooterLine) {
              pdf.setFontSize(8); // Reset font size
            }
          }
        }
      });
      
      y += 3;

      // Footer message for French/Italian/Spanish templates
      if (receipt.template_country === 'franta' && settings?.france_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        // Split by \n and also handle escaped newlines
        const footerLines = settings.france_footer_message.split(/\\n|\n/).filter(line => line.trim());
        footerLines.forEach((line: string) => {
          pdf.text(line.trim(), 5, y, { maxWidth: 75, align: 'left' });
          y += 4;
        });
      } else if (receipt.template_country === 'italia' && settings?.italy_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        pdf.text(settings.italy_footer_message.trim(), 5, y, { maxWidth: 75, align: 'left' });
        y += 4;
      } else if (receipt.template_country === 'spania' && settings?.spain_footer_message) {
        pdf.setFontSize(7);
        pdf.setFont('courier', 'normal');
        pdf.text(settings.spain_footer_message.trim(), 5, y, { maxWidth: 75, align: 'left' });
        y += 4;
      }
      // Note: footer_text is not added here as each template has its own language-specific footer
      pdf.save(`bon-${receipt.receipt_number}.pdf`);
      toast.success(t('admin.receipts.downloaded'));
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error(t('admin.receipts.errorLoading'));
    }
  };

  const getTotalAmount = () => {
    return receipts.reduce((sum, r) => sum + r.amount, 0).toFixed(2);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-4xl font-bold mb-2">{t('admin.receipts.title')}</h1>
          <p className="text-muted-foreground">
            {t('admin.receipts.description')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>{t('admin.receipts.totalReceipts')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-foreground">
                {receipts.length}
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>{t('admin.receipts.totalAmount')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-foreground">
                {getTotalAmount()} <span className="text-2xl text-muted-foreground">RON</span>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>{t('admin.receipts.today')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-foreground">
                {receipts.filter(r => {
                  const today = new Date();
                  const receiptDate = new Date(r.generated_at);
                  return receiptDate.toDateString() === today.toDateString();
                }).length}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Receipt className="h-5 w-5" />
              {t('admin.receipts.allReceipts')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : receipts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {t('admin.receipts.noReceipts')}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('admin.receipts.receiptNumber')}</TableHead>
                      <TableHead>{t('admin.receipts.user')}</TableHead>
                      <TableHead>{t('admin.receipts.video')}</TableHead>
                      <TableHead>{t('admin.receipts.template')}</TableHead>
                      <TableHead>{t('admin.receipts.amount')}</TableHead>
                      <TableHead>{t('admin.receipts.date')}</TableHead>
                      <TableHead className="text-right">{t('admin.receipts.actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {receipts.map((receipt) => (
                      <TableRow key={receipt.id}>
                        <TableCell className="font-mono text-sm">
                          {receipt.receipt_number}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium">{receipt.user_name}</span>
                            <span className="text-xs text-muted-foreground">
                              {receipt.profiles?.email}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>{receipt.videos?.title}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {receipt.template_country || 'romania'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="font-mono">
                            {receipt.amount.toFixed(2)} RON
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {new Date(receipt.generated_at).toLocaleDateString('ro-RO')}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => regeneratePDF(receipt)}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
