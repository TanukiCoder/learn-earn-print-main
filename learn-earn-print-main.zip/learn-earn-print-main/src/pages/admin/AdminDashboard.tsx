import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Video, FileQuestion, Receipt } from "lucide-react";
import api from "@/lib/api-client";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalVideos: 0,
    totalQuizzes: 0,
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const [usersRes, videosRes] = await Promise.all([
        api.users.getAll(),
        api.videos.getAllAdmin(),
      ]);

      const users = usersRes.data;
      const videos = videosRes.data;

      setStats({
        totalUsers: users.length,
        activeUsers: users.filter((u: any) => u.is_active).length,
        totalVideos: videos.length,
        totalQuizzes: 0, // TODO: Add quizzes count
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const statCards = [
    {
      title: "Utilizatori Totali",
      value: stats.totalUsers,
      description: `${stats.activeUsers} activi`,
      icon: Users,
      color: "text-blue-500",
    },
    {
      title: "Videoclipuri",
      value: stats.totalVideos,
      description: "Total videoclipuri",
      icon: Video,
      color: "text-green-500",
    },
    {
      title: "Chestionare",
      value: stats.totalQuizzes,
      description: "Total chestionare",
      icon: FileQuestion,
      color: "text-purple-500",
    },
    {
      title: "Bonuri Generate",
      value: 0,
      description: "Total bonuri",
      icon: Receipt,
      color: "text-orange-500",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-4xl font-bold mb-2">Dashboard Administrare</h1>
          <p className="text-muted-foreground">
            Bine ați venit în panoul de administrare
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {statCards.map((card, index) => (
            <Card key={index} className="shadow-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {card.title}
                </CardTitle>
                <card.icon className={`h-4 w-4 ${card.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{card.value}</div>
                <p className="text-xs text-muted-foreground">
                  {card.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Activitate Recentă</CardTitle>
              <CardDescription>
                Ultimele activități din platformă
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center py-8">
                Nu există activități recente
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Acțiuni Rapide</CardTitle>
              <CardDescription>
                Comenzi frecvente
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <a href="/admin/users" className="block p-3 rounded-lg hover:bg-accent transition-colors">
                  <div className="font-medium">Gestionează Utilizatori</div>
                  <div className="text-sm text-muted-foreground">Adaugă sau editează utilizatori</div>
                </a>
                <a href="/admin/videos" className="block p-3 rounded-lg hover:bg-accent transition-colors">
                  <div className="font-medium">Gestionează Videoclipuri</div>
                  <div className="text-sm text-muted-foreground">Încarcă sau editează videoclipuri</div>
                </a>
                <a href="/admin/quizzes" className="block p-3 rounded-lg hover:bg-accent transition-colors">
                  <div className="font-medium">Gestionează Chestionare</div>
                  <div className="text-sm text-muted-foreground">Creează sau editează chestionare</div>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
