import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import api from "@/lib/api-client";
import { FileText, Save } from "lucide-react";

export default function ReceiptSettings() {
  const [settings, setSettings] = useState({
    // General
    header_text: '',
    quiz_title: '',
    // Language-specific donation texts
    donation_text_ro: 'Donatie',
    donation_text_en: 'Donation',
    donation_text_fr: 'Donation',
    donation_text_it: 'Donazione',
    donation_text_es: 'Donación',
    donation_text_de: 'Spende',
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const response = await api.receipts.getSettings();
      const data = response.data;
      
      if (data) {
        setSettings({
          header_text: data.header_text || '',
          quiz_title: data.quiz_title || '',
          donation_text_ro: data.donation_text_ro || 'Donatie',
          donation_text_en: data.donation_text_en || 'Donation',
          donation_text_fr: data.donation_text_fr || 'Donation',
          donation_text_it: data.donation_text_it || 'Donazione',
          donation_text_es: data.donation_text_es || 'Donación',
          donation_text_de: data.donation_text_de || 'Spende',
        });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast.error('Eroare la încărcarea setărilor');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    
    try {
      await api.receipts.updateSettings(settings);
      toast.success('Setări salvate cu succes! ✅');
    } catch (error: any) {
      console.error('Error saving settings:', error);
      toast.error('Eroare la salvarea setărilor: ' + (error.response?.data?.error || error.message));
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in max-w-4xl">
        <div className="flex items-center gap-3">
          <FileText className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-4xl font-bold">Setări Bonuri</h1>
            <p className="text-muted-foreground">
              Configurările pentru bonuri sunt disponibile în secțiunea Setări pentru fiecare utilizator
            </p>
          </div>
        </div>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>ℹ️ Informații</CardTitle>
            <CardDescription>
              Fiecare utilizator poate configura propriile setări pentru bonuri în secțiunea Setări
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              Pentru a configura setările bonurilor, utilizatorii trebuie să acceseze secțiunea "Setări" din meniul lor.
              Fiecare utilizator poate avea setări personalizate pentru fiecare țară/valută.
            </p>
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <p className="text-sm text-blue-900 dark:text-blue-200">
                <strong>Notă:</strong> Toate setările pentru bonuri (șabloane, email, website, texte) sunt configurate individual de fiecare utilizator în secțiunea "Setări" din meniul utilizatorului.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>⚙️ Setări Generale</CardTitle>
            <CardDescription>
              Configurări generale pentru toți utilizatorii
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="header_text">Text Antet Bon (Header Text)</Label>
              <Input
                id="header_text"
                value={settings.header_text}
                onChange={(e) => setSettings({ ...settings, header_text: e.target.value })}
                placeholder="Ex: Text personalizat sau lasă gol pentru a nu afișa niciun text"
              />
              <p className="text-sm text-muted-foreground">
                Acest text va fi afișat în antetul bonului fiscal. Lasă câmpul gol pentru a nu afișa niciun text în antet.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="quiz_title">Titlu Test (Quiz)</Label>
              <Input
                id="quiz_title"
                value={settings.quiz_title}
                onChange={(e) => setSettings({ ...settings, quiz_title: e.target.value })}
                placeholder="Ex: Avem câteva întrebări"
              />
              <p className="text-sm text-muted-foreground">
                Acest titlu va fi afișat în dialogul de generare a bonului când utilizatorul trebuie să completeze un test.
              </p>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-semibold">Texte Donație (pe Limbi)</Label>
              <p className="text-sm text-muted-foreground">
                Configurați textul pentru "Donation" în diferite limbi. Aceste texte vor fi folosite în bonurile fiscale.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="donation_text_ro">Română (RO)</Label>
                  <Input
                    id="donation_text_ro"
                    value={settings.donation_text_ro}
                    onChange={(e) => setSettings({ ...settings, donation_text_ro: e.target.value })}
                    placeholder="Donatie"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="donation_text_en">Engleză (EN)</Label>
                  <Input
                    id="donation_text_en"
                    value={settings.donation_text_en}
                    onChange={(e) => setSettings({ ...settings, donation_text_en: e.target.value })}
                    placeholder="Donation"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="donation_text_fr">Franceză (FR)</Label>
                  <Input
                    id="donation_text_fr"
                    value={settings.donation_text_fr}
                    onChange={(e) => setSettings({ ...settings, donation_text_fr: e.target.value })}
                    placeholder="Donation"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="donation_text_it">Italiană (IT)</Label>
                  <Input
                    id="donation_text_it"
                    value={settings.donation_text_it}
                    onChange={(e) => setSettings({ ...settings, donation_text_it: e.target.value })}
                    placeholder="Donazione"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="donation_text_es">Spaniolă (ES)</Label>
                  <Input
                    id="donation_text_es"
                    value={settings.donation_text_es}
                    onChange={(e) => setSettings({ ...settings, donation_text_es: e.target.value })}
                    placeholder="Donación"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="donation_text_de">Germană (DE)</Label>
                  <Input
                    id="donation_text_de"
                    value={settings.donation_text_de}
                    onChange={(e) => setSettings({ ...settings, donation_text_de: e.target.value })}
                    placeholder="Spende"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <Button
                onClick={handleSave}
                disabled={isSaving}
                className="gradient-primary text-white shadow-glow hover:shadow-glow-lg"
              >
                {isSaving ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Se salvează...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Salvează Setări
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
