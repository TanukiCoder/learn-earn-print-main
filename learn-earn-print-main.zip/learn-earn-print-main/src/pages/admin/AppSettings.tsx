import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Settings } from "lucide-react";
import api from "@/lib/api-client";

interface AppSetting {
  id: string;
  setting_key: string;
  setting_value: string;
  description: string;
  created_at: string;
  updated_at: string;
}

export default function AppSettings() {
  const [settings, setSettings] = useState<AppSetting[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const response = await api.appSettings.getAll();
      setSettings(response.data);
    } catch (error: any) {
      console.error('Error loading settings:', error);
      toast.error('Eroare la încărcarea setărilor');
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggle = async (key: string, currentValue: string) => {
    try {
      const newValue = currentValue === 'true' ? 'false' : 'true';
      await api.appSettings.update(key, newValue);
      
      setSettings(settings.map(s => 
        s.setting_key === key 
          ? { ...s, setting_value: newValue }
          : s
      ));

      toast.success('Setare actualizată cu succes!');
    } catch (error: any) {
      console.error('Error updating setting:', error);
      toast.error('Eroare la actualizarea setării');
    }
  };

  const getSettingLabel = (key: string) => {
    const labels: Record<string, { title: string; description: string }> = {
      users_can_create_quizzes: {
        title: 'Utilizatorii pot crea chestionare',
        description: 'Permite utilizatorilor să creeze propriile chestionare'
      }
    };
    return labels[key] || { title: key, description: '' };
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Se încarcă...</div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Setări Aplicație</h1>
          <p className="text-muted-foreground mt-2">
            Gestionează setările generale ale aplicației
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Setări Generale
            </CardTitle>
            <CardDescription>
              Configurează funcționalitățile disponibile pentru utilizatori
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {settings.map((setting) => {
              const label = getSettingLabel(setting.setting_key);
              return (
                <div 
                  key={setting.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="space-y-1 flex-1">
                    <Label htmlFor={setting.setting_key} className="text-base font-semibold cursor-pointer">
                      {label.title}
                    </Label>
                    {label.description && (
                      <p className="text-sm text-muted-foreground">
                        {label.description}
                      </p>
                    )}
                  </div>
                  <Switch
                    id={setting.setting_key}
                    checked={setting.setting_value === 'true'}
                    onCheckedChange={() => handleToggle(setting.setting_key, setting.setting_value)}
                  />
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
