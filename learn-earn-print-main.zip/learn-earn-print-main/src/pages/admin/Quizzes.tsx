import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import api from "@/lib/api-client";
import { Plus, Trash2, Pencil, FileQuestion, Eye } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/lib/i18n";

interface Quiz {
  id: string;
  title: string;
  video_id: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  video: {
    title: string;
  };
  questions_count?: number;
  submissions_count?: number;
}

interface QuizQuestion {
  id: string;
  question_text: string;
  question_type: string;
  options: any;
  order_index: number;
}

interface QuestionForm {
  question_text: string;
  options: string[];
  correct_answer: number;
}

export default function Quizzes() {
  const { t } = useI18n();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);
  const [isViewingQuestions, setIsViewingQuestions] = useState(false);
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);
  const [selectedQuizForQuestions, setSelectedQuizForQuestions] = useState<Quiz | null>(null);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  
  const [formData, setFormData] = useState({
    title: "",
    video_id: "",
  });

  const [questions, setQuestions] = useState<QuestionForm[]>([{
    question_text: '',
    options: ['', '', '', ''],
    correct_answer: 0
  }]);

  useEffect(() => {
    loadQuizzes();
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const response = await api.videos.getAllAdmin();
      setVideos(response.data || []);
    } catch (error) {
      console.error('Error loading videos:', error);
    }
  };

  const loadQuizzes = async () => {
    try {
      // Load all videos first to get video titles
      const videosResponse = await api.videos.getAllAdmin();
      const videosMap = new Map(videosResponse.data.map((v: any) => [v.id, v]));
      
      // For now, we'll need to get quizzes for each video
      // This is a simplified approach - ideally the API should return all quizzes
      const allQuizzes: any[] = [];
      
      for (const video of videosResponse.data) {
        try {
          const response = await api.quizzes.getByVideoId(video.id);
          const quizzesForVideo = response.data.map((quiz: any) => ({
            ...quiz,
            video: { title: video.title },
            questions_count: quiz.question_count || 0,
            submissions_count: 0 // API doesn't return this yet
          }));
          allQuizzes.push(...quizzesForVideo);
        } catch (error) {
          // Video might not have quizzes, continue
        }
      }
      
      setQuizzes(allQuizzes);
    } catch (error: any) {
      console.error('Error loading quizzes:', error);
      toast.error('Eroare la încărcarea chestionarelor');
    } finally {
      setIsLoading(false);
    }
  };

  const loadQuizQuestions = async (quizId: string) => {
    try {
      const response = await api.quizzes.getById(quizId);
      setQuizQuestions(response.data.questions || []);
    } catch (error) {
      toast.error('Eroare la încărcarea întrebărilor');
    }
  };

  const handleViewQuestions = async (quiz: Quiz) => {
    setSelectedQuizForQuestions(quiz);
    setIsViewingQuestions(true);
    await loadQuizQuestions(quiz.id);
  };

  const resetForm = () => {
    setFormData({
      title: "",
      video_id: "",
    });
    setQuestions([{
      question_text: '',
      options: ['', '', '', ''],
      correct_answer: 0
    }]);
    setEditingQuiz(null);
  };

  const handleEdit = async (quiz: Quiz) => {
    setEditingQuiz(quiz);
    setFormData({
      title: quiz.title,
      video_id: quiz.video_id,
    });
    
    try {
      const response = await api.quizzes.getById(quiz.id);
      const data = response.data.questions || [];
      
      const formattedQuestions: QuestionForm[] = data.map((q: any) => ({
        question_text: q.question_text,
        options: q.options?.options || ['', '', '', ''],
        correct_answer: q.options?.correct || 0
      }));
      
      if (formattedQuestions.length === 0) {
        formattedQuestions.push({
          question_text: '',
          options: ['', '', '', ''],
          correct_answer: 0
        });
      }
      
      setQuestions(formattedQuestions);
      setIsOpen(true);
    } catch (error) {
      toast.error('Eroare la încărcarea întrebărilor');
    }
  };

  const addQuestion = () => {
    setQuestions([...questions, {
      question_text: '',
      options: ['', '', '', ''],
      correct_answer: 0
    }]);
  };

  const removeQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const updateQuestion = (index: number, field: keyof QuestionForm, value: any) => {
    const newQuestions = [...questions];
    newQuestions[index] = { ...newQuestions[index], [field]: value };
    setQuestions(newQuestions);
  };

  const updateOption = (qIndex: number, oIndex: number, value: string) => {
    const newQuestions = [...questions];
    newQuestions[qIndex].options[oIndex] = value;
    setQuestions(newQuestions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.video_id) {
      toast.error('Completă toate câmpurile obligatorii!');
      return;
    }

    if (questions.length === 0) {
      toast.error(t('admin.quizzes.addAtLeastOneQuestion'));
      return;
    }

    // Validate all questions
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.question_text.trim()) {
        toast.error(`${t('admin.quizzes.question')} ${i + 1} ${t('quizzes.questionEmpty')}`);
        return;
      }
      if (q.options.some(opt => !opt.trim())) {
        toast.error(`${t('admin.quizzes.answerOptions')} ${t('quizzes.allOptionsRequired')}`);
        return;
      }
    }

    try {
      const questionsToSend = questions.map((q, index) => ({
        question_text: q.question_text,
        question_type: 'radio',
        options: {
          options: q.options,
          correct: q.correct_answer
        },
        order_index: index
      }));

      const quizData = {
        title: formData.title,
        video_id: formData.video_id,
        questions: questionsToSend
      };

      await api.quizzes.create(quizData);
      toast.success(editingQuiz ? 'Chestionar actualizat cu succes!' : 'Chestionar adăugat cu succes!');

      setIsOpen(false);
      resetForm();
      loadQuizzes();
    } catch (error: any) {
      console.error('Error saving quiz:', error);
      toast.error(error.response?.data?.error || 'Eroare la salvarea chestionarului');
    }
  };

  const deleteQuiz = async (quizId: string) => {
    if (!confirm('Sigur doriți să ștergeți acest chestionar? Toate întrebările și răspunsurile asociate vor fi șterse.')) return;

    try {
      await api.quizzes.delete(quizId);
      toast.success('Chestionar șters cu succes!');
      loadQuizzes();
    } catch (error: any) {
      console.error('Error deleting quiz:', error);
      toast.error('Eroare la ștergere');
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold mb-2">{t('admin.quizzes.title')}</h1>
            <p className="text-muted-foreground">
              {t('admin.quizzes.description')}
            </p>
          </div>

          <Dialog open={isOpen} onOpenChange={(open) => {
            setIsOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                {t('admin.quizzes.addQuiz')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingQuiz ? t('admin.quizzes.editQuiz') : t('admin.quizzes.addNewQuiz')}
                </DialogTitle>
                <DialogDescription>
                  {editingQuiz 
                    ? t('admin.quizzes.editDescription') 
                    : t('admin.quizzes.addDescription')}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">{t('admin.quizzes.titleLabel')} *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="video_id">{t('admin.quizzes.videoLabel')} *</Label>
                  <Select value={formData.video_id} onValueChange={(value) => setFormData({ ...formData, video_id: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('admin.quizzes.selectVideo')} />
                    </SelectTrigger>
                    <SelectContent>
                      {videos.map((video) => (
                        <SelectItem key={video.id} value={video.id}>
                          {video.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4 border-t pt-4">
                  <div className="flex justify-between items-center">
                    <Label className="text-base font-semibold">{t('admin.quizzes.questionsLabel')}</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addQuestion}>
                      <Plus className="h-4 w-4 mr-2" />
                      {t('admin.quizzes.addQuestion')}
                    </Button>
                  </div>

                  {questions.map((question, qIndex) => (
                    <div key={qIndex} className="p-4 border rounded-lg space-y-3">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                              {qIndex + 1}
                            </div>
                            <Label>{t('admin.quizzes.question')} {qIndex + 1}</Label>
                          </div>
                          <Textarea
                            value={question.question_text}
                            onChange={(e) => updateQuestion(qIndex, 'question_text', e.target.value)}
                            placeholder={t('admin.quizzes.enterQuestion')}
                            rows={2}
                            required
                          />
                        </div>
                        {questions.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeQuestion(qIndex)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label>{t('admin.quizzes.answerOptions')}</Label>
                        {question.options.map((option, oIndex) => (
                          <div key={oIndex} className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs font-bold">
                              {String.fromCharCode(65 + oIndex)}
                            </div>
                            <Input
                              value={option}
                              onChange={(e) => updateOption(qIndex, oIndex, e.target.value)}
                              placeholder={`${t('admin.quizzes.option')} ${String.fromCharCode(65 + oIndex)}`}
                              required
                            />
                            <Button
                              type="button"
                              variant={question.correct_answer === oIndex ? "default" : "outline"}
                              size="sm"
                              onClick={() => updateQuestion(qIndex, 'correct_answer', oIndex)}
                            >
                              {t('admin.quizzes.correct')}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsOpen(false);
                      resetForm();
                    }}
                  >
                    Anulează
                  </Button>
                  <Button type="submit">
                    {editingQuiz ? 'Actualizează' : 'Adaugă'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>{t('admin.quizzes.quizList')}</CardTitle>
            <CardDescription>
              {quizzes.length} {t('admin.quizzes.totalQuizzes')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : quizzes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {t('admin.quizzes.noQuizzes')}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('admin.quizzes.titleLabel')}</TableHead>
                    <TableHead>{t('admin.quizzes.videoLabel')}</TableHead>
                    <TableHead>{t('admin.quizzes.questions')}</TableHead>
                    <TableHead>{t('admin.quizzes.submissions')}</TableHead>
                    <TableHead>{t('admin.quizzes.createdAt')}</TableHead>
                    <TableHead className="text-right">{t('admin.users.actions')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {quizzes.map((quiz) => (
                    <TableRow key={quiz.id}>
                      <TableCell>
                        <div className="font-medium">{quiz.title}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{quiz.video.title}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <FileQuestion className="h-4 w-4 text-muted-foreground" />
                          <span>{quiz.questions_count || 0}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span>{quiz.submissions_count || 0}</span>
                      </TableCell>
                      <TableCell>
                        {new Date(quiz.created_at).toLocaleDateString('ro-RO')}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewQuestions(quiz)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(quiz)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteQuiz(quiz.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* View Questions Dialog */}
        <Dialog open={isViewingQuestions} onOpenChange={setIsViewingQuestions}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {t('admin.quizzes.questionsFor')}: {selectedQuizForQuestions?.title}
              </DialogTitle>
              <DialogDescription>
                {t('admin.quizzes.viewQuestions')}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {quizQuestions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {t('admin.quizzes.noQuestions')}
                </div>
              ) : (
                quizQuestions.map((question, index) => (
                  <div key={question.id} className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <span className="font-semibold">{question.question_text}</span>
                    </div>
                    <div className="space-y-1 ml-8">
                      {question.options?.options?.map((opt: string, optIndex: number) => (
                        <div key={optIndex} className="flex items-center gap-2">
                          <div className="w-5 h-5 rounded-full bg-muted flex items-center justify-center text-xs font-bold">
                            {String.fromCharCode(65 + optIndex)}
                          </div>
                          <span className={question.options?.correct === optIndex ? 'font-semibold text-primary' : ''}>
                            {opt}
                            {question.options?.correct === optIndex && ' ✓'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}

