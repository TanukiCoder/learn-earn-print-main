import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { toast } from "sonner";
import { Plus, Trash2, Pencil, UserCheck, UserX } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import api from "@/lib/api-client";

interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'admin' | 'user';
  is_active: boolean;
  subscription_start?: string;
  subscription_end?: string;
  created_at: string;
  total_earnings?: number;
}

export default function Users() {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    userId: string;
    currentStatus: boolean;
    action: 'activate' | 'deactivate' | 'delete';
    userName: string;
  }>({
    open: false,
    userId: '',
    currentStatus: false,
    action: 'activate',
    userName: ''
  });
  
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    full_name: "",
    role: "user" as 'admin' | 'user',
    subscription_start: "",
    subscription_end: "",
  });

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const response = await api.users.getAll();
      setUsers(response.data);
    } catch (error: any) {
      console.error('Error loading users:', error);
      toast.error('Eroare la încărcarea utilizatorilor');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingUser) {
        // Update existing user
        await api.users.update(editingUser.id, {
          full_name: formData.full_name,
          role: formData.role,
          is_active: true,
          subscription_start: formData.subscription_start || null,
          subscription_end: formData.subscription_end || null,
          ...(formData.password && { password: formData.password }),
        });
        toast.success('Utilizator actualizat cu succes!');
      } else {
        // Create new user
        await api.users.create({
          email: formData.email,
          password: formData.password,
          full_name: formData.full_name,
          role: formData.role,
          subscription_start: formData.subscription_start || null,
          subscription_end: formData.subscription_end || null,
        });
        toast.success('Utilizator adăugat cu succes!');
      }

      setIsOpen(false);
      resetForm();
      loadUsers();
    } catch (error: any) {
      console.error('Error saving user:', error);
      toast.error(error.response?.data?.error || 'Eroare la salvarea utilizatorului');
    }
  };

  const resetForm = () => {
    setFormData({
      email: "",
      password: "",
      full_name: "",
      role: "user",
      subscription_start: "",
      subscription_end: "",
    });
    setEditingUser(null);
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      email: user.email,
      password: "",
      full_name: user.full_name,
      role: user.role,
      subscription_start: user.subscription_start || "",
      subscription_end: user.subscription_end || "",
    });
    setIsOpen(true);
  };

  const openConfirmDialog = (userId: string, currentStatus: boolean, userName: string) => {
    setConfirmDialog({
      open: true,
      userId,
      currentStatus,
      action: currentStatus ? 'deactivate' : 'activate',
      userName
    });
  };

  const handleConfirmAction = async () => {
    const { userId, currentStatus } = confirmDialog;
    
    try {
      // Получаем текущего пользователя для обновления
      const currentUser = users.find(u => u.id === userId);
      if (!currentUser) {
        toast.error('Utilizatorul nu a fost găsit');
        return;
      }

      // Обновляем пользователя с сохранением всех полей
      await api.users.update(userId, {
        full_name: currentUser.full_name,
        role: currentUser.role,
        is_active: !currentStatus,
        subscription_start: currentUser.subscription_start || null,
        subscription_end: currentUser.subscription_end || null
      });
      
      toast.success(!currentStatus ? 'Utilizator activat cu succes!' : 'Utilizator dezactivat cu succes!');
      loadUsers();
    } catch (error: any) {
      console.error('Error updating user status:', error);
      toast.error(error.response?.data?.error || 'Eroare la actualizarea statusului utilizatorului');
    } finally {
      setConfirmDialog(prev => ({ ...prev, open: false }));
    }
  };

  const openDeleteDialog = (userId: string, userName: string) => {
    setConfirmDialog({
      open: true,
      userId,
      currentStatus: false,
      action: 'delete',
      userName
    });
  };

  const handleDeleteUser = async () => {
    try {
      await api.users.delete(confirmDialog.userId);
      toast.success('Utilizator șters cu succes!');
      loadUsers();
    } catch (error) {
      toast.error('Eroare la ștergerea utilizatorului');
    } finally {
      setConfirmDialog(prev => ({ ...prev, open: false }));
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold mb-2">Utilizatori</h1>
            <p className="text-muted-foreground">
              Gestionați utilizatorii platformei
            </p>
          </div>

          <Dialog open={isOpen} onOpenChange={(open) => {
            setIsOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Adaugă Utilizator
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingUser ? 'Editează Utilizator' : 'Adaugă Utilizator Nou'}
                </DialogTitle>
                <DialogDescription>
                  {editingUser 
                    ? 'Modificați informațiile utilizatorului' 
                    : 'Completați informațiile pentru noul utilizator'}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    disabled={!!editingUser}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="full_name">Nume Complet *</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">
                    Parolă {editingUser ? '(lasați gol pentru a păstra parola actuală)' : '*'}
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    required={!editingUser}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="role">Rol</Label>
                  <select
                    id="role"
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as 'admin' | 'user' })}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="user">Utilizator</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="subscription_start">Data Început Abonament</Label>
                    <Input
                      id="subscription_start"
                      type="date"
                      value={formData.subscription_start}
                      onChange={(e) => setFormData({ ...formData, subscription_start: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subscription_end">Data Sfârșit Abonament</Label>
                    <Input
                      id="subscription_end"
                      type="date"
                      value={formData.subscription_end}
                      onChange={(e) => setFormData({ ...formData, subscription_end: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsOpen(false);
                      resetForm();
                    }}
                  >
                    Anulează
                  </Button>
                  <Button type="submit">
                    {editingUser ? 'Actualizează' : 'Adaugă'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Listă Utilizatori</CardTitle>
            <CardDescription>
              {users.length} utilizatori în total
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : users.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nu există utilizatori
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nume</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Rol</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Abonament</TableHead>
                    <TableHead>Câștigat Total</TableHead>
                    <TableHead className="text-right">Acțiuni</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.full_name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                          {user.role === 'admin' ? 'Admin' : 'User'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant={user.is_active ? "destructive" : "default"}
                            size="sm"
                            onClick={() => openConfirmDialog(user.id, user.is_active, user.full_name)}
                            className="min-w-[100px]"
                          >
                            {user.is_active ? (
                              <>
                                <UserX className="h-4 w-4 mr-1" />
                                Deactivate
                              </>
                            ) : (
                              <>
                                <UserCheck className="h-4 w-4 mr-1" />
                                Activate
                              </>
                            )}
                          </Button>
                          <Badge variant={user.is_active ? "default" : "destructive"}>
                            {user.is_active ? 'Activ' : 'Inactiv'}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        {user.subscription_end ? (
                          <span className="text-sm">
                            {new Date(user.subscription_end) > new Date() ? (
                              <Badge variant="outline" className="gap-1">
                                <UserCheck className="h-3 w-3" />
                                Activ
                              </Badge>
                            ) : (
                              <Badge variant="destructive" className="gap-1">
                                <UserX className="h-3 w-3" />
                                Expirat
                              </Badge>
                            )}
                          </span>
                        ) : (
                          <span className="text-sm text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="font-semibold text-green-600">
                          {user.total_earnings ? `${user.total_earnings.toFixed(2)} RON` : '0.00 RON'}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(user)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openDeleteDialog(user.id, user.full_name)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Confirm Dialog */}
      <ConfirmDialog
        open={confirmDialog.open}
        onOpenChange={(open) => setConfirmDialog(prev => ({ ...prev, open }))}
        onConfirm={confirmDialog.action === 'delete' ? handleDeleteUser : handleConfirmAction}
        title={
          confirmDialog.action === 'delete' 
            ? 'Șterge Utilizator'
            : confirmDialog.action === 'activate'
            ? 'Activează Utilizator'
            : 'Dezactivează Utilizator'
        }
        description={
          confirmDialog.action === 'delete'
            ? `Sigur doriți să ștergeți utilizatorul "${confirmDialog.userName}"? Această acțiune nu poate fi anulată.`
            : confirmDialog.action === 'activate'
            ? `Sigur doriți să activați utilizatorul "${confirmDialog.userName}"? Utilizatorul va putea accesa din nou platforma.`
            : `Sigur doriți să dezactivați utilizatorul "${confirmDialog.userName}"? Utilizatorul nu va mai putea accesa platforma.`
        }
        confirmText={
          confirmDialog.action === 'delete' 
            ? 'Șterge'
            : confirmDialog.action === 'activate'
            ? 'Activează'
            : 'Dezactivează'
        }
        variant={confirmDialog.action === 'delete' || confirmDialog.action === 'deactivate' ? 'destructive' : 'default'}
        icon={
          confirmDialog.action === 'delete' 
            ? 'warning'
            : confirmDialog.action === 'activate'
            ? 'activate'
            : 'deactivate'
        }
      />
    </DashboardLayout>
  );
}
