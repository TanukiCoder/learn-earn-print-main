import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import api from "@/lib/api-client";
import { useAuth } from "@/lib/auth-new";
import { Play, Clock, CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/lib/i18n";

interface Video {
  id: string;
  title: string;
  description: string;
  video_url: string;
  thumbnail_url: string;
  duration: number;
  order_index: number;
  country: string;
}

interface VideoProgress {
  video_id: string;
  progress_percentage: number;
  completed: boolean;
}

export default function Videos() {
  const { t } = useI18n();
  const [videosByCountry, setVideosByCountry] = useState<Record<string, Video[]>>({});
  const [progress, setProgress] = useState<VideoProgress[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeCountry, setActiveCountry] = useState<string>("România");
  const navigate = useNavigate();

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      if (!user.id) return;

      const videosResponse = await api.videos.getAll();
      const videosData = videosResponse.data || [];

      // Group videos by country
      const grouped = videosData.reduce((acc: Record<string, Video[]>, video: any) => {
        const country = video.country || 'România';
        if (!acc[country]) {
          acc[country] = [];
        }
        acc[country].push(video);
        return acc;
      }, {} as Record<string, Video[]>);

      setVideosByCountry(grouped);
      
      // Load progress for all videos
      // Note: video progress API needs to be implemented
      setProgress([]);
      
      // Set first country as active if România doesn't exist
      const countries = Object.keys(grouped);
      if (countries.length > 0 && !grouped['România']) {
        setActiveCountry(countries[0]);
      }
    } catch (error) {
      console.error('Error loading videos:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getProgress = (videoId: string) => {
    return progress.find((p) => p.video_id === videoId);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  const countries = Object.keys(videosByCountry);
  const totalVideos = countries.reduce((sum, c) => sum + videosByCountry[c].length, 0);

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-4xl font-bold mb-2">{t('videos.title')}</h1>
          <p className="text-muted-foreground">
            {t('videos.description')}
          </p>
        </div>

        {totalVideos === 0 ? (
          <Card className="shadow-card">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Play className="h-16 w-16 text-muted-foreground mb-4" />
              <p className="text-lg text-muted-foreground">
                {t('videos.noVideosAvailable') || 'Nu există videoclipuri disponibile momentan'}
              </p>
            </CardContent>
          </Card>
        ) : countries.length === 1 ? (
          // If only one country, don't show tabs
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {videosByCountry[countries[0]].map((video) => {
              const videoProgress = getProgress(video.id);
              const isCompleted = videoProgress?.completed || false;
              const progressPercentage = videoProgress?.progress_percentage || 0;

              return (
                <Card key={video.id} className="shadow-card hover:shadow-glow transition-all overflow-hidden group flex flex-col h-full">
                  <div className="relative aspect-video bg-secondary overflow-hidden">
                    {video.thumbnail_url ? (
                      <img
                        src={video.thumbnail_url}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Play className="h-16 w-16 text-muted-foreground" />
                      </div>
                    )}
                    
                    {isCompleted && (
                      <div className="absolute top-2 right-2 bg-green-500 rounded-full p-2">
                        <CheckCircle className="h-5 w-5 text-white" />
                      </div>
                    )}

                    {progressPercentage > 0 && !isCompleted && (
                      <div className="absolute bottom-0 left-0 w-full h-1 bg-secondary">
                        <div
                          className="h-full gradient-primary transition-all"
                          style={{ width: `${progressPercentage}%` }}
                        />
                      </div>
                    )}
                  </div>

                  <CardHeader className="flex-shrink-0">
                    <div className="flex items-start justify-between gap-2">
                      <CardTitle className="text-lg line-clamp-2">{video.title}</CardTitle>
                      {video.duration && (
                        <Badge variant="secondary" className="flex items-center gap-1 shrink-0">
                          <Clock className="h-3 w-3" />
                          {formatDuration(video.duration)}
                        </Badge>
                      )}
                    </div>
                    {video.description && (
                      <CardDescription className="line-clamp-2">
                        {video.description}
                      </CardDescription>
                    )}
                  </CardHeader>

                  <CardContent className="flex-1 flex flex-col justify-end mt-auto">
                    <Button
                      className="w-full gradient-primary shadow-glow hover:opacity-90 transition-opacity"
                      onClick={() => navigate(`/video/${video.id}`)}
                    >
                      <Play className="h-4 w-4 mr-2" />
                      {isCompleted ? t('videos.completed') : progressPercentage > 0 ? t('videos.continue') : t('videos.watchNow')}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          // Multiple countries - show tabs
          <Tabs value={activeCountry} onValueChange={setActiveCountry} className="w-full">
            <TabsList className="grid w-full gap-2 mb-6" style={{ gridTemplateColumns: `repeat(${Math.min(countries.length, 5)}, 1fr)` }}>
              {countries.map((country) => (
                <TabsTrigger key={country} value={country} className="text-sm font-medium">
                  {country}
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {videosByCountry[country].length}
                  </Badge>
                </TabsTrigger>
              ))}
            </TabsList>

            {countries.map((country) => (
              <TabsContent key={country} value={country}>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                  {videosByCountry[country].map((video) => {
                    const videoProgress = getProgress(video.id);
                    const isCompleted = videoProgress?.completed || false;
                    const progressPercentage = videoProgress?.progress_percentage || 0;

                    return (
                      <Card key={video.id} className="shadow-card hover:shadow-glow transition-all overflow-hidden group flex flex-col h-full">
                        <div className="relative aspect-video bg-secondary overflow-hidden">
                          {video.thumbnail_url ? (
                            <img
                              src={video.thumbnail_url}
                              alt={video.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Play className="h-16 w-16 text-muted-foreground" />
                            </div>
                          )}
                          
                          {isCompleted && (
                            <div className="absolute top-2 right-2 bg-green-500 rounded-full p-2">
                              <CheckCircle className="h-5 w-5 text-white" />
                            </div>
                          )}

                          {progressPercentage > 0 && !isCompleted && (
                            <div className="absolute bottom-0 left-0 w-full h-1 bg-secondary">
                              <div
                                className="h-full gradient-primary transition-all"
                                style={{ width: `${progressPercentage}%` }}
                              />
                            </div>
                          )}
                        </div>

                        <CardHeader className="flex-shrink-0">
                          <div className="flex items-start justify-between gap-2">
                            <CardTitle className="text-lg line-clamp-2">{video.title}</CardTitle>
                            {video.duration && (
                              <Badge variant="secondary" className="flex items-center gap-1 shrink-0">
                                <Clock className="h-3 w-3" />
                                {formatDuration(video.duration)}
                              </Badge>
                            )}
                          </div>
                          {video.description && (
                            <CardDescription className="line-clamp-2">
                              {video.description}
                            </CardDescription>
                          )}
                        </CardHeader>

                        <CardContent className="flex-1 flex flex-col justify-end mt-auto">
                          <Button
                            className="w-full gradient-primary shadow-glow hover:opacity-90 transition-opacity"
                            onClick={() => navigate(`/video/${video.id}`)}
                          >
                            <Play className="h-4 w-4 mr-2" />
                            {isCompleted ? t('videos.completed') : progressPercentage > 0 ? t('videos.continue') : t('videos.watchNow')}
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}
      </div>
    </DashboardLayout>
  );
}
