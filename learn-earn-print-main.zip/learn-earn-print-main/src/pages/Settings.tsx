import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "@/lib/themes";
import { useI18n, Language } from "@/lib/i18n";
import { Palette, Check, Globe, Image as ImageIcon, Plus, Trash2, Receipt, Save } from "lucide-react";
import { toast } from "sonner";
import api from "@/lib/api-client";
import { useAuth } from "@/lib/auth-new";
import { CountryFlag } from "@/components/CountryFlag";

export default function Settings() {
  const { user } = useAuth();
  const { currentTheme, setTheme, availableThemes } = useTheme();
  const { language, setLanguage, t } = useI18n();
  const [logoUrl, setLogoUrl] = useState('');
  const [newLogoUrl, setNewLogoUrl] = useState('');
  const [newLogoName, setNewLogoName] = useState('');
  const [selectedPages, setSelectedPages] = useState<string[]>([]);
  const [savedLogos, setSavedLogos] = useState<Array<{ id: string; name: string; url: string }>>([]);
  const [logosByLanguage, setLogosByLanguage] = useState<Record<Language, { url: string; pages: string[] }>>({
    ro: { url: '', pages: [] },
    en: { url: '', pages: [] },
    fr: { url: '', pages: [] },
    it: { url: '', pages: [] },
    es: { url: '', pages: [] },
    de: { url: '', pages: [] },
  });

  // Receipt settings state
  const [selectedCountry, setSelectedCountry] = useState('romania');
  const [receiptSettings, setReceiptSettings] = useState({
    quiz_title: '',
    donation_text_ro: 'Donatie',
    donation_text_en: 'Donation',
    donation_text_fr: 'Donation',
    donation_text_it: 'Donazione',
    donation_text_es: 'Donación',
    donation_text_de: 'Spende',
    romania_store_name: '',
    romania_address: '',
    romania_city: '',
    romania_email: '',
    romania_website: '',
    romania_cui: '',
    romania_phone: '',
    spain_store_name: '',
    spain_address_line1: '',
    spain_address_line2: '',
    spain_phone: '',
    italy_store_name: '',
    italy_company_info: '',
    italy_address: '',
    italy_city: '',
    italy_vat_number: '',
    italy_phone: '',
    france_store_name: '',
    france_address_line1: '',
    france_address_line2: '',
    france_phone: '',
    austria_store_name: '',
    austria_business_name: '',
    austria_address: '',
    austria_city: '',
    germany_slogan: '',
    germany_company_name: '',
    germany_company_legal: '',
    germany_address: '',
    germany_city: '',
    germany_phone: '',
    elvetia_store_name: '',
    elvetia_address: '',
    elvetia_city: '',
    elvetia_uid: '',
    elvetia_phone: '',
    elvetia_email: '',
    elvetia_website: '',
  });
  const [isSavingReceipt, setIsSavingReceipt] = useState(false);

  const availablePages = [
    { id: 'dashboard', labelKey: 'settings.pages.dashboard' },
    { id: 'videos', labelKey: 'settings.pages.videos' },
    { id: 'video-watch', labelKey: 'settings.pages.videoWatch' },
    { id: 'quizzes', labelKey: 'settings.pages.quizzes' },
    { id: 'receipts', labelKey: 'settings.pages.receipts' },
    { id: 'settings', labelKey: 'settings.pages.settings' },
  ];

  useEffect(() => {
    // Load saved logos library
    const savedLogosData = localStorage.getItem('savedLogos');
    if (savedLogosData) {
      setSavedLogos(JSON.parse(savedLogosData));
    }

    // Load current language logo settings
    const saved = localStorage.getItem('logosByLanguage');
    if (saved) {
      const logos = JSON.parse(saved);
      setLogosByLanguage(logos);
      setLogoUrl(logos[language]?.url || '');
      setSelectedPages(logos[language]?.pages || []);
    }

    // Load receipt settings
    loadReceiptSettings();
  }, [language]);

  const loadReceiptSettings = async () => {
    if (!user) return;

    try {
      const response = await api.receipts.getSettings();
      const data = response.data;
      
      if (data) {
        setReceiptSettings({
          quiz_title: (data as any).quiz_title || '',
          donation_text_ro: (data as any).donation_text_ro || 'Donatie',
          donation_text_en: (data as any).donation_text_en || 'Donation',
          donation_text_fr: (data as any).donation_text_fr || 'Donation',
          donation_text_it: (data as any).donation_text_it || 'Donazione',
          donation_text_es: (data as any).donation_text_es || 'Donación',
          donation_text_de: (data as any).donation_text_de || 'Spende',
          romania_store_name: data.romania_store_name || '',
          romania_address: data.romania_address || '',
          romania_city: data.romania_city || '',
          romania_email: data.romania_email || '',
          romania_website: data.romania_website || '',
          romania_cui: data.romania_cui || '',
          romania_phone: data.romania_phone || '',
          spain_store_name: data.spain_store_name || '',
          spain_address_line1: data.spain_address_line1 || '',
          spain_address_line2: data.spain_address_line2 || '',
          spain_phone: data.spain_phone || '',
          italy_store_name: data.italy_store_name || '',
          italy_company_info: data.italy_company_info || '',
          italy_address: data.italy_address || '',
          italy_city: data.italy_city || '',
          italy_vat_number: data.italy_vat_number || '',
          italy_phone: data.italy_phone || '',
          france_store_name: data.france_store_name || '',
          france_address_line1: data.france_address_line1 || '',
          france_address_line2: data.france_address_line2 || '',
          france_phone: data.france_phone || '',
          austria_store_name: data.austria_store_name || '',
          austria_business_name: data.austria_business_name || '',
          austria_address: data.austria_address || '',
          austria_city: data.austria_city || '',
          germany_slogan: data.germany_slogan || '',
          germany_company_name: data.germany_company_name || '',
          germany_company_legal: data.germany_company_legal || '',
          germany_address: data.germany_address || '',
          germany_city: data.germany_city || '',
          germany_phone: data.germany_phone || '',
          elvetia_store_name: data.elvetia_store_name || '',
          elvetia_address: data.elvetia_address || '',
          elvetia_city: data.elvetia_city || '',
          elvetia_uid: data.elvetia_uid || '',
          elvetia_phone: data.elvetia_phone || '',
          elvetia_email: data.elvetia_email || '',
          elvetia_website: data.elvetia_website || '',
        });
      }
    } catch (error) {
      console.error('Error loading receipt settings:', error);
    }
  };

  const handleThemeChange = (themeId: string) => {
    setTheme(themeId);
    toast.success(t('settings.themeApplied') || `Tema "${availableThemes.find(t => t.id === themeId)?.name}" a fost aplicată!`);
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    toast.success(t('settings.languageChanged') || 'Limba a fost schimbată!');
  };

  const handlePageToggle = (pageId: string) => {
    setSelectedPages(prev => 
      prev.includes(pageId) 
        ? prev.filter(p => p !== pageId)
        : [...prev, pageId]
    );
  };

  const handleAddLogoToLibrary = () => {
    if (!newLogoUrl.trim() || !newLogoName.trim()) {
      toast.error(t('settings.fillNameAndUrl') || 'Te rog introdu și nume și URL pentru logo!');
      return;
    }

    const newLogo = {
      id: Date.now().toString(),
      name: newLogoName,
      url: newLogoUrl,
    };

    const updated = [...savedLogos, newLogo];
    setSavedLogos(updated);
    localStorage.setItem('savedLogos', JSON.stringify(updated));
    setNewLogoUrl('');
    setNewLogoName('');
    toast.success(t('settings.logoAddedToLibrary') || 'Logo adăugat în bibliotecă!');
  };

  const handleRemoveLogoFromLibrary = (id: string) => {
    const updated = savedLogos.filter(logo => logo.id !== id);
    setSavedLogos(updated);
    localStorage.setItem('savedLogos', JSON.stringify(updated));
    toast.success(t('settings.logoRemovedFromLibrary') || 'Logo șters din bibliotecă!');
  };

  const handleSelectLogo = (url: string) => {
    setLogoUrl(url);
  };

  const handleLogoSave = () => {
    const updated = { 
      ...logosByLanguage, 
      [language]: { url: logoUrl, pages: selectedPages } 
    };
    setLogosByLanguage(updated);
    localStorage.setItem('logosByLanguage', JSON.stringify(updated));
    toast.success(t('settings.logoSaved') || 'Logo salvat!');
  };

  const handleSaveReceiptSettings = async () => {
    if (!user) return;

    setIsSavingReceipt(true);
    try {
      await api.receipts.updateSettings(receiptSettings);

      toast.success(t('settings.receiptSettings.saved'));
    } catch (error: any) {
      console.error('Error saving receipt settings:', error);
      toast.error(t('settings.errorSaving') + ': ' + error.message);
    } finally {
      setIsSavingReceipt(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in max-w-6xl">
        <div className="flex items-center gap-3 mb-6">
          <Palette className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-4xl font-bold">{t('settings.title')}</h1>
            <p className="text-muted-foreground">
              {t('settings.customizeAppearance')}
            </p>
          </div>
        </div>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6 h-12">
            <TabsTrigger value="general" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              <span>{t('settings.tabs.general')}</span>
            </TabsTrigger>
            <TabsTrigger value="logo" className="flex items-center gap-2">
              <ImageIcon className="h-4 w-4" />
              <span>{t('settings.tabs.logo')}</span>
            </TabsTrigger>
            <TabsTrigger value="receipts" className="flex items-center gap-2">
              <Receipt className="h-4 w-4" />
              <span>{t('settings.tabs.receipts')}</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6 mt-6">
            {/* Language Settings */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  {t('settings.language')}
                </CardTitle>
                <CardDescription>
                  {t('settings.selectLanguage')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Select value={language} onValueChange={handleLanguageChange}>
                  <SelectTrigger className="w-64">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ro"><CountryFlag country="ro" className="mr-2" /> Română</SelectItem>
                    <SelectItem value="en"><CountryFlag country="en" className="mr-2" /> English</SelectItem>
                    <SelectItem value="fr"><CountryFlag country="fr" className="mr-2" /> Français</SelectItem>
                    <SelectItem value="it"><CountryFlag country="it" className="mr-2" /> Italiano</SelectItem>
                    <SelectItem value="es"><CountryFlag country="es" className="mr-2" /> Español</SelectItem>
                    <SelectItem value="de"><CountryFlag country="de" className="mr-2" /> Deutsch</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Theme Settings */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  {t('settings.themes.title')}
                </CardTitle>
                <CardDescription>
                  {t('settings.themes.description')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <RadioGroup value={currentTheme.id} onValueChange={handleThemeChange}>
                  <div className="grid gap-4">
                    {availableThemes.map((theme) => (
                      <div
                        key={theme.id}
                        className="relative flex items-start space-x-3 rounded-lg border p-4 hover:bg-accent/50 transition-colors cursor-pointer"
                        onClick={() => handleThemeChange(theme.id)}
                      >
                        <RadioGroupItem value={theme.id} id={theme.id} className="mt-1" />
                        <div className="flex-1 min-w-0">
                          <Label htmlFor={theme.id} className="cursor-pointer">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">{t(`settings.themes.${theme.id}.name`)}</span>
                              {currentTheme.id === theme.id && (
                                <Check className="h-4 w-4 text-primary" />
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              {t(`settings.themes.${theme.id}.description`)}
                            </p>
                          </Label>
                          <div className="flex gap-2 mt-3">
                            <div
                              className="w-8 h-8 rounded border shadow-sm"
                              style={{ backgroundColor: `hsl(${theme.colors.primary})` }}
                              title={t('settings.themes.primary')}
                            />
                            <div
                              className="w-8 h-8 rounded border shadow-sm"
                              style={{ backgroundColor: `hsl(${theme.colors.secondary})` }}
                              title={t('settings.themes.secondary')}
                            />
                            <div
                              className="w-8 h-8 rounded border shadow-sm"
                              style={{ backgroundColor: `hsl(${theme.colors.accent})` }}
                              title={t('settings.themes.accent')}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </RadioGroup>

                <div className="mt-6 p-4 rounded-lg bg-muted">
                  <p className="text-sm text-muted-foreground">
                    💡 <strong>{t('settings.themes.tip')}:</strong> {t('settings.themes.tipText')}
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logo" className="space-y-6 mt-6">
            {/* Logo Settings */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="h-5 w-5" />
                  {t('settings.logo')} ({language.toUpperCase()})
                </CardTitle>
                <CardDescription>
                  {t('settings.uploadLogo')} {t('settings.forLanguage')} {language.toUpperCase()}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
            {/* Add new logo to library */}
            <div className="space-y-3 p-4 border rounded-lg bg-muted/30">
              <div className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                <Label className="font-semibold">{t('settings.receiptSettings.addLogoToLibrary')}</Label>
              </div>
              <div className="space-y-2">
                <Input
                  type="text"
                  placeholder={t('settings.logoNamePlaceholder')}
                  value={newLogoName}
                  onChange={(e) => setNewLogoName(e.target.value)}
                />
                <Input
                  type="url"
                  placeholder="https://example.com/logo.png"
                  value={newLogoUrl}
                  onChange={(e) => setNewLogoUrl(e.target.value)}
                />
                <Button onClick={handleAddLogoToLibrary} className="w-full" size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  {t('settings.logo.addToLibrary')}
                </Button>
              </div>
            </div>

            {/* Saved logos library */}
            {savedLogos.length > 0 && (
              <div className="space-y-3">
                <Label className="font-semibold">{t('settings.logo.selectFromLibrary')}</Label>
                <div className="grid grid-cols-3 gap-3 max-h-96 overflow-y-auto">
                  {savedLogos.map(logo => (
                    <div 
                      key={logo.id}
                      className={`relative border rounded-lg p-3 cursor-pointer transition-all hover:border-primary ${
                        logoUrl === logo.url ? 'border-primary bg-primary/5' : ''
                      }`}
                      onClick={() => handleSelectLogo(logo.url)}
                    >
                      <div className="flex flex-col gap-2">
                        <div className="h-16 flex items-center justify-center">
                          <img 
                            src={logo.url} 
                            alt={logo.name}
                            className="max-h-16 max-w-full object-contain"
                            onError={(e) => {
                              e.currentTarget.src = '';
                              e.currentTarget.alt = t('settings.logo.error');
                            }}
                          />
                        </div>
                        <p className="text-xs text-center font-medium truncate">{logo.name}</p>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="absolute top-1 right-1 h-6 w-6"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemoveLogoFromLibrary(logo.id);
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                      {logoUrl === logo.url && (
                        <Check className="absolute bottom-2 right-2 h-4 w-4 text-primary" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Manual URL input */}
            <div className="space-y-2">
              <Label>{t('settings.logo.orEnterUrlManually')}</Label>
              <Input
                type="url"
                placeholder="https://example.com/logo.png"
                value={logoUrl}
                onChange={(e) => setLogoUrl(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>{t('settings.logo.selectPages')}</Label>
              <div className="grid grid-cols-2 gap-3">
                {availablePages.map(page => (
                  <div 
                    key={page.id}
                    className="flex items-center space-x-2"
                  >
                    <input
                      type="checkbox"
                      id={`page-${page.id}`}
                      checked={selectedPages.includes(page.id)}
                      onChange={() => handlePageToggle(page.id)}
                      className="h-4 w-4 rounded border-gray-300"
                    />
                    <Label 
                      htmlFor={`page-${page.id}`}
                      className="cursor-pointer text-sm font-normal"
                    >
                      {t(page.labelKey)}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <Button onClick={handleLogoSave} className="w-full">
              {t('common.save')}
            </Button>
            
            {logosByLanguage[language]?.url && (
              <div className="space-y-2">
                <Label>{t('settings.currentLogo')}</Label>
                <div className="border rounded-lg p-4 bg-muted/50">
                  <img 
                    src={logosByLanguage[language].url} 
                    alt="Logo" 
                    className="h-16 object-contain"
                    onError={(e) => {
                      e.currentTarget.src = '';
                      e.currentTarget.alt = t('settings.logo.loadingError');
                    }}
                  />
                </div>
              </div>
            )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="receipts" className="space-y-6 mt-6">
            {/* Receipt Settings */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  {t('settings.receiptSettings.title')}
                </CardTitle>
                <CardDescription>
                  {t('settings.receiptSettings.description')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
            {/* General Settings */}
            <div className="space-y-2">
              <Label htmlFor="quiz_title">{t('settings.receiptSettings.quizTitle')}</Label>
              <Input
                id="quiz_title"
                value={receiptSettings.quiz_title || ''}
                onChange={(e) => setReceiptSettings({ ...receiptSettings, quiz_title: e.target.value })}
                placeholder={t('settings.receiptSettings.quizTitlePlaceholder')}
              />
              <p className="text-xs text-muted-foreground">
                {t('settings.receiptSettings.quizTitleHint')}
              </p>
            </div>

            <Separator />

            <div className="space-y-4">
              <Label className="text-base font-semibold">{t('settings.receiptSettings.donationTextLabel')}</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="donation_text_ro">{t('settings.receiptSettings.romanian')}</Label>
                  <Input
                    id="donation_text_ro"
                    value={receiptSettings.donation_text_ro || ''}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, donation_text_ro: e.target.value })}
                    placeholder="Donatie"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="donation_text_en">{t('settings.receiptSettings.english')}</Label>
                  <Input
                    id="donation_text_en"
                    value={receiptSettings.donation_text_en || ''}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, donation_text_en: e.target.value })}
                    placeholder="Donation"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="donation_text_fr">{t('settings.receiptSettings.french')}</Label>
                  <Input
                    id="donation_text_fr"
                    value={receiptSettings.donation_text_fr || ''}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, donation_text_fr: e.target.value })}
                    placeholder="Donation"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="donation_text_it">{t('settings.receiptSettings.italian')}</Label>
                  <Input
                    id="donation_text_it"
                    value={receiptSettings.donation_text_it || ''}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, donation_text_it: e.target.value })}
                    placeholder="Donazione"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="donation_text_es">{t('settings.receiptSettings.spanish')}</Label>
                  <Input
                    id="donation_text_es"
                    value={receiptSettings.donation_text_es || ''}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, donation_text_es: e.target.value })}
                    placeholder="Donación"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="donation_text_de">{t('settings.receiptSettings.german')}</Label>
                  <Input
                    id="donation_text_de"
                    value={receiptSettings.donation_text_de || ''}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, donation_text_de: e.target.value })}
                    placeholder="Spende"
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                {t('settings.receiptSettings.donationTextHint')}
              </p>
            </div>

            <Separator />

            <div className="space-y-4">
              <Label className="text-base font-semibold">{t('settings.receiptSettings.selectCountry')}</Label>
              <p className="text-sm text-muted-foreground">
                {t('settings.receiptSettings.selectCountryHint')}
              </p>
              <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="romania"><CountryFlag country="ro" className="mr-2" /> România (RON)</SelectItem>
                  <SelectItem value="franta"><CountryFlag country="fr" className="mr-2" /> Franța (EUR)</SelectItem>
                  <SelectItem value="italia"><CountryFlag country="it" className="mr-2" /> Italia (EUR)</SelectItem>
                  <SelectItem value="spania"><CountryFlag country="es" className="mr-2" /> Spania (EUR)</SelectItem>
                  <SelectItem value="austria"><CountryFlag country="at" className="mr-2" /> Austria (EUR)</SelectItem>
                  <SelectItem value="germania"><CountryFlag country="de" className="mr-2" /> Germania (EUR)</SelectItem>
                  <SelectItem value="elvetia"><CountryFlag country="ch" className="mr-2" /> Elveția (CHF)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Tabs value={selectedCountry} onValueChange={setSelectedCountry} className="w-full">
              <TabsList className="grid w-full grid-cols-7">
                <TabsTrigger value="romania"><CountryFlag country="ro" className="mr-1" /> RON</TabsTrigger>
                <TabsTrigger value="franta"><CountryFlag country="fr" className="mr-1" /> EUR</TabsTrigger>
                <TabsTrigger value="italia"><CountryFlag country="it" className="mr-1" /> EUR</TabsTrigger>
                <TabsTrigger value="spania"><CountryFlag country="es" className="mr-1" /> EUR</TabsTrigger>
                <TabsTrigger value="austria"><CountryFlag country="at" className="mr-1" /> EUR</TabsTrigger>
                <TabsTrigger value="germania"><CountryFlag country="de" className="mr-1" /> EUR</TabsTrigger>
                <TabsTrigger value="elvetia"><CountryFlag country="ch" className="mr-1" /> CHF</TabsTrigger>
              </TabsList>

              <TabsContent value="romania" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.storeName')}</Label>
                  <Input
                    value={receiptSettings.romania_store_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, romania_store_name: e.target.value })}
                    placeholder="Ex: MAGAZIN EDUCAȚIONAL"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.address')}</Label>
                  <Input
                    value={receiptSettings.romania_address}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, romania_address: e.target.value })}
                    placeholder="Ex: STR. EDUCAȚIEI NR. 1"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.city')}</Label>
                  <Input
                    value={receiptSettings.romania_city}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, romania_city: e.target.value })}
                    placeholder="Ex: BUCUREȘTI"
                  />
                </div>
                <Separator />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.email')}</Label>
                    <Input
                      type="email"
                      value={receiptSettings.romania_email || ''}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, romania_email: e.target.value })}
                      placeholder="Ex: contact@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.website')}</Label>
                    <Input
                      type="url"
                      value={receiptSettings.romania_website || ''}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, romania_website: e.target.value })}
                      placeholder="Ex: https://www.example.com"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.cui')}</Label>
                    <Input
                      value={receiptSettings.romania_cui || ''}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, romania_cui: e.target.value })}
                      placeholder="Ex: RO12345678"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.phone')}</Label>
                    <Input
                      value={receiptSettings.romania_phone || ''}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, romania_phone: e.target.value })}
                      placeholder="Ex: 021.123.4567"
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="spania" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.storeName')}</Label>
                  <Input
                    value={receiptSettings.spain_store_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, spain_store_name: e.target.value })}
                    placeholder="Ex: TIENDA EDUCATIVA"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.addressLine1')}</Label>
                  <Input
                    value={receiptSettings.spain_address_line1}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, spain_address_line1: e.target.value })}
                    placeholder="Ex: CALLE DE LA EDUCACIÓN, 33"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.addressLine2')}</Label>
                  <Input
                    value={receiptSettings.spain_address_line2}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, spain_address_line2: e.target.value })}
                    placeholder="Ex: 28000 MADRID"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.phone')}</Label>
                  <Input
                    value={receiptSettings.spain_phone}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, spain_phone: e.target.value })}
                    placeholder="Ex: 91 234 56 78"
                  />
                </div>
              </TabsContent>

              <TabsContent value="italia" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.storeName')}</Label>
                  <Input
                    value={receiptSettings.italy_store_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, italy_store_name: e.target.value })}
                    placeholder="Ex: NEGOZIO EDUCATIVO"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.companyInfo')}</Label>
                  <Input
                    value={receiptSettings.italy_company_info}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, italy_company_info: e.target.value })}
                    placeholder="Ex: SOCIETÀ S.P.A. unipersonale"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.address')}</Label>
                  <Input
                    value={receiptSettings.italy_address}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, italy_address: e.target.value })}
                    placeholder="Ex: Via Educazione, 10"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.city')}</Label>
                  <Input
                    value={receiptSettings.italy_city}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, italy_city: e.target.value })}
                    placeholder="Ex: 40138 - Bologna"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.vat')}</Label>
                  <Input
                    value={receiptSettings.italy_vat_number}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, italy_vat_number: e.target.value })}
                    placeholder="Ex: P.Iva 01234567890"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.phone')}</Label>
                  <Input
                    value={receiptSettings.italy_phone}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, italy_phone: e.target.value })}
                    placeholder="Ex: Tel. 051/12345678"
                  />
                </div>
              </TabsContent>

              <TabsContent value="franta" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.storeName')}</Label>
                  <Input
                    value={receiptSettings.france_store_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, france_store_name: e.target.value })}
                    placeholder="Ex: MAGASIN ÉDUCATIF"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.addressLine1')}</Label>
                  <Input
                    value={receiptSettings.france_address_line1}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, france_address_line1: e.target.value })}
                    placeholder="Ex: 33 RUE DE L'ÉDUCATION"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.addressLine2')}</Label>
                  <Input
                    value={receiptSettings.france_address_line2}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, france_address_line2: e.target.value })}
                    placeholder="Ex: 75000 PARIS"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.phone')}</Label>
                  <Input
                    value={receiptSettings.france_phone}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, france_phone: e.target.value })}
                    placeholder="Ex: 01.23.45.67.89"
                  />
                </div>
              </TabsContent>

              <TabsContent value="austria" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.storeName')}</Label>
                  <Input
                    value={receiptSettings.austria_store_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, austria_store_name: e.target.value })}
                    placeholder="Ex: KUNDENBELEG"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.businessName')}</Label>
                  <Input
                    value={receiptSettings.austria_business_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, austria_business_name: e.target.value })}
                    placeholder="Ex: VILLAGE SNACK BAR"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.address')}</Label>
                  <Input
                    value={receiptSettings.austria_address}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, austria_address: e.target.value })}
                    placeholder="Ex: KEGELG 37-39/TOP 7"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.city')}</Label>
                  <Input
                    value={receiptSettings.austria_city}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, austria_city: e.target.value })}
                    placeholder="Ex: 1030 WIEN"
                  />
                </div>
              </TabsContent>

              <TabsContent value="germania" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.slogan')}</Label>
                  <Input
                    value={receiptSettings.germany_slogan}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, germany_slogan: e.target.value })}
                    placeholder="Ex: Ich lasse es®"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.companyName')}</Label>
                  <Input
                    value={receiptSettings.germany_company_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, germany_company_name: e.target.value })}
                    placeholder="Ex: Bildungszentrum"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.companyLegal')}</Label>
                  <Input
                    value={receiptSettings.germany_company_legal}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, germany_company_legal: e.target.value })}
                    placeholder="Ex: Deutschland Inc."
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.address')}</Label>
                  <Input
                    value={receiptSettings.germany_address}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, germany_address: e.target.value })}
                    placeholder="Ex: Am Ostbahnhof 9"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.city')}</Label>
                  <Input
                    value={receiptSettings.germany_city}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, germany_city: e.target.value })}
                    placeholder="Ex: 10243 Berlin"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.phone')}</Label>
                  <Input
                    value={receiptSettings.germany_phone}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, germany_phone: e.target.value })}
                    placeholder="Ex: 030 29364913"
                  />
                </div>
              </TabsContent>

              <TabsContent value="elvetia" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.storeName')}</Label>
                  <Input
                    value={receiptSettings.elvetia_store_name}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, elvetia_store_name: e.target.value })}
                    placeholder="Ex: BILDUNGSGESCHÄFT"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.address')}</Label>
                  <Input
                    value={receiptSettings.elvetia_address}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, elvetia_address: e.target.value })}
                    placeholder="Ex: BILDUNGSSTRASSE 1"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('settings.receiptSettings.city')}</Label>
                  <Input
                    value={receiptSettings.elvetia_city}
                    onChange={(e) => setReceiptSettings({ ...receiptSettings, elvetia_city: e.target.value })}
                    placeholder="Ex: ZÜRICH"
                  />
                </div>
                <Separator />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.uid')}</Label>
                    <Input
                      value={receiptSettings.elvetia_uid}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, elvetia_uid: e.target.value })}
                      placeholder="Ex: CHE-123.456.789"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.phone')}</Label>
                    <Input
                      value={receiptSettings.elvetia_phone}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, elvetia_phone: e.target.value })}
                      placeholder="Ex: +41 44 123 4567"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.email')}</Label>
                    <Input
                      type="email"
                      value={receiptSettings.elvetia_email || ''}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, elvetia_email: e.target.value })}
                      placeholder="Ex: contact@example.ch"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t('settings.receiptSettings.website')}</Label>
                    <Input
                      type="url"
                      value={receiptSettings.elvetia_website || ''}
                      onChange={(e) => setReceiptSettings({ ...receiptSettings, elvetia_website: e.target.value })}
                      placeholder="Ex: https://www.example.ch"
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <Button 
              onClick={handleSaveReceiptSettings} 
              disabled={isSavingReceipt}
              className="w-full"
            >
              {isSavingReceipt ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  {t('settings.receiptSettings.saving')}
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  {t('settings.receiptSettings.save')}
                </>
              )}
            </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
