import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Video, FileQuestion, Receipt, Award, TrendingUp } from "lucide-react";
import api from "@/lib/api-client";
import { CartesianGrid, Line, LineChart, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { useI18n } from "@/lib/i18n";
// @ts-ignore - library has no official TS types
import writtenNumber from "written-number";

export default function Dashboard() {
  const { t } = useI18n();
  const [stats, setStats] = useState({
    totalVideos: 0,
    completedVideos: 0,
    quizzesTaken: 0,
    totalReceipts: 0,
    totalAmount: 0,
  });
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    loadStats();
    
    // Poll for updates every 60 seconds
    const interval = setInterval(() => {
      loadStats();
    }, 60000);

    return () => {
      clearInterval(interval);
    };
  }, []);

  const loadStats = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      if (!user.id) return;

      const [videosResponse, receiptsResponse] = await Promise.all([
        api.videos.getAll(),
        api.receipts.getAll(),
      ]);

      const videosData = videosResponse.data || [];
      const receiptsData = receiptsResponse.data || [];

      const totalAmount = receiptsData.reduce((sum: number, r: any) => {
        const amount = typeof r.amount === 'string' ? parseFloat(r.amount) : r.amount;
        return sum + (isNaN(amount) ? 0 : amount);
      }, 0);

      setStats({
        totalVideos: videosData.length,
        completedVideos: 0, // Video progress API not implemented yet
        quizzesTaken: 0, // Quiz submissions API not implemented yet
        totalReceipts: receiptsData.length,
        totalAmount,
      });

      // Prepare chart data - group by month
      if (receiptsData.length > 0) {
        const monthlyData: Record<string, number> = {};
        
        receiptsData.forEach((receipt: any) => {
          const date = new Date(receipt.generated_at);
          const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          
          if (!monthlyData[monthKey]) {
            monthlyData[monthKey] = 0;
          }
          const amount = typeof receipt.amount === 'string' ? parseFloat(receipt.amount) : receipt.amount;
          monthlyData[monthKey] += isNaN(amount) ? 0 : amount;
        });

        const chartDataArray = Object.entries(monthlyData).map(([key, amount]) => {
          const [year, month] = key.split('-');
          const date = new Date(parseInt(year), parseInt(month) - 1);
          return {
            month: date.toLocaleDateString('ro-RO', { month: 'short', year: 'numeric' }),
            suma: parseFloat(amount.toFixed(2)),
          };
        });

        setChartData(chartDataArray);
      }
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const cards = [
    { title: t('dashboard.activeVideos'), value: stats.totalVideos, icon: Video, color: "from-blue-500 to-cyan-500" },
    { title: t('dashboard.completedVideos'), value: stats.completedVideos, icon: Award, color: "from-purple-500 to-pink-500" },
    { title: t('dashboard.quizzesTaken'), value: stats.quizzesTaken, icon: FileQuestion, color: "from-green-500 to-emerald-500" },
    { title: t('dashboard.receiptsGenerated'), value: stats.totalReceipts, icon: Receipt, color: "from-orange-500 to-red-500" },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 via-emerald-500/10 to-teal-500/10 rounded-2xl blur-3xl -z-10" />
          <div className="flex items-center gap-4 mb-4">
            <div className="relative">
              <img 
                src="/newlolgo.jpg" 
                alt="Logo UNICEFO" 
                className="h-24 w-24 md:h-32 md:w-32 lg:h-36 lg:w-36 object-contain rounded-2xl bg-white/10 p-3 shadow-lg"
                onError={(e) => {
                  // Fallback to icon if logo fails to load
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div className="absolute -bottom-1 -right-1 p-2 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg">
                <Award className="h-4 w-4 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                {t('dashboard.title')}
              </h1>
              <p className="text-muted-foreground">{t('dashboard.welcome')}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {cards.map((card) => (
            <Card key={card.title} className="shadow-card hover:shadow-glow transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {card.title}
                </CardTitle>
                <div className={`p-2 rounded-lg bg-gradient-to-br ${card.color}`}>
                  <card.icon className="h-4 w-4 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{card.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  {t('dashboard.totalDonations')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-foreground">
                  {stats.totalAmount.toFixed(2)} <span className="text-2xl text-muted-foreground">RON</span>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  suma: {writtenNumber(Math.floor(stats.totalAmount), { lang: 'ro' })} lei și {String(Math.round((stats.totalAmount % 1) * 100)).padStart(2, '0')} bani
                </div>
              </CardContent>
        </Card>

        {chartData.length > 0 && (
          <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  {t('dashboard.revenueEvolution')}
                </CardTitle>
              </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="month" 
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      className="text-xs"
                      tick={{ fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="rounded-lg border bg-background p-2 shadow-sm">
                              <div className="grid grid-cols-2 gap-2">
                                <div className="flex flex-col">
                                  <span className="text-[0.70rem] uppercase text-muted-foreground">
                                    Lună
                                  </span>
                                  <span className="font-bold text-muted-foreground">
                                    {payload[0].payload.month}
                                  </span>
                                </div>
                                <div className="flex flex-col">
                                  <span className="text-[0.70rem] uppercase text-muted-foreground">
                                    Sumă
                                  </span>
                                  <span className="font-bold">
                                    {payload[0].value} RON
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="suma" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      dot={{ fill: 'hsl(var(--primary))' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
