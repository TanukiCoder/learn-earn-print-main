import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/lib/auth-new";
import { ThemeProvider } from "@/lib/themes";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Videos from "./pages/Videos";
import VideoWatch from "./pages/VideoWatch";
import Receipts from "./pages/Receipts";
import Quizzes from "./pages/Quizzes";
import Settings from "./pages/Settings";
import AdminDashboard from "./pages/admin/AdminDashboard";
import Users from "./pages/admin/Users";
import ReceiptSettings from "./pages/admin/ReceiptSettings";
import Sessions from "./pages/admin/Sessions";
import AdminReceipts from "./pages/admin/AdminReceipts";
import AdminVideos from "./pages/admin/Videos";
import AdminQuizzes from "./pages/admin/Quizzes";
import AppSettings from "./pages/admin/AppSettings";
import Notifications from "./pages/admin/Notifications";
import AccountDeactivated from "./pages/AccountDeactivated";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
          <Routes>
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/account-deactivated" element={<AccountDeactivated />} />
            
            {/* User routes */}
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/videos" element={<ProtectedRoute><Videos /></ProtectedRoute>} />
            <Route path="/video/:id" element={<ProtectedRoute><VideoWatch /></ProtectedRoute>} />
            <Route path="/quizzes" element={<ProtectedRoute><Quizzes /></ProtectedRoute>} />
            <Route path="/receipts" element={<ProtectedRoute><Receipts /></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
            
            {/* Admin routes */}
            <Route path="/admin" element={<ProtectedRoute requireAdmin><AdminDashboard /></ProtectedRoute>} />
            <Route path="/admin/users" element={<ProtectedRoute requireAdmin><Users /></ProtectedRoute>} />
            <Route path="/admin/videos" element={<ProtectedRoute requireAdmin><AdminVideos /></ProtectedRoute>} />
            <Route path="/admin/quizzes" element={<ProtectedRoute requireAdmin><AdminQuizzes /></ProtectedRoute>} />
            <Route path="/admin/receipt-settings" element={<ProtectedRoute requireAdmin><ReceiptSettings /></ProtectedRoute>} />
            <Route path="/admin/app-settings" element={<ProtectedRoute requireAdmin><AppSettings /></ProtectedRoute>} />
            <Route path="/admin/sessions" element={<ProtectedRoute requireAdmin><Sessions /></ProtectedRoute>} />
            <Route path="/admin/receipts" element={<ProtectedRoute requireAdmin><AdminReceipts /></ProtectedRoute>} />
            <Route path="/admin/notifications" element={<ProtectedRoute requireAdmin><Notifications /></ProtectedRoute>} />

            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
