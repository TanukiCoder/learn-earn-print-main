interface ReceiptTemplate {
  country: string;
  name: string;
  flag: string;
  currency: string;
  headerFormat: (settings: any) => string[];
  detailsFormat: (data: any) => string[];
}

export const receiptTemplates: Record<string, ReceiptTemplate> = {
  romania: {
    country: 'romania',
    name: 'România',
    flag: '🇷🇴',
    currency: 'RON',
    headerFormat: (settings) => {
      // Use configured CUI or generate realistic one
      const cuiNumber = settings.romania_cui || (() => {
        const random = Math.floor(Math.random() * 9000000) + 1000000; // 7-8 digits
        return `RO${random}`;
      })();
      
      // Use configured phone or generate realistic one
      const phoneNumber = settings.romania_phone || (() => {
        const areaCode = ['021', '031', '026', '025', '023'][Math.floor(Math.random() * 5)];
        const first = Math.floor(Math.random() * 900) + 100;
        const second = Math.floor(Math.random() * 9000) + 1000;
        return `${areaCode}.${first}.${second}`;
      })();
      
      const headerLines = [
        settings.romania_store_name || 'MAGAZIN EDUCATIONAL',
        settings.romania_address || 'STR. EDUCATIEI NR. 1',
        settings.romania_city || 'BUCURESTI',
        `CUI: ${cuiNumber}`,
        `Tel: ${phoneNumber}`,
      ];
      
      // Add email if configured
      if (settings.romania_email) {
        headerLines.push(`Email: ${settings.romania_email}`);
      }
      
      // Add website if configured
      if (settings.romania_website) {
        headerLines.push(`Web: ${settings.romania_website}`);
      }
      
      headerLines.push('');
      headerLines.push('--------------------------------');
      
      // Add 6-digit random number for receipt header
      const randomNumber = Math.floor(Math.random() * 900000) + 100000; // Generates 6-digit number (100000-999999)
      headerLines.push(randomNumber.toString());
      headerLines.push('--------------------------------');
      
      // Only add header text if it exists in settings and is not just numbers
      if (settings.header_text && !/^\d+$/.test(settings.header_text.trim())) {
        headerLines.push(settings.header_text);
        headerLines.push('--------------------------------');
      }
      
      return headerLines;
    },
    detailsFormat: (data) => {
      const total = parseFloat(data.amount);
      const date = new Date();
      const dateStr = date.toLocaleDateString('ro-RO', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
      });
      const timeStr = date.toLocaleTimeString('ro-RO', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
      });
      
      // Get donation text based on user language or country
      const userLang = (data.settings as any)?.user_language || 'ro';
      const donationText = (data.settings as any)?.[`donation_text_${userLang}`] || 
                          (data.settings as any)?.donation_text_ro || 'Donatie';
      
      return [
        '',
        `BON NR: ${data.receiptNumber}`,
        `DATA: ${dateStr}`,
        `ORA: ${timeStr}`,
        '',
        '================================',
        '',
        'PRODUS/SERVICIU          VALOARE',
        '',
        donationText,
        `1 buc              ${total.toFixed(2)} RON`,
        '',
        '--------------------------------',
        '',
        `SUBTOTAL:          ${total.toFixed(2)} RON`,
        'TVA 0%:                  0.00 RON',
        '',
        `TOTAL DE PLATA:    ${total.toFixed(2)} RON`,
        '',
        '================================',
        '',
        'PLATA: CARD',
        `SUMA INCASATA:     ${total.toFixed(2)} RON`,
        '',
        '================================',
        '',
        'Va multumim!',
        'Document fiscal',
        'Conform Legii 227/2015',
      ];
    }
  },
  spania: {
    country: 'spania',
    name: 'Spania',
    flag: '🇪🇸',
    currency: 'EUR',
    headerFormat: (settings) => {
      // Generate realistic Spanish phone number
      const phoneNumber = settings.spain_phone || (() => {
        const areaCode = ['91', '93', '96', '95', '92'][Math.floor(Math.random() * 5)];
        const part1 = Math.floor(Math.random() * 900) + 100;
        const part2 = Math.floor(Math.random() * 90) + 10;
        const part3 = Math.floor(Math.random() * 90) + 10;
        return `${areaCode} ${part1} ${part2} ${part3}`;
      })();
      
      // Generate realistic Spanish CIF/NIF
      const cifNumber = settings.spain_cif || (() => {
        const letters = 'ABCDEFGHJKLMNPQRSUVW';
        const letter = letters[Math.floor(Math.random() * letters.length)];
        const numbers = Array.from({ length: 7 }, () => Math.floor(Math.random() * 10)).join('');
        const check = Math.floor(Math.random() * 10);
        return `${letter}${numbers}${check}`;
      })();
      
      const headerLines = [
        settings.spain_store_name || 'TIENDA EDUCATIVA',
        settings.spain_address_line1 || 'C/ DE LA EDUCACION, 33',
        settings.spain_address_line2 || '28000 MADRID',
        `CIF: ${cifNumber}`,
        `Tel: ${phoneNumber}`,
      ];
      
      if (settings.spain_email) {
        headerLines.push(`Email: ${settings.spain_email}`);
      }
      if (settings.spain_website) {
        headerLines.push(`Web: ${settings.spain_website}`);
      }
      
      headerLines.push('');
      headerLines.push('================================');
      // Add 6-digit random number for receipt header
      const randomNumber = Math.floor(Math.random() * 900000) + 100000; // Generates 6-digit number (100000-999999)
      headerLines.push(randomNumber.toString());
      headerLines.push('================================');
      // Only add header text if it exists in settings and is not just numbers
      if (settings.header_text && !/^\d+$/.test(settings.header_text.trim())) {
        headerLines.push(settings.header_text);
        headerLines.push('================================');
      }
      
      return headerLines;
    },
    detailsFormat: (data) => {
      const total = parseFloat(data.amount);
      const date = new Date();
      const dateStr = date.toLocaleDateString('es-ES', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
      });
      const timeStr = date.toLocaleTimeString('es-ES', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
      });
      
      // Get donation text based on user language or country
      const userLang = (data.settings as any)?.user_language || 'es';
      const donationText = (data.settings as any)?.[`donation_text_${userLang}`] || 
                          (data.settings as any)?.donation_text_es || 'Donación';
      
      return [
        '',
        `TICKET: ${data.receiptNumber}`,
        `${dateStr} ${timeStr}`,
        '',
        '================================',
        '',
        'DESCRIPCIÓN         CANT  IMPORTE',
        '',
        donationText,
        `                       1  ${total.toFixed(2)}`,
        '',
        '--------------------------------',
        '',
        `BASE IMPONIBLE:        ${total.toFixed(2)}`,
        'IVA 0%:                     0.00',
        '',
        `TOTAL:                 ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'TARJETA',
        `IMPORTE:               ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'Gracias por su visita',
      ];
    }
  },
  italia: {
    country: 'italia',
    name: 'Italia',
    flag: '🇮🇹',
    currency: 'EUR',
    headerFormat: (settings) => {
      // Generate realistic Italian VAT number (Partita IVA - 11 digits)
      const vatNumber = settings.italy_vat_number || (() => {
        const digits = Array.from({ length: 11 }, () => Math.floor(Math.random() * 10)).join('');
        return `P.IVA ${digits}`;
      })();
      
      // Generate realistic Italian phone number
      const phoneNumber = settings.italy_phone || (() => {
        const areaCode = ['02', '06', '051', '055', '081', '011', '041'][Math.floor(Math.random() * 7)];
        const number = Math.floor(Math.random() * 9000000) + 1000000; // 7 digits
        return `Tel. ${areaCode}/${number}`;
      })();
      
      const headerLines = [
        settings.italy_store_name || 'NEGOZIO EDUCATIVO',
        settings.italy_company_info || 'S.R.L.',
        settings.italy_address || 'Via Educazione, 10',
        settings.italy_city || '00100 Roma RM',
        vatNumber,
        phoneNumber,
      ];
      
      if (settings.italy_email) {
        headerLines.push(`Email: ${settings.italy_email}`);
      }
      if (settings.italy_website) {
        headerLines.push(`Web: ${settings.italy_website}`);
      }
      
      headerLines.push('');
      headerLines.push('================================');
      headerLines.push('   SCONTRINO FISCALE');
      headerLines.push('================================');
      // Add 6-digit random number for receipt header
      const randomNumber = Math.floor(Math.random() * 900000) + 100000; // Generates 6-digit number (100000-999999)
      headerLines.push(randomNumber.toString());
      headerLines.push('================================');
      // Only add header text if it exists in settings and is not just numbers
      if (settings.header_text && !/^\d+$/.test(settings.header_text.trim())) {
        headerLines.push(settings.header_text);
        headerLines.push('================================');
      }
      
      return headerLines;
    },
    detailsFormat: (data) => {
      const total = parseFloat(data.amount);
      const date = new Date();
      const dateStr = date.toLocaleDateString('it-IT', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
      });
      const timeStr = date.toLocaleTimeString('it-IT', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
      });
      
      // Get donation text based on user language or country
      const userLang = (data.settings as any)?.user_language || 'it';
      const donationText = (data.settings as any)?.[`donation_text_${userLang}`] || 
                          (data.settings as any)?.donation_text_it || 'Donazione';
      
      return [
        '',
        `N. ${data.receiptNumber}`,
        `${dateStr} ${timeStr}`,
        '',
        '================================',
        '',
        'DESCRIZIONE         QTÀ  IMPORTO',
        '',
        donationText,
        `                      1  ${total.toFixed(2)}`,
        '',
        '--------------------------------',
        '',
        `TOTALE EUR           ${total.toFixed(2)}`,
        '',
        'IVA 0%                    0.00',
        '',
        '================================',
        '',
        `CONTANTI EUR         ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'Grazie e arrivederci',
      ];
    }
  },
  franta: {
    country: 'franta',
    name: 'Franța',
    flag: '🇫🇷',
    currency: 'EUR',
    headerFormat: (settings) => {
      // Generate realistic French SIRET (14 digits)
      const siret = settings.france_siret || (() => {
        const part1 = Math.floor(Math.random() * 900000000) + 100000000; // 9 digits
        const part2 = Math.floor(Math.random() * 90000) + 10000; // 5 digits
        return `${part1} ${part2}`;
      })();
      
      // Generate realistic French VAT number
      const vatNumber = settings.france_vat || (() => {
        const part1 = Math.floor(Math.random() * 90) + 10;
        const part2 = Math.floor(Math.random() * 900000000) + 100000000;
        return `FR ${part1} ${part2}`;
      })();
      
      // Generate realistic French phone number
      const phoneNumber = settings.france_phone || (() => {
        const areaCode = ['01', '02', '03', '04', '05', '06', '07', '09'][Math.floor(Math.random() * 8)];
        const part1 = Math.floor(Math.random() * 90) + 10;
        const part2 = Math.floor(Math.random() * 90) + 10;
        const part3 = Math.floor(Math.random() * 90) + 10;
        const part4 = Math.floor(Math.random() * 90) + 10;
        return `${areaCode} ${part1} ${part2} ${part3} ${part4}`;
      })();
      
      const headerLines = [
        settings.france_store_name || 'MAGASIN EDUCATIF',
        settings.france_address_line1 || '33 RUE DE L\'EDUCATION',
        settings.france_address_line2 || '75000 PARIS',
        `Tel: ${phoneNumber}`,
        `SIRET: ${siret}`,
        `TVA: ${vatNumber}`,
      ];
      
      if (settings.france_email) {
        headerLines.push(`Email: ${settings.france_email}`);
      }
      if (settings.france_website) {
        headerLines.push(`Web: ${settings.france_website}`);
      }
      
      headerLines.push('');
      headerLines.push('================================');
      // Add 6-digit random number for receipt header
      const randomNumber = Math.floor(Math.random() * 900000) + 100000; // Generates 6-digit number (100000-999999)
      headerLines.push(randomNumber.toString());
      headerLines.push('================================');
      // Only add header text if it exists in settings and is not just numbers
      if (settings.header_text && !/^\d+$/.test(settings.header_text.trim())) {
        headerLines.push(settings.header_text);
        headerLines.push('================================');
      }
      
      return headerLines;
    },
    detailsFormat: (data) => {
      const total = parseFloat(data.amount);
      const date = new Date();
      const dateStr = date.toLocaleDateString('fr-FR', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
      });
      const timeStr = date.toLocaleTimeString('fr-FR', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
      });
      
      // Get donation text based on user language or country
      const userLang = (data.settings as any)?.user_language || 'fr';
      const donationText = (data.settings as any)?.[`donation_text_${userLang}`] || 
                          (data.settings as any)?.donation_text_fr || 'Don';
      
      return [
        '',
        `TICKET N: ${data.receiptNumber}`,
        `Le ${dateStr} a ${timeStr}`,
        '',
        '================================',
        '',
        'DÉSIGNATION             P.U. QTÉ',
        '',
        donationText,
        `${total.toFixed(2)}EUR           1`,
        '',
        '--------------------------------',
        '',
        `TOTAL TTC:           ${total.toFixed(2)}EUR`,
        '',
        'Dont TVA 0.00%:           0.00EUR',
        '',
        '================================',
        '',
        `ESPÈCES:             ${total.toFixed(2)}EUR`,
        '',
        '================================',
        '',
        'Merci de votre visite',
        'À bientôt',
      ];
    }
  },
  austria: {
    country: 'austria',
    name: 'Austria',
    flag: '🇦🇹',
    currency: 'EUR',
    headerFormat: (settings) => {
      // Generate realistic Austrian UID (Umsatzsteuer-ID)
      const uidNumber = settings.austria_uid || (() => {
        const prefix = 'AT';
        const numbers = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10)).join('');
        return `${prefix}U${numbers}`;
      })();
      
      const headerLines = [
        settings.austria_business_name || 'BILDUNGSGESCHAEFT',
        settings.austria_address || 'KEGELG 37-39/TOP 7',
        settings.austria_city || '1030 WIEN',
        `UID: ${uidNumber}`,
      ];
      
      if (settings.austria_email) {
        headerLines.push(`Email: ${settings.austria_email}`);
      }
      if (settings.austria_website) {
        headerLines.push(`Web: ${settings.austria_website}`);
      }
      
      headerLines.push('');
      headerLines.push('================================');
      headerLines.push('      KUNDENBELEG');
      headerLines.push('================================');
      // Add 6-digit random number for receipt header
      const randomNumber = Math.floor(Math.random() * 900000) + 100000; // Generates 6-digit number (100000-999999)
      headerLines.push(randomNumber.toString());
      headerLines.push('================================');
      // Only add header text if it exists in settings and is not just numbers
      if (settings.header_text && !/^\d+$/.test(settings.header_text.trim())) {
        headerLines.push(settings.header_text);
        headerLines.push('================================');
      }
      
      return headerLines;
    },
    detailsFormat: (data) => {
      const total = parseFloat(data.amount);
      const date = new Date();
      const dateStr = date.toLocaleDateString('de-AT', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
      });
      const timeStr = date.toLocaleTimeString('de-AT', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
      });
      
      // Get donation text based on user language or country
      const userLang = (data.settings as any)?.user_language || 'de';
      const donationText = (data.settings as any)?.[`donation_text_${userLang}`] || 
                          (data.settings as any)?.donation_text_de || 'Spende';
      
      return [
        '',
        `BELEG NR: ${data.receiptNumber}`,
        `${dateStr} ${timeStr}`,
        '',
        '================================',
        '',
        'ARTIKEL              ANZ  BETRAG',
        '',
        donationText,
        `                       1  ${total.toFixed(2)}`,
        '',
        '--------------------------------',
        '',
        `NETTO:                 ${total.toFixed(2)}`,
        'USt 0%:                     0.00',
        '',
        `GESAMT EUR:            ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'KARTE',
        `BETRAG:                ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'Vielen Dank!',
      ];
    }
  },
  germania: {
    country: 'germania',
    name: 'Germania',
    flag: '🇩🇪',
    currency: 'EUR',
    headerFormat: (settings) => {
      // Generate realistic German VAT number (USt-IdNr)
      const vatNumber = settings.germany_vat || (() => {
        const prefix = 'DE';
        const numbers = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10)).join('');
        return `${prefix}${numbers}`;
      })();
      
      // Generate realistic German tax number (Steuernummer)
      const taxNumber = settings.germany_tax_number || (() => {
        const parts = [
          Math.floor(Math.random() * 900) + 100, // 3 digits
          Math.floor(Math.random() * 9000) + 1000, // 4 digits
          Math.floor(Math.random() * 900) + 100 // 3 digits
        ];
        return `${parts[0]}/${parts[1]}/${parts[2]}`;
      })();
      
      // Generate realistic phone number
      const phoneNumber = settings.germany_phone || (() => {
        const areaCode = ['030', '040', '089', '021', '0221'][Math.floor(Math.random() * 5)];
        const number = Math.floor(Math.random() * 90000000) + 10000000; // 8 digits
        return `${areaCode} ${number}`;
      })();
      
      const headerLines = [
        settings.germany_company_name || 'BILDUNGSZENTRUM',
        settings.germany_company_legal || 'GMBH',
        settings.germany_address || 'Am Ostbahnhof 9',
        settings.germany_city || '10243 Berlin',
        `Tel: ${phoneNumber}`,
        `USt-IdNr: ${vatNumber}`,
        `St.Nr: ${taxNumber}`,
      ];
      
      if (settings.germany_email) {
        headerLines.push(`Email: ${settings.germany_email}`);
      }
      if (settings.germany_website) {
        headerLines.push(`Web: ${settings.germany_website}`);
      }
      
      headerLines.push('');
      headerLines.push('================================');
      headerLines.push('         KASSENBON');
      headerLines.push('================================');
      // Add 6-digit random number for receipt header
      const randomNumber = Math.floor(Math.random() * 900000) + 100000; // Generates 6-digit number (100000-999999)
      headerLines.push(randomNumber.toString());
      headerLines.push('================================');
      // Only add header text if it exists in settings and is not just numbers
      if (settings.header_text && !/^\d+$/.test(settings.header_text.trim())) {
        headerLines.push(settings.header_text);
        headerLines.push('================================');
      }
      
      return headerLines;
    },
    detailsFormat: (data) => {
      const total = parseFloat(data.amount);
      const date = new Date();
      const dateStr = date.toLocaleDateString('de-DE', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
      });
      const timeStr = date.toLocaleTimeString('de-DE', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
      });
      
      // Get donation text based on user language or country
      const userLang = (data.settings as any)?.user_language || 'de';
      const donationText = (data.settings as any)?.[`donation_text_${userLang}`] || 
                          (data.settings as any)?.donation_text_de || 'Spende';
      
      return [
        '',
        `BELEG NR: ${data.receiptNumber}`,
        `${dateStr} ${timeStr}`,
        '',
        '================================',
        '',
        'ARTIKEL              ANZ  BETRAG',
        '',
        donationText,
        `                       1  ${total.toFixed(2)}`,
        '',
        '--------------------------------',
        '',
        `NETTO:                 ${total.toFixed(2)}`,
        'MwSt 0%:                    0.00',
        '',
        `SUMME EUR:             ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'EC-KARTE',
        `BETRAG EUR:            ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'Vielen Dank!',
        'Auf Wiedersehen',
      ];
    }
  },
  elvetia: {
    country: 'elvetia',
    name: 'Elveția',
    flag: '🇨🇭',
    currency: 'CHF',
    headerFormat: (settings) => {
      // Generate realistic Swiss phone number
      const phoneNumber = settings.elvetia_phone || (() => {
        const areaCode = ['044', '031', '021', '061', '022'][Math.floor(Math.random() * 5)];
        const first = Math.floor(Math.random() * 900) + 100;
        const second = Math.floor(Math.random() * 9000) + 1000;
        return `+41 ${areaCode} ${first} ${second}`;
      })();
      
      const headerLines = [
        settings.elvetia_store_name || 'BILDUNGSGESCHAEFT',
        settings.elvetia_address || 'BILDUNGSSTRASSE 1',
        settings.elvetia_city || '8000 ZUERICH',
        `UID: ${settings.elvetia_uid || 'CHE-123.456.789'}`,
        `Tel: ${phoneNumber}`,
      ];
      
      if (settings.elvetia_email) {
        headerLines.push(`Email: ${settings.elvetia_email}`);
      }
      
      if (settings.elvetia_website) {
        headerLines.push(`Web: ${settings.elvetia_website}`);
      }
      
      headerLines.push('');
      headerLines.push('================================');
      headerLines.push('        QUITTUNG');
      headerLines.push('================================');
      // Add 6-digit random number for receipt header
      const randomNumber = Math.floor(Math.random() * 900000) + 100000; // Generates 6-digit number (100000-999999)
      headerLines.push(randomNumber.toString());
      headerLines.push('================================');
      // Only add header text if it exists in settings and is not just numbers
      if (settings.header_text && !/^\d+$/.test(settings.header_text.trim())) {
        headerLines.push(settings.header_text);
        headerLines.push('================================');
      }
      
      return headerLines;
    },
    detailsFormat: (data) => {
      const total = parseFloat(data.amount);
      const date = new Date();
      const dateStr = date.toLocaleDateString('de-CH', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric' 
      });
      const timeStr = date.toLocaleTimeString('de-CH', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false
      });
      
      const userLang = (data.settings as any)?.user_language || 'de';
      const donationText = (data.settings as any)?.[`donation_text_${userLang}`] || 
                          (data.settings as any)?.donation_text_de || 'Spende';
      
      return [
        '',
        `QUITTUNG NR: ${data.receiptNumber}`,
        `${dateStr} ${timeStr}`,
        '',
        '================================',
        '',
        'BEZEICHNUNG          ANZ  BETRAG',
        '',
        donationText,
        `                       1  ${total.toFixed(2)}`,
        '',
        '--------------------------------',
        '',
        `NETTO CHF:             ${total.toFixed(2)}`,
        'MwSt 0%:                    0.00',
        '',
        `TOTAL CHF:             ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'KARTE',
        `BETRAG CHF:            ${total.toFixed(2)}`,
        '',
        '================================',
        '',
        'Vielen Dank!',
        'Auf Wiedersehen',
      ];
    }
  }
};

export const getReceiptTemplate = (country: string): ReceiptTemplate => {
  return receiptTemplates[country] || receiptTemplates.romania;
};
