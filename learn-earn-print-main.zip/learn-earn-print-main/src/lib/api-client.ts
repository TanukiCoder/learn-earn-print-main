import axios from 'axios';

// Use relative path in production, localhost in development
const API_URL = import.meta.env.VITE_API_URL || (import.meta.env.MODE === 'production' ? '/api' : 'http://localhost:3001/api');

// Create axios instance
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const api = {
  // Auth
  auth: {
    login: (email: string, password: string) =>
      apiClient.post('/auth/login', { email, password }),
    register: (email: string, password: string, full_name: string) =>
      apiClient.post('/auth/register', { email, password, full_name }),
    logout: () => apiClient.post('/auth/logout'),
    getCurrentUser: () => apiClient.get('/auth/me'),
  },

  // Videos
  videos: {
    getAll: () => apiClient.get('/videos'),
    getAllAdmin: () => apiClient.get('/videos/admin'),
    getById: (id: string) => apiClient.get(`/videos/${id}`),
    create: (formData: FormData) =>
      apiClient.post('/videos', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      }),
    update: (id: string, formData: FormData) =>
      apiClient.put(`/videos/${id}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      }),
    delete: (id: string) => apiClient.delete(`/videos/${id}`),
  },

  // Users
  users: {
    getAll: () => apiClient.get('/users'),
    getById: (id: string) => apiClient.get(`/users/${id}`),
    create: (data: any) => apiClient.post('/users', data),
    update: (id: string, data: any) => apiClient.put(`/users/${id}`, data),
    delete: (id: string) => apiClient.delete(`/users/${id}`),
  },

  // Quizzes
  quizzes: {
    getByVideoId: (videoId: string) => apiClient.get(`/quizzes/video/${videoId}`),
    getById: (id: string) => apiClient.get(`/quizzes/${id}`),
    create: (data: any) => apiClient.post('/quizzes', data),
    submit: (id: string, data: any) => apiClient.post(`/quizzes/${id}/submit`, data),
    delete: (id: string) => apiClient.delete(`/quizzes/${id}`),
  },

  // Receipts
  receipts: {
    getAll: () => apiClient.get('/receipts'),
    getAllAdmin: () => apiClient.get('/receipts/admin'),
    getSettings: () => apiClient.get('/receipts/settings'),
    updateSettings: (data: any) => apiClient.put('/receipts/settings', data),
    create: (data: any) => apiClient.post('/receipts', data),
    getNextNumber: () => apiClient.get('/receipts/next-number'),
  },

  // Video Progress
  videoProgress: {
    get: (userId: string, videoId: string) =>
      apiClient.get(`/video-progress/${userId}/${videoId}`),
    upsert: (data: any) => apiClient.post('/video-progress', data),
  },

  // Sessions
  sessions: {
    getAll: () => apiClient.get('/sessions'),
    kick: (id: string, reason?: string) => 
      apiClient.post(`/sessions/${id}/kick`, { reason }),
    getStats: () => apiClient.get('/sessions/stats'),
    cleanup: (days?: number) => apiClient.delete('/sessions/cleanup', { data: { days } }),
  },

  // Notifications
  notifications: {
    getAll: () => apiClient.get('/notifications'),
    getUnreadCount: () => apiClient.get('/notifications/unread-count'),
    markAsRead: (id: string) => apiClient.put(`/notifications/${id}/read`),
    markAllAsRead: () => apiClient.put('/notifications/mark-all-read'),
    delete: (id: string) => apiClient.delete(`/notifications/${id}`),
  },

  // App Settings
  appSettings: {
    getAll: () => apiClient.get('/app-settings'),
    getByKey: (key: string) => apiClient.get(`/app-settings/${key}`),
    update: (key: string, value: string) => apiClient.put(`/app-settings/${key}`, { setting_value: value }),
    create: (key: string, value: string, description?: string) => 
      apiClient.post('/app-settings', { setting_key: key, setting_value: value, description }),
  },
};

export default api;
