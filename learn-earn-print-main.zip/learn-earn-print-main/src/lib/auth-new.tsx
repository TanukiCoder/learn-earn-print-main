import { createContext, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import api from "./api-client";

interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'admin' | 'user';
  is_active: boolean;
  subscription_start?: string;
  subscription_end?: string;
  created_at: string;
  updated_at: string;
}

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, fullName: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    // Check for existing session
    const checkSession = async () => {
      const token = localStorage.getItem('auth_token');
      if (token) {
        try {
          const response = await api.auth.getCurrentUser();
          const user = response.data.user;
          setUser(user);
          
          // If user is deactivated, redirect to deactivated page
          if (!user.is_active && window.location.pathname !== '/account-deactivated') {
            navigate('/account-deactivated');
          }
        } catch (error) {
          localStorage.removeItem('auth_token');
          localStorage.removeItem('user');
        }
      }
      setIsLoading(false);
    };

    checkSession();
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      const response = await api.auth.login(email, password);
      const { user, token } = response.data;

      localStorage.setItem('auth_token', token);
      localStorage.setItem('user', JSON.stringify(user));
      setUser(user);

      // Check if user account is deactivated
      if (!user.is_active) {
        toast.error('Contul dumneavoastră a fost dezactivat. Contactați administratorul pentru reactivare.');
        navigate('/account-deactivated');
        return;
      }

      toast.success('Autentificare reușită!');
      navigate(user.role === 'admin' ? '/admin' : '/dashboard');
    } catch (error: any) {
      const message = error.response?.data?.error || 'Eroare la autentificare';
      toast.error(message);
      throw error;
    }
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const response = await api.auth.register(email, password, fullName);
      toast.success('Cont creat cu succes! Vă rugăm să vă autentificați.');
      navigate('/login');
    } catch (error: any) {
      const message = error.response?.data?.error || 'Eroare la înregistrare';
      toast.error(message);
      throw error;
    }
  };

  const signOut = async () => {
    try {
      await api.auth.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user');
      setUser(null);
      navigate('/login');
      toast.success('Deconectare reușită!');
    }
  };

  return (
    <AuthContext.Provider value={{ user, isAdmin, isLoading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
