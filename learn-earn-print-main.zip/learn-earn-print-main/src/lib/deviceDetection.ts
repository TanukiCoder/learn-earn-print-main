export const isMobileOrTablet = (): boolean => {
  const userAgent = navigator.userAgent.toLowerCase();
  const mobileKeywords = ['android', 'webos', 'iphone', 'ipad', 'ipod', 'blackberry', 'windows phone'];
  
  // Check user agent
  const isMobileUA = mobileKeywords.some(keyword => userAgent.includes(keyword));
  
  // Check screen size as additional verification
  const isMobileScreen = window.innerWidth <= 1024;
  
  // Check touch capability
  const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  
  return isMobileUA || (isMobileScreen && hasTouch);
};

export const getDeviceType = (): 'mobile' | 'tablet' | 'desktop' => {
  const userAgent = navigator.userAgent.toLowerCase();
  const width = window.innerWidth;
  const height = window.innerHeight;
  
  // More accurate tablet detection
  if (userAgent.includes('ipad')) {
    return 'tablet';
  }
  
  // Android tablets - check for tablet indicators
  if (userAgent.includes('android')) {
    // Check screen size and density
    if (width >= 768 || (width >= 600 && window.devicePixelRatio >= 1.5)) {
      return 'tablet';
    }
  }
  
  // Check for tablet-like screen dimensions
  if (width >= 768 && width <= 1024 && height >= 600) {
    // If it's a touch device with these dimensions, likely a tablet
    if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
      return 'tablet';
    }
  }
  
  if (isMobileOrTablet()) {
    return 'mobile';
  }
  
  return 'desktop';
};

export const getDeviceDetails = () => {
  const userAgent = navigator.userAgent;
  const deviceType = getDeviceType();
  
  // Detect if it's an unusual device
  const isUnusual = 
    !userAgent.includes('chrome') && 
    !userAgent.includes('firefox') && 
    !userAgent.includes('safari') && 
    !userAgent.includes('edge') ||
    userAgent.includes('bot') ||
    userAgent.includes('crawler') ||
    userAgent.includes('spider');
  
  return {
    deviceType,
    isUnusual,
    userAgent,
    platform: navigator.platform,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    innerWidth: window.innerWidth,
    innerHeight: window.innerHeight,
    devicePixelRatio: window.devicePixelRatio,
    language: navigator.language,
    languages: navigator.languages,
    cookieEnabled: navigator.cookieEnabled,
    onLine: navigator.onLine,
  };
};

export const getDeviceInfo = () => {
  return {
    deviceType: getDeviceType(),
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
  };
};
