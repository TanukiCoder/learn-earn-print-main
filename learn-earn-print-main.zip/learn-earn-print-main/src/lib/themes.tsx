import { createContext, useContext, useEffect, useState } from "react";

export interface Theme {
  id: string;
  name: string;
  description: string;
  colors: {
    primary: string;
    primaryForeground: string;
    secondary: string;
    accent: string;
    background: string;
    foreground: string;
    card: string;
    cardForeground: string;
    muted: string;
    mutedForeground: string;
    border: string;
  };
}

export const themes: Record<string, Theme> = {
  ngo: {
    id: 'ngo',
    name: 'ONG / Non-Profit',
    description: 'Temă caldă și prietenoasă pentru organizații nonprofit',
    colors: {
      primary: '142 90% 40%',
      primaryForeground: '0 0% 100%',
      secondary: '142 30% 88%',
      accent: '48 96% 53%',
      background: '0 0% 100%',
      foreground: '142 10% 10%',
      card: '0 0% 100%',
      cardForeground: '142 10% 10%',
      muted: '142 30% 95%',
      mutedForeground: '142 10% 40%',
      border: '142 30% 88%',
    }
  },
  government: {
    id: 'government',
    name: 'Instituție Publică',
    description: 'Temă profesională pentru instituții guvernamentale',
    colors: {
      primary: '221 83% 35%',
      primaryForeground: '0 0% 100%',
      secondary: '214 32% 91%',
      accent: '24 100% 50%',
      background: '0 0% 100%',
      foreground: '221 39% 11%',
      card: '0 0% 100%',
      cardForeground: '221 39% 11%',
      muted: '214 32% 91%',
      mutedForeground: '221 39% 40%',
      border: '214 32% 88%',
    }
  },
  education: {
    id: 'education',
    name: 'Educație & Formare',
    description: 'Temă vibrantă pentru platforme educaționale',
    colors: {
      primary: '262 80% 50%',
      primaryForeground: '0 0% 100%',
      secondary: '270 30% 92%',
      accent: '335 78% 50%',
      background: '0 0% 100%',
      foreground: '262 10% 10%',
      card: '0 0% 100%',
      cardForeground: '262 10% 10%',
      muted: '270 30% 95%',
      mutedForeground: '262 10% 40%',
      border: '270 30% 88%',
    }
  },
};

interface ThemeContextType {
  currentTheme: Theme;
  setTheme: (themeId: string) => void;
  availableThemes: Theme[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [currentThemeId, setCurrentThemeId] = useState<string>(() => {
    return localStorage.getItem('app-theme') || 'ngo';
  });

  const currentTheme = themes[currentThemeId] || themes.ngo;

  useEffect(() => {
    const root = document.documentElement;
    Object.entries(currentTheme.colors).forEach(([key, value]) => {
      const cssVar = `--${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
      root.style.setProperty(cssVar, value);
    });
    localStorage.setItem('app-theme', currentThemeId);
  }, [currentTheme, currentThemeId]);

  const setTheme = (themeId: string) => {
    if (themes[themeId]) {
      setCurrentThemeId(themeId);
    }
  };

  return (
    <ThemeContext.Provider value={{ 
      currentTheme, 
      setTheme, 
      availableThemes: Object.values(themes) 
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}
