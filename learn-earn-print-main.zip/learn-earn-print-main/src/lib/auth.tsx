import { createContext, useContext, useEffect, useState } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  isAdmin: boolean;
  isLoading: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;

    // Listen for session kicks via realtime (only if user is set)
    if (user?.id) {
      channel = supabase
        .channel('session-management')
        .on('postgres_changes', 
          { 
            event: 'UPDATE', 
            schema: 'public', 
            table: 'user_sessions',
            filter: `user_id=eq.${user.id}`
          }, 
          (payload: any) => {
            if (payload.new.is_active === false && payload.new.logout_reason === 'kicked_by_new_session') {
              toast.error("Sesiune închisă: conectat de pe alt dispozitiv.");
              supabase.auth.signOut();
              navigate('/login');
            }
          }
        )
        .subscribe();
    }

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          setTimeout(async () => {
            const { data: profile } = await supabase
              .from('profiles')
              .select('role, is_active, subscription_end')
              .eq('id', session.user.id)
              .maybeSingle();
            
            if (profile) {
              setIsAdmin(profile.role === 'admin');
              
              // Check if subscription expired for non-admins
              if (profile.role !== 'admin' && !profile.is_active) {
                await supabase.auth.signOut();
                navigate('/login');
              }
              
              if (profile.role !== 'admin' && profile.subscription_end) {
                const subEnd = new Date(profile.subscription_end);
                if (subEnd < new Date()) {
                  await supabase.auth.signOut();
                  navigate('/login');
                }
              }
            }
          }, 0);
        } else {
          setIsAdmin(false);
        }
        
        setIsLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        setTimeout(async () => {
          const { data: profile } = await supabase
            .from('profiles')
            .select('role, is_active, subscription_end')
            .eq('id', session.user.id)
            .maybeSingle();
          
          if (profile) {
            setIsAdmin(profile.role === 'admin');
            
            if (profile.role !== 'admin' && !profile.is_active) {
              await supabase.auth.signOut();
              navigate('/login');
            }
            
            if (profile.role !== 'admin' && profile.subscription_end) {
              const subEnd = new Date(profile.subscription_end);
              if (subEnd < new Date()) {
                await supabase.auth.signOut();
                navigate('/login');
              }
            }
          }
          setIsLoading(false);
        }, 0);
      } else {
        setIsLoading(false);
      }
    });

    return () => {
      subscription.unsubscribe();
      if (channel) {
        channel.unsubscribe();
      }
    };
  }, [navigate, user?.id]);

  const signOut = async () => {
    // Mark session as manually logged out
    if (user?.id) {
      await supabase
        .from('user_sessions')
        .update({ is_active: false, logout_reason: 'manual' })
        .eq('user_id', user.id)
        .eq('is_active', true);
    }
    
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <AuthContext.Provider value={{ user, session, isAdmin, isLoading, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
