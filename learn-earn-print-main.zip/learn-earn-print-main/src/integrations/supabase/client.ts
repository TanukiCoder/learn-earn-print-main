// DEPRECATED: This file is kept for backward compatibility only
// Please use the new API client: import api from "@/lib/api-client"

// Temporary mock to prevent import errors during migration
export const supabase = {
  auth: {
    signInWithPassword: () => Promise.reject(new Error('Please use api.auth.login instead')),
    signUp: () => Promise.reject(new Error('Please use api.auth.register instead')),
    signOut: () => Promise.reject(new Error('Please use api.auth.logout instead')),
    getSession: () => Promise.resolve({ data: { session: null }, error: null }),
    onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
  },
  from: () => ({
    select: () => Promise.reject(new Error('Please use the new API client')),
    insert: () => Promise.reject(new Error('Please use the new API client')),
    update: () => Promise.reject(new Error('Please use the new API client')),
    delete: () => Promise.reject(new Error('Please use the new API client')),
  }),
  storage: {
    from: () => ({
      upload: () => Promise.reject(new Error('Please use the new API client')),
      getPublicUrl: () => ({ data: { publicUrl: '' } }),
    }),
  },
  channel: () => ({
    on: () => ({ subscribe: () => {} }),
    subscribe: () => {},
    unsubscribe: () => {},
  }),
};