import { supabase } from "@/integrations/supabase/client";

export async function resetAdminPassword() {
  try {
    const { data, error } = await supabase.functions.invoke('reset-password-now', {
      body: {}
    });

    if (error) {
      console.error('Error calling reset function:', error);
      return { success: false, error };
    }

    console.log('Reset response:', data);
    return { success: true, data };
  } catch (err) {
    console.error('Exception calling reset function:', err);
    return { success: false, error: err };
  }
}
