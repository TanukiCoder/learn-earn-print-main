const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

try {
  console.log('🚀 Applying notifications migration...');
  
  const db = new Database('./data/database.sqlite');
  const sql = fs.readFileSync('./server/migrations/007_create_notifications.sql', 'utf-8');
  
  // Execute the entire SQL at once
  console.log('Executing migration SQL...');
  db.exec(sql);
  
  console.log('✅ Migration applied successfully!');
  
  // Verify
  const tableInfo = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='notifications'").get();
  
  if (tableInfo) {
    console.log('✅ Table "notifications" created!');
    const columns = db.prepare('PRAGMA table_info(notifications)').all();
    console.log('\n📋 Table structure:');
    columns.forEach(col => {
      console.log(`  - ${col.name} (${col.type})`);
    });
  }
  
  db.close();
  console.log('\n🎉 Done! You can now restart your server.');
  
} catch (error) {
  console.error('❌ Error:', error.message);
  process.exit(1);
}
