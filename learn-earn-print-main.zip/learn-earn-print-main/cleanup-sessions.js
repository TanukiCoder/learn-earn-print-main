import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, 'data', 'database.sqlite');
const db = new Database(dbPath);

console.log('🧹 Начинаем очистку сессий...\n');

// 1. Показать текущее состояние
const beforeCount = db.prepare('SELECT COUNT(*) as count FROM user_sessions').get();
console.log(`📊 Всего сессий до очистки: ${beforeCount.count}`);

const activeBefore = db.prepare('SELECT COUNT(*) as count FROM user_sessions WHERE is_active = 1').get();
console.log(`✅ Активных сессий: ${activeBefore.count}`);

const inactiveBefore = db.prepare('SELECT COUNT(*) as count FROM user_sessions WHERE is_active = 0').get();
console.log(`❌ Неактивных сессий: ${inactiveBefore.count}\n`);

// 2. Удалить все неактивные сессии
console.log('🗑️  Удаляем неактивные сессии...');
const deleteInactive = db.prepare('DELETE FROM user_sessions WHERE is_active = 0');
const resultInactive = deleteInactive.run();
console.log(`   Удалено: ${resultInactive.changes} сессий\n`);

// 3. Для каждого пользователя оставить только последнюю активную сессию
console.log('🔄 Удаляем дубликаты активных сессий...');

// Получить всех пользователей с активными сессиями
const users = db.prepare(`
  SELECT DISTINCT user_id 
  FROM user_sessions 
  WHERE is_active = 1
`).all();

let duplicatesRemoved = 0;

users.forEach(({ user_id }) => {
  // Получить все активные сессии пользователя, отсортированные по времени
  const sessions = db.prepare(`
    SELECT id, last_active 
    FROM user_sessions 
    WHERE user_id = ? AND is_active = 1
    ORDER BY last_active DESC
  `).all(user_id);

  // Если больше одной сессии, удалить все кроме последней
  if (sessions.length > 1) {
    const sessionsToDelete = sessions.slice(1); // Все кроме первой (самой свежей)
    
    sessionsToDelete.forEach(session => {
      db.prepare('DELETE FROM user_sessions WHERE id = ?').run(session.id);
      duplicatesRemoved++;
    });
  }
});

console.log(`   Удалено дубликатов: ${duplicatesRemoved}\n`);

// 4. Показать результат
const afterCount = db.prepare('SELECT COUNT(*) as count FROM user_sessions').get();
console.log(`📊 Всего сессий после очистки: ${afterCount.count}`);

const activeAfter = db.prepare('SELECT COUNT(*) as count FROM user_sessions WHERE is_active = 1').get();
console.log(`✅ Активных сессий: ${activeAfter.count}\n`);

// 5. Показать оставшиеся сессии
console.log('📋 Оставшиеся активные сессии:');
const remainingSessions = db.prepare(`
  SELECT 
    u.email,
    s.device_type,
    s.ip_address,
    s.login_at,
    s.last_active
  FROM user_sessions s
  LEFT JOIN users u ON s.user_id = u.id
  WHERE s.is_active = 1
  ORDER BY s.last_active DESC
`).all();

remainingSessions.forEach(session => {
  console.log(`   - ${session.email} | ${session.device_type} | ${session.ip_address} | ${new Date(session.last_active).toLocaleString()}`);
});

console.log('\n✅ Очистка завершена!');

db.close();
