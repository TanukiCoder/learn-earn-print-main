import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const db = new Database(join(__dirname, 'data', 'database.sqlite'));

console.log('🔧 Creating app_settings table...');

try {
  // Create app_settings table
  db.exec(`
    CREATE TABLE IF NOT EXISTS app_settings (
      id TEXT PRIMARY KEY,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT NOT NULL,
      description TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  console.log('✅ Table created successfully!');

  // Insert default settings
  const insertSetting = db.prepare(`
    INSERT OR IGNORE INTO app_settings (id, setting_key, setting_value, description)
    VALUES (?, ?, ?, ?)
  `);

  const settings = [
    {
      id: 'users-can-create-quizzes',
      key: 'users_can_create_quizzes',
      value: 'true',
      description: 'Allow users to create quizzes'
    }
  ];

  let added = 0;
  for (const setting of settings) {
    const result = insertSetting.run(
      setting.id,
      setting.key,
      setting.value,
      setting.description
    );
    if (result.changes > 0) {
      console.log(`✅ Added setting: ${setting.key}`);
      added++;
    }
  }

  console.log(`\n📊 Summary:`);
  console.log(`   Added: ${added} settings`);
  console.log(`\n✅ Migration complete!`);

} catch (error) {
  console.error('❌ Error:', error);
  process.exit(1);
} finally {
  db.close();
}
