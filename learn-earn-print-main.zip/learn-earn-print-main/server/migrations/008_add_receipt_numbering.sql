-- Add receipt numbering fields to receipt_settings table
ALTER TABLE receipt_settings ADD COLUMN receipt_number_start INTEGER DEFAULT 0;
ALTER TABLE receipt_settings ADD COLUMN receipt_number_current INTEGER DEFAULT 0;
ALTER TABLE receipt_settings ADD COLUMN receipt_number_reset INTEGER DEFAULT 9999;

-- Update existing records to have default values
UPDATE receipt_settings 
SET 
  receipt_number_start = 0,
  receipt_number_current = 0,
  receipt_number_reset = 9999
WHERE receipt_number_start IS NULL;
