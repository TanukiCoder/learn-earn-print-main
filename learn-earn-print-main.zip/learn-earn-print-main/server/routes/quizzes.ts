import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/database.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';

const router = express.Router();

// Get all quizzes for a video
router.get('/video/:videoId', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const quizzes = db.prepare(`
      SELECT q.*, 
        (SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = q.id) as question_count
      FROM quizzes q
      WHERE q.video_id = ?
      ORDER BY q.created_at DESC
    `).all(req.params.videoId);

    // Get submissions for current user for each quiz
    const quizzesWithSubmissions = quizzes.map((quiz: any) => {
      const submissions = db.prepare(`
        SELECT id, submitted_at 
        FROM quiz_submissions 
        WHERE quiz_id = ? AND user_id = ?
        ORDER BY submitted_at DESC
      `).all(quiz.id, req.userId);

      return {
        ...quiz,
        submissions
      };
    });

    res.json(quizzesWithSubmissions);
  } catch (error) {
    console.error('Get quizzes error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get quiz with questions
router.get('/:id', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const quiz = db.prepare('SELECT * FROM quizzes WHERE id = ?').get(req.params.id);

    if (!quiz) {
      return res.status(404).json({ error: 'Quiz not found' });
    }

    const questions = db.prepare(`
      SELECT * FROM quiz_questions 
      WHERE quiz_id = ? 
      ORDER BY order_index ASC
    `).all(req.params.id);

    // Parse JSON options for each question
    const parsedQuestions = questions.map((q: any) => ({
      ...q,
      options: q.options ? JSON.parse(q.options) : null
    }));

    res.json({ ...quiz, questions: parsedQuestions });
  } catch (error) {
    console.error('Get quiz error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create quiz
router.post('/', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const { video_id, title, questions } = req.body;

    const quizId = uuidv4();
    db.prepare(`
      INSERT INTO quizzes (id, video_id, title, created_by)
      VALUES (?, ?, ?, ?)
    `).run(quizId, video_id, title, req.userId);

    // Insert questions
    if (questions && Array.isArray(questions)) {
      const insertQuestion = db.prepare(`
        INSERT INTO quiz_questions (id, quiz_id, question_text, question_type, options, order_index)
        VALUES (?, ?, ?, ?, ?, ?)
      `);

      questions.forEach((q: any, index: number) => {
        insertQuestion.run(
          uuidv4(),
          quizId,
          q.question_text,
          q.question_type,
          q.options ? JSON.stringify(q.options) : null,
          index
        );
      });
    }

    const quiz = db.prepare('SELECT * FROM quizzes WHERE id = ?').get(quizId);
    const quizQuestions = db.prepare('SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY order_index').all(quizId);

    res.status(201).json({ ...quiz, questions: quizQuestions });
  } catch (error) {
    console.error('Create quiz error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Submit quiz
router.post('/:id/submit', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const { answers, video_id } = req.body;

    const submissionId = uuidv4();
    db.prepare(`
      INSERT OR REPLACE INTO quiz_submissions (id, user_id, quiz_id, video_id, answers)
      VALUES (?, ?, ?, ?, ?)
    `).run(submissionId, req.userId, req.params.id, video_id, JSON.stringify(answers));

    const submission = db.prepare('SELECT * FROM quiz_submissions WHERE id = ?').get(submissionId);

    res.status(201).json(submission);
  } catch (error) {
    console.error('Submit quiz error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete quiz
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const result = db.prepare('DELETE FROM quizzes WHERE id = ?').run(req.params.id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Quiz not found' });
    }

    res.json({ message: 'Quiz deleted successfully' });
  } catch (error) {
    console.error('Delete quiz error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
