import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/database.js';
import { authenticateToken, AuthRequest } from '../middleware/auth.js';

const router = express.Router();

// Get video progress for a user
router.get('/:userId/:videoId', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const progress = db.prepare(`
      SELECT * FROM video_progress 
      WHERE user_id = ? AND video_id = ?
    `).get(req.params.userId, req.params.videoId);

    if (!progress) {
      return res.status(404).json({ error: 'Progress not found' });
    }

    res.json(progress);
  } catch (error) {
    console.error('Get video progress error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Upsert video progress
router.post('/', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const { user_id, video_id, progress_percentage, completed, last_watched_at } = req.body;

    console.log('=== Video Progress Upsert ===');
    console.log('Body:', { user_id, video_id, progress_percentage, completed, last_watched_at });

    if (!user_id || !video_id) {
      return res.status(400).json({ error: 'user_id and video_id are required' });
    }

    // Check if progress exists
    const existing = db.prepare(`
      SELECT id FROM video_progress 
      WHERE user_id = ? AND video_id = ?
    `).get(user_id, video_id);

    if (existing) {
      // Update existing progress
      db.prepare(`
        UPDATE video_progress 
        SET progress_percentage = ?, completed = ?, last_watched_at = ?
        WHERE user_id = ? AND video_id = ?
      `).run(progress_percentage, completed ? 1 : 0, last_watched_at || new Date().toISOString(), user_id, video_id);
    } else {
      // Insert new progress
      const progressId = uuidv4();
      db.prepare(`
        INSERT INTO video_progress (id, user_id, video_id, progress_percentage, completed, last_watched_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(progressId, user_id, video_id, progress_percentage, completed ? 1 : 0, last_watched_at || new Date().toISOString());
    }

    const progress = db.prepare(`
      SELECT * FROM video_progress 
      WHERE user_id = ? AND video_id = ?
    `).get(user_id, video_id);

    res.json(progress);
  } catch (error: any) {
    console.error('Upsert video progress error:', error);
    console.error('Error message:', error.message);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

export default router;
