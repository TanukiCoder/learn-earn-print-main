import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import crypto from 'crypto';
import { db } from '../db/database.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';

const router = express.Router();

// Generate receipt number
function generateReceiptNumber(): string {
  const year = new Date().getFullYear();
  const count = db.prepare(`
    SELECT COUNT(*) as count FROM receipts 
    WHERE strftime('%Y', generated_at) = ?
  `).get(year.toString()) as any;
  
  const counter = (count?.count || 0) + 1;
  return `BON-${year}-${counter.toString().padStart(6, '0')}`;
}

// Get all receipts for current user
router.get('/', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const receipts = db.prepare(`
      SELECT r.*, v.title as video_title
      FROM receipts r
      LEFT JOIN videos v ON r.video_id = v.id
      WHERE r.user_id = ?
      ORDER BY r.generated_at DESC
    `).all(req.userId);

    res.json(receipts);
  } catch (error) {
    console.error('Get receipts error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all receipts (admin)
router.get('/admin', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const receipts = db.prepare(`
      SELECT r.*, v.title as video_title, u.full_name, u.email
      FROM receipts r
      LEFT JOIN videos v ON r.video_id = v.id
      LEFT JOIN users u ON r.user_id = u.id
      ORDER BY r.generated_at DESC
    `).all();

    res.json(receipts);
  } catch (error) {
    console.error('Get receipts error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get receipt settings
router.get('/settings', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    // Try to get user-specific settings first
    let settings = db.prepare('SELECT * FROM receipt_settings WHERE user_id = ?').get(req.userId);

    // If no user settings, get global settings (user_id is null)
    if (!settings) {
      settings = db.prepare('SELECT * FROM receipt_settings WHERE user_id IS NULL LIMIT 1').get();
    }

    // If still no settings, return empty object with defaults
    if (!settings) {
      return res.json({});
    }

    res.json(settings);
  } catch (error) {
    console.error('Get receipt settings error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update receipt settings
router.put('/settings', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    console.log('=== Receipt Settings Update ===');
    console.log('User ID:', req.userId);
    console.log('Request body keys:', Object.keys(req.body));
    console.log('Request body:', JSON.stringify(req.body, null, 2));
    
    // Check if user already has settings
    const existingSettings = db.prepare('SELECT id FROM receipt_settings WHERE user_id = ?').get(req.userId) as any;
    console.log('Existing settings:', existingSettings);

    // Allowed fields to update
    const allowedFields = [
      'header_text', 'quiz_title', 'donation_text_ro', 'donation_text_en', 'donation_text_fr', 
      'donation_text_it', 'donation_text_es', 'donation_text_de',
      'romania_store_name', 'romania_address', 'romania_city', 'romania_email', 
      'romania_website', 'romania_cui', 'romania_phone',
      'spain_store_name', 'spain_address_line1', 'spain_address_line2', 'spain_phone',
      'italy_store_name', 'italy_company_info', 'italy_address', 'italy_city', 
      'italy_vat_number', 'italy_phone',
      'france_store_name', 'france_address_line1', 'france_address_line2', 'france_phone',
      'austria_store_name', 'austria_business_name', 'austria_address', 'austria_city',
      'germany_slogan', 'germany_company_name', 'germany_company_legal', 
      'germany_address', 'germany_city', 'germany_phone'
    ];

    const fields = Object.keys(req.body).filter(key => allowedFields.includes(key));
    console.log('Filtered fields:', fields);
    
    if (fields.length === 0) {
      console.log('No valid fields to update');
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    if (existingSettings) {
      // Update existing settings
      const values = fields.map(key => req.body[key]);
      const setClause = fields.map(key => `${key} = ?`).join(', ');
      
      console.log('Updating existing settings...');
      console.log('SQL:', `UPDATE receipt_settings SET ${setClause}, updated_at = datetime('now') WHERE id = ${existingSettings.id}`);
      console.log('Values:', values);
      
      db.prepare(`
        UPDATE receipt_settings 
        SET ${setClause}, updated_at = datetime('now')
        WHERE id = ?
      `).run(...values, existingSettings.id);

      const updatedSettings = db.prepare('SELECT * FROM receipt_settings WHERE id = ?').get(existingSettings.id);
      return res.json(updatedSettings);
    } else {
      // Create new settings for this user
      const settingsId = uuidv4();
      const columns = ['id', 'user_id', ...fields];
      const placeholders = columns.map(() => '?').join(', ');
      const values = [settingsId, req.userId, ...fields.map(key => req.body[key])];

      db.prepare(`
        INSERT INTO receipt_settings (${columns.join(', ')})
        VALUES (${placeholders})
      `).run(...values);

      const newSettings = db.prepare('SELECT * FROM receipt_settings WHERE id = ?').get(settingsId);
      return res.json(newSettings);
    }
  } catch (error: any) {
    console.error('Update receipt settings error:', error);
    console.error('Error details:', error.message);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

// Create receipt
router.post('/', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const { video_id, quiz_submission_id, amount, template_country } = req.body;

    const user = db.prepare('SELECT full_name FROM users WHERE id = ?').get(req.userId) as any;

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const receiptId = uuidv4();
    const receiptNumber = generateReceiptNumber();

    db.prepare(`
      INSERT INTO receipts (id, user_id, video_id, quiz_submission_id, amount, receipt_number, user_name, template_country)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(receiptId, req.userId, video_id, quiz_submission_id || null, amount, receiptNumber, user.full_name, template_country || null);

    const receipt = db.prepare('SELECT * FROM receipts WHERE id = ?').get(receiptId);

    res.status(201).json(receipt);
  } catch (error) {
    console.error('Create receipt error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get next receipt number
router.get('/next-number', authenticateToken, (req: AuthRequest, res) => {
  try {
    const userId = req.userId;
    
    // Get current receipt settings
    let settings = db.prepare('SELECT * FROM receipt_settings WHERE user_id = ?').get(userId) as any;
    
    if (!settings) {
      // Create default settings if they don't exist
      const settingsId = crypto.randomUUID();
      db.prepare(`
        INSERT INTO receipt_settings (id, user_id, receipt_number_start, receipt_number_current, receipt_number_reset)
        VALUES (?, ?, ?, ?, ?)
      `).run(settingsId, userId, 0, 0, 9999);
      
      settings = { receipt_number_start: 0, receipt_number_current: 0, receipt_number_reset: 9999 };
    }
    
    // Use fixed values for automatic numbering
    const startNumber = 0;
    const resetNumber = 9999;
    
    let nextNumber = settings.receipt_number_current;
    
    // Check if we need to reset
    if (nextNumber > resetNumber) {
      nextNumber = startNumber;
    }
    
    // Update current number for next time
    const newCurrent = nextNumber + 1;
    if (newCurrent > resetNumber) {
      // Reset to start number
      db.prepare('UPDATE receipt_settings SET receipt_number_current = ? WHERE user_id = ?')
        .run(startNumber, userId);
    } else {
      db.prepare('UPDATE receipt_settings SET receipt_number_current = ? WHERE user_id = ?')
        .run(newCurrent, userId);
    }
    
    // Format number with leading zeros (4 digits)
    const formattedNumber = String(nextNumber).padStart(4, '0');
    const year = new Date().getFullYear();
    const receiptNumber = `BON-${year}-${formattedNumber}`;
    
    res.json({ receiptNumber, nextNumber: formattedNumber });
  } catch (error) {
    console.error('Get next receipt number error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
