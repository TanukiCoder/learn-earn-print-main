import { Router } from 'express';
import { db } from '../db/database.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';

const router = Router();

// Get all notifications (admin only)
router.get('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const notifications = db.prepare(
      `SELECT * FROM notifications 
       ORDER BY created_at DESC 
       LIMIT 100`
    ).all();
    
    res.json(notifications);
  } catch (error) {
    console.error('Error fetching notifications:', error);
    res.status(500).json({ error: 'Failed to fetch notifications' });
  }
});

// Get unread count (admin only)
router.get('/unread-count', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const result = db.prepare(
      'SELECT COUNT(*) as count FROM notifications WHERE is_read = 0'
    ).get() as { count: number };
    
    res.json({ count: result.count });
  } catch (error) {
    console.error('Error fetching unread count:', error);
    res.status(500).json({ error: 'Failed to fetch unread count' });
  }
});

// Mark notification as read (admin only)
router.put('/:id/read', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    
    db.prepare(
      'UPDATE notifications SET is_read = 1 WHERE id = ?'
    ).run(id);
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    res.status(500).json({ error: 'Failed to mark notification as read' });
  }
});

// Mark all notifications as read (admin only)
router.put('/mark-all-read', authenticateToken, requireAdmin, async (req, res) => {
  try {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE is_read = 0').run();
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    res.status(500).json({ error: 'Failed to mark all notifications as read' });
  }
});

// Delete notification (admin only)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    
    db.prepare('DELETE FROM notifications WHERE id = ?').run(id);
    
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting notification:', error);
    res.status(500).json({ error: 'Failed to delete notification' });
  }
});

// Helper function to create notification (can be called from other routes)
export function createNotification(data: {
  type: string;
  title: string;
  message: string;
  user_id?: string;
  user_name?: string;
  user_email?: string;
  old_ip?: string;
  new_ip?: string;
}) {
  try {
    db.prepare(
      `INSERT INTO notifications (type, title, message, user_id, user_name, user_email, old_ip, new_ip)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      data.type,
      data.title,
      data.message,
      data.user_id || null,
      data.user_name || null,
      data.user_email || null,
      data.old_ip || null,
      data.new_ip || null
    );
  } catch (error) {
    console.error('Error creating notification:', error);
  }
}

export default router;
