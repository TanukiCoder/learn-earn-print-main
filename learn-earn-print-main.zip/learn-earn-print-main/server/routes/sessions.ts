import express from 'express';
import { db } from '../db/database.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';

const router = express.Router();

// Get all sessions (admin only)
router.get('/', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    // Clean up old inactive sessions (older than 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    db.prepare(`
      DELETE FROM user_sessions 
      WHERE is_active = 0 AND last_active < ?
    `).run(thirtyDaysAgo.toISOString());

    const sessions = db.prepare(`
      SELECT 
        s.*,
        u.full_name,
        u.email
      FROM user_sessions s
      LEFT JOIN users u ON s.user_id = u.id
      ORDER BY s.last_active DESC
    `).all();

    // Format sessions with user info
    const formattedSessions = sessions.map((session: any) => ({
      id: session.id,
      user_id: session.user_id,
      device_type: session.device_type,
      device_info: session.device_info,
      ip_address: session.ip_address,
      login_at: session.login_at,
      last_active: session.last_active,
      is_active: session.is_active === 1,
      logout_reason: session.logout_reason,
      profiles: {
        full_name: session.full_name,
        email: session.email
      }
    }));

    res.json(formattedSessions);
  } catch (error) {
    console.error('Get sessions error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Kick a session (admin only)
router.put('/:id/kick', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    // Update session to inactive
    const result = db.prepare(`
      UPDATE user_sessions 
      SET is_active = 0, logout_reason = ?
      WHERE id = ?
    `).run(reason || 'Kicked by admin', id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Session not found' });
    }

    res.json({ message: 'Session kicked successfully' });
  } catch (error) {
    console.error('Kick session error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get active sessions count
router.get('/stats', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN device_type = 'mobile' THEN 1 ELSE 0 END) as mobile,
        SUM(CASE WHEN device_type = 'tablet' THEN 1 ELSE 0 END) as tablet,
        SUM(CASE WHEN device_type = 'desktop' THEN 1 ELSE 0 END) as desktop
      FROM user_sessions
    `).get();

    res.json(stats);
  } catch (error) {
    console.error('Get session stats error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Clean up old inactive sessions (admin only)
router.delete('/cleanup', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const { days = 7 } = req.body;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    const result = db.prepare(`
      DELETE FROM user_sessions 
      WHERE is_active = 0 AND last_active < ?
    `).run(cutoffDate.toISOString());

    res.json({ 
      message: 'Old sessions cleaned up successfully',
      deleted: result.changes 
    });
  } catch (error) {
    console.error('Cleanup sessions error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
