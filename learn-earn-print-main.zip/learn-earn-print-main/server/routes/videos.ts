import express from 'express';
import multer from 'multer';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/database.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = file.fieldname === 'video' 
      ? path.join(__dirname, '../../uploads/videos')
      : path.join(__dirname, '../../uploads/thumbnails');
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 500 * 1024 * 1024 } // 500MB limit
});

// Get all videos (for users)
router.get('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    const videos = db.prepare(`
      SELECT * FROM videos 
      WHERE is_active = 1 
      ORDER BY order_index ASC
    `).all();

    res.json(videos);
  } catch (error) {
    console.error('Get videos error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all videos (for admin)
router.get('/admin', authenticateToken, requireAdmin, (req: AuthRequest, res) => {
  try {
    const videos = db.prepare('SELECT * FROM videos ORDER BY order_index ASC').all();
    res.json(videos);
  } catch (error) {
    console.error('Get videos error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single video
router.get('/:id', authenticateToken, (req: AuthRequest, res) => {
  try {
    const video = db.prepare('SELECT * FROM videos WHERE id = ?').get(req.params.id);

    if (!video) {
      return res.status(404).json({ error: 'Video not found' });
    }

    res.json(video);
  } catch (error) {
    console.error('Get video error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create video
router.post('/', authenticateToken, requireAdmin, upload.fields([
  { name: 'video', maxCount: 1 },
  { name: 'thumbnail', maxCount: 1 }
]), (req: AuthRequest, res) => {
  try {
    const { title, description, country, order_index, youtube_url } = req.body;
    const files = req.files as { [fieldname: string]: Express.Multer.File[] };

    let videoUrl = youtube_url || '';
    let thumbnailUrl = null;

    // Handle video file upload
    if (files?.video && files.video[0]) {
      videoUrl = `/uploads/videos/${files.video[0].filename}`;
    }

    // Handle thumbnail upload
    if (files?.thumbnail && files.thumbnail[0]) {
      thumbnailUrl = `/uploads/thumbnails/${files.thumbnail[0].filename}`;
    }

    if (!videoUrl) {
      return res.status(400).json({ error: 'Video URL or file is required' });
    }

    const videoId = uuidv4();
    db.prepare(`
      INSERT INTO videos (id, title, description, video_url, thumbnail_url, country, order_index, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    `).run(videoId, title, description || null, videoUrl, thumbnailUrl, country || null, parseInt(order_index) || 0);

    const video = db.prepare('SELECT * FROM videos WHERE id = ?').get(videoId);
    res.status(201).json(video);
  } catch (error) {
    console.error('Create video error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update video
router.put('/:id', authenticateToken, requireAdmin, upload.fields([
  { name: 'video', maxCount: 1 },
  { name: 'thumbnail', maxCount: 1 }
]), (req: AuthRequest, res) => {
  try {
    const { title, description, country, order_index, youtube_url, is_active } = req.body;
    const files = req.files as { [fieldname: string]: Express.Multer.File[] };

    const existingVideo = db.prepare('SELECT * FROM videos WHERE id = ?').get(req.params.id) as any;

    if (!existingVideo) {
      return res.status(404).json({ error: 'Video not found' });
    }

    let videoUrl = existingVideo.video_url;
    let thumbnailUrl = existingVideo.thumbnail_url;

    // Update video URL if provided
    if (youtube_url) {
      videoUrl = youtube_url;
    } else if (files?.video && files.video[0]) {
      videoUrl = `/uploads/videos/${files.video[0].filename}`;
    }

    // Update thumbnail if provided
    if (files?.thumbnail && files.thumbnail[0]) {
      thumbnailUrl = `/uploads/thumbnails/${files.thumbnail[0].filename}`;
    }

    // Parse is_active properly (can come as string "true"/"false" or boolean)
    let isActiveValue = existingVideo.is_active;
    if (is_active !== undefined && is_active !== null) {
      if (typeof is_active === 'string') {
        isActiveValue = is_active === 'true' ? 1 : 0;
      } else {
        isActiveValue = is_active ? 1 : 0;
      }
    }

    db.prepare(`
      UPDATE videos 
      SET title = ?, description = ?, video_url = ?, thumbnail_url = ?, 
          country = ?, order_index = ?, is_active = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(
      title,
      description || null,
      videoUrl,
      thumbnailUrl,
      country || null,
      parseInt(order_index) || 0,
      isActiveValue,
      req.params.id
    );

    const video = db.prepare('SELECT * FROM videos WHERE id = ?').get(req.params.id);
    res.json(video);
  } catch (error) {
    console.error('Update video error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete video
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthRequest, res) => {
  try {
    const result = db.prepare('DELETE FROM videos WHERE id = ?').run(req.params.id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Video not found' });
    }

    res.json({ message: 'Video deleted successfully' });
  } catch (error) {
    console.error('Delete video error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
