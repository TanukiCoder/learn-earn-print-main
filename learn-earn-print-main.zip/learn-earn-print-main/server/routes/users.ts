import express from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/database.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';

const router = express.Router();

// Get all users (admin only)
router.get('/', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const users = db.prepare(`
      SELECT 
        u.id, 
        u.email, 
        u.full_name, 
        u.role, 
        u.is_active, 
        u.subscription_start, 
        u.subscription_end, 
        u.created_at, 
        u.updated_at,
        COALESCE(SUM(r.amount), 0) as total_earnings
      FROM users u
      LEFT JOIN receipts r ON u.id = r.user_id
      GROUP BY u.id
      ORDER BY u.created_at DESC
    `).all();

    res.json(users);
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get user by ID
router.get('/:id', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const user = db.prepare(`
      SELECT id, email, full_name, role, is_active, subscription_start, subscription_end, created_at, updated_at
      FROM users WHERE id = ?
    `).get(req.params.id);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Users can only see their own data, admins can see all
    if (req.userRole !== 'admin' && req.userId !== req.params.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json(user);
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create user (admin only)
router.post('/', authenticateToken, requireAdmin, async (req: AuthRequest, res: any) => {
  try {
    const { email, password, full_name, role, subscription_start, subscription_end } = req.body;

    const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const userId = uuidv4();

    db.prepare(`
      INSERT INTO users (id, email, password_hash, full_name, role, subscription_start, subscription_end)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(userId, email, hashedPassword, full_name, role || 'user', subscription_start || null, subscription_end || null);

    const user = db.prepare(`
      SELECT id, email, full_name, role, is_active, subscription_start, subscription_end, created_at
      FROM users WHERE id = ?
    `).get(userId);

    res.status(201).json(user);
  } catch (error) {
    console.error('Create user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update user
router.put('/:id', authenticateToken, requireAdmin, async (req: AuthRequest, res: any) => {
  try {
    const { full_name, role, is_active, subscription_start, subscription_end, password } = req.body;

    const existingUser = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
    if (!existingUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    let updateQuery = `
      UPDATE users 
      SET full_name = ?, role = ?, is_active = ?, subscription_start = ?, subscription_end = ?, updated_at = datetime('now')
    `;
    let params: any[] = [full_name, role, is_active ? 1 : 0, subscription_start || null, subscription_end || null];

    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      updateQuery += `, password_hash = ?`;
      params.push(hashedPassword);
    }

    updateQuery += ` WHERE id = ?`;
    params.push(req.params.id);

    db.prepare(updateQuery).run(...params);

    const user = db.prepare(`
      SELECT id, email, full_name, role, is_active, subscription_start, subscription_end, updated_at
      FROM users WHERE id = ?
    `).get(req.params.id);

    res.json(user);
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete user
router.delete('/:id', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const result = db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
