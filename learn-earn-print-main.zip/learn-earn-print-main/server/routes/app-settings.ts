import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/database.js';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.js';

const router = express.Router();

// Get all settings (admin only)
router.get('/', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const settings = db.prepare('SELECT * FROM app_settings ORDER BY setting_key ASC').all();
    res.json(settings);
  } catch (error) {
    console.error('Get settings error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get specific setting by key (authenticated users can read)
router.get('/:key', authenticateToken, (req: AuthRequest, res: any) => {
  try {
    const setting = db.prepare('SELECT * FROM app_settings WHERE setting_key = ?').get(req.params.key);
    
    if (!setting) {
      return res.status(404).json({ error: 'Setting not found' });
    }

    res.json(setting);
  } catch (error) {
    console.error('Get setting error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update setting (admin only)
router.put('/:key', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const { setting_value } = req.body;
    const { key } = req.params;

    const existing = db.prepare('SELECT id FROM app_settings WHERE setting_key = ?').get(key);

    if (!existing) {
      return res.status(404).json({ error: 'Setting not found' });
    }

    db.prepare(`
      UPDATE app_settings 
      SET setting_value = ?, updated_at = datetime('now')
      WHERE setting_key = ?
    `).run(setting_value, key);

    const updated = db.prepare('SELECT * FROM app_settings WHERE setting_key = ?').get(key);
    res.json(updated);
  } catch (error) {
    console.error('Update setting error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create setting (admin only)
router.post('/', authenticateToken, requireAdmin, (req: AuthRequest, res: any) => {
  try {
    const { setting_key, setting_value, description } = req.body;

    const existing = db.prepare('SELECT id FROM app_settings WHERE setting_key = ?').get(setting_key);
    if (existing) {
      return res.status(400).json({ error: 'Setting already exists' });
    }

    const settingId = uuidv4();
    db.prepare(`
      INSERT INTO app_settings (id, setting_key, setting_value, description)
      VALUES (?, ?, ?, ?)
    `).run(settingId, setting_key, setting_value, description || null);

    const setting = db.prepare('SELECT * FROM app_settings WHERE id = ?').get(settingId);
    res.status(201).json(setting);
  } catch (error) {
    console.error('Create setting error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
