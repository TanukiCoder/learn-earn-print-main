import express from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/database.js';

const router = express.Router();

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, user.password_hash);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (!user.is_active) {
      return res.status(403).json({ error: 'Account is inactive' });
    }

    // Check subscription for non-admin users
    if (user.role !== 'admin' && user.subscription_end) {
      const subEnd = new Date(user.subscription_end);
      if (subEnd < new Date()) {
        return res.status(403).json({ error: 'Subscription expired' });
      }
    }

    // Deactivate old sessions for this user
    db.prepare(`
      UPDATE user_sessions 
      SET is_active = 0, logout_reason = 'new_login'
      WHERE user_id = ? AND is_active = 1
    `).run(user.id);

    // Create new session
    const sessionId = uuidv4();
    const deviceType = req.headers['user-agent']?.includes('Mobile') ? 'mobile' : 
                       req.headers['user-agent']?.includes('Tablet') ? 'tablet' : 'desktop';
    
    // Get real IP address (considering proxy/nginx)
    const forwardedFor = req.headers['x-forwarded-for'];
    const realIp = (typeof forwardedFor === 'string' ? forwardedFor.split(',')[0] : null) ||
                   req.headers['x-real-ip'] || 
                   req.ip ||
                   'unknown';

    db.prepare(`
      INSERT INTO user_sessions (id, user_id, device_type, device_info, ip_address)
      VALUES (?, ?, ?, ?, ?)
    `).run(sessionId, user.id, deviceType, req.headers['user-agent'], realIp);

    // Return user data (excluding password)
    const { password_hash, ...userData } = user;

    res.json({
      user: userData,
      session: { id: sessionId },
      token: user.id // In production, use JWT
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Register
router.post('/register', async (req, res) => {
  try {
    const { email, password, full_name } = req.body;

    // Check if user exists
    const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);

    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const userId = uuidv4();
    db.prepare(`
      INSERT INTO users (id, email, password_hash, full_name, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(userId, email, hashedPassword, full_name, 'user');

    const user = db.prepare('SELECT id, email, full_name, role, is_active FROM users WHERE id = ?').get(userId);

    res.status(201).json({ user });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (token) {
      db.prepare(`
        UPDATE user_sessions 
        SET is_active = 0, logout_reason = 'manual'
        WHERE user_id = ? AND is_active = 1
      `).run(token);
    }

    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get current user
router.get('/me', (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const user = db.prepare(`
      SELECT id, email, full_name, role, is_active, subscription_start, subscription_end, created_at, updated_at
      FROM users WHERE id = ?
    `).get(token);

    if (!user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
