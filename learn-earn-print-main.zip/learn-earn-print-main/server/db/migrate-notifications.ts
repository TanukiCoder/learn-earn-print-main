import { db } from './database.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runMigration() {
  try {
    console.log('🚀 Running notifications migration...');

    // Read the migration file
    const migrationPath = path.join(__dirname, '../migrations/007_create_notifications.sql');
    const migrationSQL = fs.readFileSync(migrationPath, 'utf-8');

    // Split by semicolon and execute each statement
    const statements = migrationSQL
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0 && !s.startsWith('--'));

    for (const statement of statements) {
      console.log(`Executing: ${statement.substring(0, 50)}...`);
      db.exec(statement);
    }

    console.log('✅ Notifications migration completed successfully!');
    console.log('📊 Verifying table...');

    // Verify the table was created
    const tableInfo = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='notifications'").get();
    
    if (tableInfo) {
      console.log('✅ Table "notifications" created successfully!');
      
      // Show table structure
      const columns = db.prepare('PRAGMA table_info(notifications)').all();
      console.log('\n📋 Table structure:');
      columns.forEach((col: any) => {
        console.log(`  - ${col.name} (${col.type})`);
      });
    } else {
      console.log('❌ Table "notifications" was not created!');
    }

  } catch (error) {
    console.error('❌ Error running migration:', error);
    process.exit(1);
  } finally {
    db.close();
  }
}

runMigration();
