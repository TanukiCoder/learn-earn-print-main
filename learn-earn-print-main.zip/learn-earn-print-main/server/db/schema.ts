import { db } from './database.js';

export function createTables() {
  // Create users table (replaces auth.users and profiles)
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin', 'user')),
      subscription_start TEXT,
      subscription_end TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Create videos table
  db.exec(`
    CREATE TABLE IF NOT EXISTS videos (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      video_url TEXT NOT NULL,
      thumbnail_url TEXT,
      duration INTEGER,
      is_active INTEGER NOT NULL DEFAULT 1,
      order_index INTEGER NOT NULL DEFAULT 0,
      country TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Create quizzes table
  db.exec(`
    CREATE TABLE IF NOT EXISTS quizzes (
      id TEXT PRIMARY KEY,
      video_id TEXT NOT NULL,
      title TEXT NOT NULL,
      created_by TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE
    );
  `);

  // Create quiz_questions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS quiz_questions (
      id TEXT PRIMARY KEY,
      quiz_id TEXT NOT NULL,
      question_text TEXT NOT NULL,
      question_type TEXT NOT NULL CHECK(question_type IN ('text', 'radio', 'checkbox')),
      options TEXT,
      order_index INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
    );
  `);

  // Create quiz_submissions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS quiz_submissions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      quiz_id TEXT NOT NULL,
      video_id TEXT NOT NULL,
      answers TEXT NOT NULL,
      submitted_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
      FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
      UNIQUE(user_id, quiz_id)
    );
  `);

  // Create receipts table
  db.exec(`
    CREATE TABLE IF NOT EXISTS receipts (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      video_id TEXT NOT NULL,
      quiz_submission_id TEXT,
      amount REAL NOT NULL,
      receipt_number TEXT NOT NULL UNIQUE,
      user_name TEXT NOT NULL,
      template_country TEXT,
      generated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
      FOREIGN KEY (quiz_submission_id) REFERENCES quiz_submissions(id) ON DELETE SET NULL
    );
  `);

  // Create receipt_settings table
  db.exec(`
    CREATE TABLE IF NOT EXISTS receipt_settings (
      id TEXT PRIMARY KEY,
      header_text TEXT NOT NULL DEFAULT '',
      legal_text TEXT NOT NULL DEFAULT 'Acest document are valoare educațională și demonstrativă.',
      footer_text TEXT NOT NULL DEFAULT 'Mulțumim pentru participare!',
      logo_url TEXT,
      signature_text TEXT,
      signature_image_url TEXT,
      template_country TEXT,
      user_id TEXT,
      austria_address TEXT,
      austria_business_name TEXT,
      austria_city TEXT,
      austria_store_name TEXT,
      available_templates TEXT,
      france_address_line1 TEXT,
      france_address_line2 TEXT,
      france_footer_message TEXT,
      france_phone TEXT,
      france_store_name TEXT,
      germany_address TEXT,
      germany_city TEXT,
      germany_company_legal TEXT,
      germany_company_name TEXT,
      germany_phone TEXT,
      germany_slogan TEXT,
      italy_address TEXT,
      italy_city TEXT,
      italy_company_info TEXT,
      italy_document_type TEXT,
      italy_footer_message TEXT,
      italy_phone TEXT,
      italy_store_name TEXT,
      italy_vat_number TEXT,
      romania_address TEXT,
      romania_city TEXT,
      romania_email TEXT,
      romania_website TEXT,
      romania_cui TEXT,
      romania_phone TEXT,
      romania_store_name TEXT,
      quiz_title TEXT,
      donation_text_ro TEXT DEFAULT 'Donatie',
      donation_text_en TEXT DEFAULT 'Donation',
      donation_text_fr TEXT DEFAULT 'Donation',
      donation_text_it TEXT DEFAULT 'Donazione',
      donation_text_es TEXT DEFAULT 'Donación',
      donation_text_de TEXT DEFAULT 'Spende',
      spain_address_line1 TEXT,
      spain_address_line2 TEXT,
      spain_footer_message TEXT,
      spain_phone TEXT,
      spain_store_name TEXT,
      receipt_number_start INTEGER DEFAULT 0,
      receipt_number_current INTEGER DEFAULT 0,
      receipt_number_reset INTEGER DEFAULT 9999,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Create video_progress table
  db.exec(`
    CREATE TABLE IF NOT EXISTS video_progress (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      video_id TEXT NOT NULL,
      progress_percentage INTEGER NOT NULL DEFAULT 0 CHECK(progress_percentage >= 0 AND progress_percentage <= 100),
      completed INTEGER NOT NULL DEFAULT 0,
      last_watched_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
      UNIQUE(user_id, video_id)
    );
  `);

  // Create user_sessions table
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      device_type TEXT NOT NULL,
      device_info TEXT,
      ip_address TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      last_active TEXT NOT NULL DEFAULT (datetime('now')),
      login_at TEXT NOT NULL DEFAULT (datetime('now')),
      logout_reason TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  // Create admin_notifications table
  db.exec(`
    CREATE TABLE IF NOT EXISTS admin_notifications (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      data TEXT,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Create app_settings table
  db.exec(`
    CREATE TABLE IF NOT EXISTS app_settings (
      id TEXT PRIMARY KEY,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT NOT NULL,
      description TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Create indexes for better performance
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
    CREATE INDEX IF NOT EXISTS idx_users_subscription ON users(subscription_end);
    CREATE INDEX IF NOT EXISTS idx_videos_active ON videos(is_active);
    CREATE INDEX IF NOT EXISTS idx_receipts_user ON receipts(user_id);
    CREATE INDEX IF NOT EXISTS idx_receipts_generated ON receipts(generated_at);
    CREATE INDEX IF NOT EXISTS idx_quiz_submissions_user ON quiz_submissions(user_id);
    CREATE INDEX IF NOT EXISTS idx_video_progress_user ON video_progress(user_id);
    CREATE INDEX IF NOT EXISTS idx_user_sessions_user ON user_sessions(user_id);
  `);

  console.log('✅ All tables created successfully');
}

export function dropTables() {
  const tables = [
    'app_settings',
    'admin_notifications',
    'user_sessions',
    'video_progress',
    'receipt_settings',
    'receipts',
    'quiz_submissions',
    'quiz_questions',
    'quizzes',
    'videos',
    'users'
  ];

  tables.forEach(table => {
    db.exec(`DROP TABLE IF EXISTS ${table};`);
  });

  console.log('✅ All tables dropped successfully');
}
