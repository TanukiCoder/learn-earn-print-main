import { db } from './database.js';
import { createTables } from './schema.js';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Function to check if database is initialized (tables exist)
function isDatabaseInitialized(): boolean {
  try {
    // Check if users table exists
    const result = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get();
    return result !== undefined;
  } catch {
    return false;
  }
}

// Function to initialize database without closing connection (for server startup)
export async function ensureDatabaseInitialized() {
  try {
    // Check if database is already initialized
    if (isDatabaseInitialized()) {
      console.log('✅ Database already initialized');
      return;
    }

    console.log('🚀 Initializing database...');

    // Create data directory if it doesn't exist
    const dataDir = path.join(__dirname, '../../data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
      console.log('📁 Created data directory');
    }

    // Create uploads directories
    const uploadsDir = path.join(__dirname, '../../uploads');
    const videosDir = path.join(uploadsDir, 'videos');
    const thumbnailsDir = path.join(uploadsDir, 'thumbnails');
    const imagesDir = path.join(uploadsDir, 'images');

    [uploadsDir, videosDir, thumbnailsDir, imagesDir].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log(`📁 Created ${path.basename(dir)} directory`);
      }
    });

    // Create tables
    createTables();

    // Check if admin user exists
    const adminExists = db.prepare('SELECT id FROM users WHERE role = ?').get('admin');

    if (!adminExists) {
      // Create default admin user
      const adminId = uuidv4();
      const hashedPassword = await bcrypt.hash('admin123', 10);

      db.prepare(`
        INSERT INTO users (id, email, password_hash, full_name, role, is_active)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(adminId, 'admin@example.com', hashedPassword, 'Administrator', 'admin', 1);

      console.log('👤 Created default admin user:');
      console.log('   Email: admin@example.com');
      console.log('   Password: admin123');
      console.log('   ⚠️  Please change the password after first login!');
    } else {
      console.log('👤 Admin user already exists');
    }

    // Insert default receipt settings if not exists
    const settingsExists = db.prepare('SELECT id FROM receipt_settings LIMIT 1').get();

    if (!settingsExists) {
      const settingsId = uuidv4();
      db.prepare(`
        INSERT INTO receipt_settings (
          id, 
          header_text, 
          legal_text, 
          footer_text
        ) VALUES (?, ?, ?, ?)
      `).run(
        settingsId,
        '',
        'Acest document are valoare educațională și demonstrativă. Nu reprezintă un document fiscal.',
        'Mulțumim pentru participare în programul nostru educațional!'
      );

      console.log('📄 Created default receipt settings');
    } else {
      console.log('📄 Receipt settings already exist');
    }

    console.log('✅ Database initialized successfully!');
    console.log(`📍 Database location: ${path.join(dataDir, 'database.sqlite')}`);

  } catch (error) {
    console.error('❌ Error initializing database:', error);
    throw error;
  }
}

async function initDatabase() {
  try {
    await ensureDatabaseInitialized();
  } catch (error) {
    console.error('❌ Error initializing database:', error);
    process.exit(1);
  } finally {
    db.close();
  }
}

// Only run initDatabase if this file is executed directly (not imported)
// When run via 'tsx server/db/init.ts', process.argv[1] will contain the path to this file
// When imported, process.argv[1] will point to the main file (server/index.ts)
if (typeof process !== 'undefined' && process.argv[1]) {
  const mainFilePath = process.argv[1];
  const currentFilePath = fileURLToPath(import.meta.url);
  
  // Check if the main file path contains 'init' (for init.ts or init.js)
  // This is a simple check that works in most cases
  const isInitFile = mainFilePath.includes('/init') || mainFilePath.includes('\\init') || 
                     path.basename(mainFilePath, path.extname(mainFilePath)) === 'init';
  
  // Also check if paths match (direct execution)
  const pathsMatch = path.resolve(mainFilePath) === path.resolve(currentFilePath);
  
  if (isInitFile || pathsMatch) {
    initDatabase();
  }
}
