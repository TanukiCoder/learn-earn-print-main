import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import authRoutes from './routes/auth.js';
import videosRoutes from './routes/videos.js';
import usersRoutes from './routes/users.js';
import quizzesRoutes from './routes/quizzes.js';
import receiptsRoutes from './routes/receipts.js';
import videoProgressRoutes from './routes/video-progress.js';
import sessionsRoutes from './routes/sessions.js';
import appSettingsRoutes from './routes/app-settings.js';
import notificationsRoutes from './routes/notifications.js';
import { ensureDatabaseInitialized } from './db/init.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Trust proxy to get real IP addresses
app.set('trust proxy', true);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/videos', videosRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/quizzes', quizzesRoutes);
app.use('/api/receipts', receiptsRoutes);
app.use('/api/video-progress', videoProgressRoutes);
app.use('/api/sessions', sessionsRoutes);
app.use('/api/app-settings', appSettingsRoutes);
app.use('/api/notifications', notificationsRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

// Initialize database and start server
ensureDatabaseInitialized()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
      console.log(`📁 Uploads directory: ${path.join(__dirname, '../uploads')}`);
    });
  })
  .catch((error) => {
    console.error('❌ Failed to initialize database:', error);
    process.exit(1);
  });
