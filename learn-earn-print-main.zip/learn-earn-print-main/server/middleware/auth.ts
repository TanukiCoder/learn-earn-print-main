import { Request, Response, NextFunction } from 'express';
import { db } from '../db/database.js';

export interface AuthRequest extends Request {
  userId?: string;
  userRole?: string;
}

export function authenticateToken(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    // In a real app, you'd verify a JWT token here
    // For simplicity, we're using the token as user ID
    const user = db.prepare('SELECT id, role FROM users WHERE id = ? AND is_active = 1').get(token);

    if (!user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    req.userId = (user as any).id;
    req.userRole = (user as any).role;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

export function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  if (req.userRole !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}
