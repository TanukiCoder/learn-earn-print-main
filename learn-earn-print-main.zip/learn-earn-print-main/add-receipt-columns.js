import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, 'data', 'database.sqlite');
const db = new Database(dbPath);

console.log('🔧 Adding missing columns to receipt_settings table...\n');

// List of columns to add
const columnsToAdd = [
  'quiz_title TEXT',
  'donation_text_ro TEXT DEFAULT "Donatie"',
  'donation_text_en TEXT DEFAULT "Donation"',
  'donation_text_fr TEXT DEFAULT "Donation"',
  'donation_text_it TEXT DEFAULT "Donazione"',
  'donation_text_es TEXT DEFAULT "Donación"',
  'donation_text_de TEXT DEFAULT "Spende"',
  'romania_email TEXT',
  'romania_website TEXT',
  'romania_cui TEXT',
  'romania_phone TEXT'
];

let addedCount = 0;
let skippedCount = 0;

columnsToAdd.forEach(column => {
  const columnName = column.split(' ')[0];
  
  try {
    // Check if column exists
    const tableInfo = db.prepare("PRAGMA table_info(receipt_settings)").all();
    const columnExists = tableInfo.some(col => col.name === columnName);
    
    if (!columnExists) {
      db.prepare(`ALTER TABLE receipt_settings ADD COLUMN ${column}`).run();
      console.log(`✅ Added column: ${columnName}`);
      addedCount++;
    } else {
      console.log(`⏭️  Column already exists: ${columnName}`);
      skippedCount++;
    }
  } catch (error) {
    console.error(`❌ Error adding column ${columnName}:`, error.message);
  }
});

console.log(`\n📊 Summary:`);
console.log(`   Added: ${addedCount} columns`);
console.log(`   Skipped: ${skippedCount} columns`);
console.log(`\n✅ Migration complete!`);

db.close();
