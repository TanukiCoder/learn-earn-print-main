-- Fix search_path for all functions

-- Fix update_updated_at_column function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Fix generate_receipt_number function  
CREATE OR REPLACE FUNCTION generate_receipt_number()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_year TEXT;
  counter INTEGER;
  receipt_num TEXT;
BEGIN
  current_year := TO_CHAR(now(), 'YYYY');
  
  SELECT COUNT(*) + 1 INTO counter
  FROM public.receipts
  WHERE EXTRACT(YEAR FROM generated_at) = EXTRACT(YEAR FROM now());
  
  receipt_num := 'BON-' || current_year || '-' || LPAD(counter::TEXT, 6, '0');
  
  RETURN receipt_num;
END;
$$;