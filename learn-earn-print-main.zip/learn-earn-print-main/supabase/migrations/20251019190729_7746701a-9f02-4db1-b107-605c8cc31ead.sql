-- Update video URL to a working direct video URL
UPDATE videos 
SET video_url = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    description = 'Videoclip demonstrativ cu Big Buck Bunny. Urmăriți până la final pentru a putea selecta un chestionar și genera bonul fiscal.'
WHERE id = 'b5555e2e-3962-4ddb-a942-3be15967d854';