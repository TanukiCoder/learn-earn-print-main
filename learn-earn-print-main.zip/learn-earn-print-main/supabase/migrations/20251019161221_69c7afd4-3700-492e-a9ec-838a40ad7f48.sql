-- Add French receipt template specific fields to receipt_settings
ALTER TABLE receipt_settings
ADD COLUMN IF NOT EXISTS france_store_name TEXT DEFAULT 'MAGASIN EDUCAȚIONAL',
ADD COLUMN IF NOT EXISTS france_address_line1 TEXT DEFAULT '33 RUE DE L''ÉDUCATION',
ADD COLUMN IF NOT EXISTS france_address_line2 TEXT DEFAULT '75000 PARIS',
ADD COLUMN IF NOT EXISTS france_phone TEXT DEFAULT '01.23.45.67.89',
ADD COLUMN IF NOT EXISTS france_footer_message TEXT DEFAULT 'MERCI DE VOTRE VISITE\nÀ BIENTÔT';

COMMENT ON COLUMN receipt_settings.france_store_name IS 'Numele magazinului pentru template-ul francez';
COMMENT ON COLUMN receipt_settings.france_address_line1 IS 'Prima linie a adresei pentru template-ul francez';
COMMENT ON COLUMN receipt_settings.france_address_line2 IS 'A doua linie a adresei (cod poștal și oraș) pentru template-ul francez';
COMMENT ON COLUMN receipt_settings.france_phone IS 'Numărul de telefon pentru template-ul francez';
COMMENT ON COLUMN receipt_settings.france_footer_message IS 'Mesajul final pentru template-ul francez';