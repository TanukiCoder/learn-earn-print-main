-- Add country/category field to videos table
ALTER TABLE videos 
ADD COLUMN country TEXT DEFAULT 'România';

-- Create index for better performance when filtering by country
CREATE INDEX idx_videos_country ON videos(country);

-- Add some example countries/categories
COMMENT ON COLUMN videos.country IS 'Țara/categoria pentru organizarea videoclipurilor (România, Germania, Anglia, etc.)';