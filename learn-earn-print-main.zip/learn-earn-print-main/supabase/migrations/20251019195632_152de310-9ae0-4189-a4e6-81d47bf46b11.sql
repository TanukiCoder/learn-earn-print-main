-- Allow admins to delete any quiz, not just their own
DROP POLICY IF EXISTS "Users can delete own quizzes" ON public.quizzes;

CREATE POLICY "Users and admins can delete quizzes" 
ON public.quizzes 
FOR DELETE 
USING (
  auth.uid() = created_by 
  OR is_admin(auth.uid())
);

-- Also update quiz questions deletion policy to handle null created_by
DROP POLICY IF EXISTS "Users can delete questions for own quizzes" ON public.quiz_questions;

CREATE POLICY "Users and admins can delete quiz questions" 
ON public.quiz_questions 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM quizzes
    WHERE quizzes.id = quiz_questions.quiz_id
    AND (quizzes.created_by = auth.uid() OR is_admin(auth.uid()))
  )
  OR is_admin(auth.uid())
);