-- Activate admin account and ensure it's properly set up
UPDATE profiles 
SET 
  is_active = true,
  role = 'admin',
  subscription_end = NULL,
  subscription_start = NULL
WHERE email = 'admin@eduplatform.ro';