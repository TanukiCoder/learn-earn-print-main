-- Modify receipt_settings to support per-user settings

-- Add user_id column to receipt_settings
ALTER TABLE public.receipt_settings 
ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

-- Remove old RLS policies
DROP POLICY IF EXISTS "Everyone can view receipt settings" ON public.receipt_settings;
DROP POLICY IF EXISTS "Admins can update receipt settings" ON public.receipt_settings;

-- Create new RLS policies for per-user settings
CREATE POLICY "Users can view own receipt settings"
ON public.receipt_settings
FOR SELECT
TO authenticated
USING (user_id = auth.uid() OR user_id IS NULL);

CREATE POLICY "Users can insert own receipt settings"
ON public.receipt_settings
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own receipt settings"
ON public.receipt_settings
FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can manage all receipt settings"
ON public.receipt_settings
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  )
);

-- Create unique constraint for user_id (one setting per user)
CREATE UNIQUE INDEX IF NOT EXISTS receipt_settings_user_id_key 
ON public.receipt_settings(user_id) 
WHERE user_id IS NOT NULL;