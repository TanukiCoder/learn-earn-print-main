-- Create admin user
-- Password: Admin123!@#

INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  recovery_token,
  email_change_token_new,
  email_change
)
VALUES (
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'admin@eduplatform.ro',
  crypt('Admin123!@#', gen_salt('bf')),
  now(),
  '{"role": "admin", "full_name": "Administrator"}'::jsonb,
  now(),
  now(),
  '',
  '',
  '',
  ''
);

-- The handle_new_user trigger will automatically create the profile with admin role