-- Add quiz_title and donation_text columns for different languages
ALTER TABLE public.receipt_settings 
ADD COLUMN IF NOT EXISTS quiz_title text DEFAULT 'Avem câteva întrebări',
ADD COLUMN IF NOT EXISTS donation_text_ro text DEFAULT 'Donatie',
ADD COLUMN IF NOT EXISTS donation_text_en text DEFAULT 'Donation',
ADD COLUMN IF NOT EXISTS donation_text_fr text DEFAULT 'Donation',
ADD COLUMN IF NOT EXISTS donation_text_it text DEFAULT 'Donazione',
ADD COLUMN IF NOT EXISTS donation_text_es text DEFAULT 'Donación',
ADD COLUMN IF NOT EXISTS donation_text_de text DEFAULT 'Spende';

-- Add email and website columns for each country
ALTER TABLE public.receipt_settings 
ADD COLUMN IF NOT EXISTS romania_email text,
ADD COLUMN IF NOT EXISTS romania_website text,
ADD COLUMN IF NOT EXISTS romania_cui text,
ADD COLUMN IF NOT EXISTS romania_phone text,
ADD COLUMN IF NOT EXISTS spain_email text,
ADD COLUMN IF NOT EXISTS spain_website text,
ADD COLUMN IF NOT EXISTS spain_cif text,
ADD COLUMN IF NOT EXISTS italy_email text,
ADD COLUMN IF NOT EXISTS italy_website text,
ADD COLUMN IF NOT EXISTS france_email text,
ADD COLUMN IF NOT EXISTS france_website text,
ADD COLUMN IF NOT EXISTS france_siret text,
ADD COLUMN IF NOT EXISTS france_vat text,
ADD COLUMN IF NOT EXISTS austria_email text,
ADD COLUMN IF NOT EXISTS austria_website text,
ADD COLUMN IF NOT EXISTS austria_uid text,
ADD COLUMN IF NOT EXISTS germany_email text,
ADD COLUMN IF NOT EXISTS germany_website text,
ADD COLUMN IF NOT EXISTS germany_vat text,
ADD COLUMN IF NOT EXISTS germany_tax_number text;

COMMENT ON COLUMN receipt_settings.quiz_title IS 'Title displayed in the quiz dialog';
COMMENT ON COLUMN receipt_settings.donation_text_ro IS 'Donation text in Romanian';
COMMENT ON COLUMN receipt_settings.donation_text_en IS 'Donation text in English';
COMMENT ON COLUMN receipt_settings.donation_text_fr IS 'Donation text in French';
COMMENT ON COLUMN receipt_settings.donation_text_it IS 'Donation text in Italian';
COMMENT ON COLUMN receipt_settings.donation_text_es IS 'Donation text in Spanish';
COMMENT ON COLUMN receipt_settings.donation_text_de IS 'Donation text in German';

