-- Add new receipt settings columns for Romania, Austria, and Germany

ALTER TABLE public.receipt_settings 
ADD COLUMN IF NOT EXISTS romania_store_name text DEFAULT 'MAGAZIN EDUCAȚIONAL',
ADD COLUMN IF NOT EXISTS romania_address text DEFAULT 'STR. EDUCAȚIEI NR. 1',
ADD COLUMN IF NOT EXISTS romania_city text DEFAULT 'BUCUREȘTI',
ADD COLUMN IF NOT EXISTS austria_store_name text DEFAULT '** KUNDENBELEG **',
ADD COLUMN IF NOT EXISTS austria_business_name text DEFAULT 'VILLAGE SNACK BAR',
ADD COLUMN IF NOT EXISTS austria_address text DEFAULT 'KEGELG 37-39/TOP 7',
ADD COLUMN IF NOT EXISTS austria_city text DEFAULT '1030 WIEN',
ADD COLUMN IF NOT EXISTS germany_slogan text DEFAULT 'Ich lasse es®',
ADD COLUMN IF NOT EXISTS germany_company_name text DEFAULT 'Bildungszentrum',
ADD COLUMN IF NOT EXISTS germany_company_legal text DEFAULT 'Deutschland Inc.',
ADD COLUMN IF NOT EXISTS germany_address text DEFAULT 'Am Ostbahnhof 9',
ADD COLUMN IF NOT EXISTS germany_city text DEFAULT '10243 Berlin',
ADD COLUMN IF NOT EXISTS germany_phone text DEFAULT '030 29364913';

-- Update available_templates to include Austria and Germany
UPDATE public.receipt_settings
SET available_templates = '["romania", "spania", "italia", "franta", "austria", "germania"]'::jsonb
WHERE available_templates IS NOT NULL;