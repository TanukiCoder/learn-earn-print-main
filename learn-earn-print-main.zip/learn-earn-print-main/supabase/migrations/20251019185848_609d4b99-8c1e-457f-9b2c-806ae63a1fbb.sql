-- Add Spanish receipt template specific fields to receipt_settings
ALTER TABLE receipt_settings
ADD COLUMN IF NOT EXISTS spain_store_name TEXT DEFAULT 'TIENDA EDUCATIVA',
ADD COLUMN IF NOT EXISTS spain_address_line1 TEXT DEFAULT 'CALLE DE LA EDUCACIÓN, 33',
ADD COLUMN IF NOT EXISTS spain_address_line2 TEXT DEFAULT '28000 MADRID',
ADD COLUMN IF NOT EXISTS spain_phone TEXT DEFAULT '91 234 56 78',
ADD COLUMN IF NOT EXISTS spain_footer_message TEXT DEFAULT 'GRACIAS POR SU VISITA';

COMMENT ON COLUMN receipt_settings.spain_store_name IS 'Numele magazinului pentru template-ul spaniol';
COMMENT ON COLUMN receipt_settings.spain_address_line1 IS 'Adresa linia 1 pentru template-ul spaniol';
COMMENT ON COLUMN receipt_settings.spain_address_line2 IS 'Adresa linia 2 pentru template-ul spaniol';
COMMENT ON COLUMN receipt_settings.spain_phone IS 'Numărul de telefon pentru template-ul spaniol';
COMMENT ON COLUMN receipt_settings.spain_footer_message IS 'Mesajul final pentru template-ul spaniol';