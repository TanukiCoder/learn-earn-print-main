-- Add Italian receipt template specific fields to receipt_settings
ALTER TABLE receipt_settings
ADD COLUMN IF NOT EXISTS italy_store_name TEXT DEFAULT 'NEGOZIO EDUCATIVO',
ADD COLUMN IF NOT EXISTS italy_company_info TEXT DEFAULT 'SOCIETÀ S.P.A. unipersonale',
ADD COLUMN IF NOT EXISTS italy_address TEXT DEFAULT 'Via Educazione, 10',
ADD COLUMN IF NOT EXISTS italy_city TEXT DEFAULT '40138 - Bologna',
ADD COLUMN IF NOT EXISTS italy_vat_number TEXT DEFAULT 'P.Iva 01234567890',
ADD COLUMN IF NOT EXISTS italy_phone TEXT DEFAULT 'Tel. 051/12345678',
ADD COLUMN IF NOT EXISTS italy_document_type TEXT DEFAULT 'DOCUMENTO COMMERCIALE\ndi vendita o prestazione',
ADD COLUMN IF NOT EXISTS italy_footer_message TEXT DEFAULT 'DETTAGLIO FORME di PAGAMENTO';

COMMENT ON COLUMN receipt_settings.italy_store_name IS 'Numele magazinului pentru template-ul italian';
COMMENT ON COLUMN receipt_settings.italy_company_info IS 'Informații companie pentru template-ul italian';
COMMENT ON COLUMN receipt_settings.italy_address IS 'Adresa pentru template-ul italian';
COMMENT ON COLUMN receipt_settings.italy_city IS 'Orașul și codul poștal pentru template-ul italian';
COMMENT ON COLUMN receipt_settings.italy_vat_number IS 'Numărul de TVA pentru template-ul italian';
COMMENT ON COLUMN receipt_settings.italy_phone IS 'Numărul de telefon pentru template-ul italian';
COMMENT ON COLUMN receipt_settings.italy_document_type IS 'Tipul documentului pentru template-ul italian';
COMMENT ON COLUMN receipt_settings.italy_footer_message IS 'Mesajul final pentru template-ul italian';