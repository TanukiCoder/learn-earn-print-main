-- Enable realtime for receipts table
ALTER PUBLICATION supabase_realtime ADD TABLE public.receipts;