begin;
  -- Delete dependent data first (safe cleanup)
  delete from public.quiz_submissions where quiz_id in ('d2c90160-8172-47ba-a36c-0fcf7e47cbc2','4e25a5b0-ff90-4b40-8de3-c7f7771926cc');
  delete from public.quiz_questions   where quiz_id in ('d2c90160-8172-47ba-a36c-0fcf7e47cbc2','4e25a5b0-ff90-4b40-8de3-c7f7771926cc');
  delete from public.quizzes          where id      in ('d2c90160-8172-47ba-a36c-0fcf7e47cbc2','4e25a5b0-ff90-4b40-8de3-c7f7771926cc');
commit;