-- Add template fields to receipt_settings
ALTER TABLE receipt_settings
ADD COLUMN template_country TEXT DEFAULT 'romania',
ADD COLUMN available_templates JSONB DEFAULT '["romania", "spania", "italia", "franta"]'::jsonb;

-- Add template_used field to receipts table to track which template was used
ALTER TABLE receipts
ADD COLUMN template_country TEXT DEFAULT 'romania';

COMMENT ON COLUMN receipt_settings.template_country IS 'Template țară implicit folosit (romania, spania, italia, franta)';
COMMENT ON COLUMN receipt_settings.available_templates IS 'Lista de template-uri disponibile pentru utilizatori';
COMMENT ON COLUMN receipts.template_country IS 'Template țară folosit pentru acest bon';