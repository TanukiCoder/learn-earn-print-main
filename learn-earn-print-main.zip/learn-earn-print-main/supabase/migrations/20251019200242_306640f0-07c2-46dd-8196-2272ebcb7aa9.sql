-- Allow any authenticated user to delete the two initial quizzes by title
-- Safely replace the existing delete policy to include an exception for specific titles
DROP POLICY IF EXISTS "Users and admins can delete quizzes" ON public.quizzes;

CREATE POLICY "Delete quizzes by owner, admin, or special titles"
ON public.quizzes
FOR DELETE
TO authenticated
USING (
  (auth.uid() = created_by)
  OR public.is_admin(auth.uid())
  OR (lower(title) IN ('test de evaluare', 'chestionar final'))
);
