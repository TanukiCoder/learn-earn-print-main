-- Allow users to create their own quizzes
CREATE POLICY "Users can create own quizzes" 
ON public.quizzes 
FOR INSERT 
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.is_active = true 
    AND (profiles.subscription_end IS NULL OR profiles.subscription_end > now())
  )
);

-- Allow users to update their own quizzes (we'll add a user_id column first)
ALTER TABLE public.quizzes 
ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id);

-- Update the insert policy to track ownership
DROP POLICY IF EXISTS "Users can create own quizzes" ON public.quizzes;

CREATE POLICY "Users can create own quizzes" 
ON public.quizzes 
FOR INSERT 
TO authenticated
WITH CHECK (
  auth.uid() = created_by
  AND EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.is_active = true 
    AND (profiles.subscription_end IS NULL OR profiles.subscription_end > now())
  )
);

CREATE POLICY "Users can update own quizzes" 
ON public.quizzes 
FOR UPDATE 
TO authenticated
USING (auth.uid() = created_by);

CREATE POLICY "Users can delete own quizzes" 
ON public.quizzes 
FOR DELETE 
TO authenticated
USING (auth.uid() = created_by);

-- Allow users to create quiz questions for their own quizzes
CREATE POLICY "Users can create questions for own quizzes" 
ON public.quiz_questions 
FOR INSERT 
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM quizzes 
    WHERE quizzes.id = quiz_id 
    AND (quizzes.created_by = auth.uid() OR EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'::user_role
    ))
  )
);

CREATE POLICY "Users can update questions for own quizzes" 
ON public.quiz_questions 
FOR UPDATE 
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM quizzes 
    WHERE quizzes.id = quiz_id 
    AND (quizzes.created_by = auth.uid() OR EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'::user_role
    ))
  )
);

CREATE POLICY "Users can delete questions for own quizzes" 
ON public.quiz_questions 
FOR DELETE 
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM quizzes 
    WHERE quizzes.id = quiz_id 
    AND (quizzes.created_by = auth.uid() OR EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'::user_role
    ))
  )
);