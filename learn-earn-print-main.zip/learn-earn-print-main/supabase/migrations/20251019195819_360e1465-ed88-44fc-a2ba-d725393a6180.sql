-- Allow admins to delete quiz submissions
DROP POLICY IF EXISTS "Admins can delete quiz submissions" ON public.quiz_submissions;
CREATE POLICY "Admins can delete quiz submissions"
ON public.quiz_submissions
FOR DELETE
USING (is_admin(auth.uid()));