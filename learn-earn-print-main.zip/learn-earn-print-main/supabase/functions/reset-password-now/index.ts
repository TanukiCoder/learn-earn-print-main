import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Resetting admin password...');

    // Update admin password
    const { data, error } = await supabaseAdmin.auth.admin.updateUserById(
      '849c870c-badd-47c5-83a0-00b8e7e7a7da',
      { password: 'admin123' }
    );

    if (error) {
      console.error('Error resetting password:', error);
      throw error;
    }

    console.log('Password reset successfully:', data);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Parola admin resetată cu succes la: admin123',
        user: data
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Exception:', error);
    return new Response(
      JSON.stringify({ error: error?.message || 'Unknown error' }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
