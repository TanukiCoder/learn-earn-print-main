-- Скрипт для очистки старых сессий
-- Выполните этот скрипт в SQLite для удаления дубликатов

-- 1. Удалить все неактивные сессии
DELETE FROM user_sessions WHERE is_active = 0;

-- 2. Для каждого пользователя оставить только последнюю активную сессию
DELETE FROM user_sessions 
WHERE id NOT IN (
  SELECT id FROM (
    SELECT id, user_id, MAX(last_active) as max_active
    FROM user_sessions
    WHERE is_active = 1
    GROUP BY user_id
  )
);

-- 3. Проверить результат
SELECT 
  u.email,
  s.device_type,
  s.ip_address,
  s.login_at,
  s.is_active
FROM user_sessions s
LEFT JOIN users u ON s.user_id = u.id
ORDER BY s.last_active DESC;
